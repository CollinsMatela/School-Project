package school.project;
import java.sql.Blob;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.table.JTableHeader;



public class StudentApplicants extends javax.swing.JFrame {
    
        Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
        ResultSetMetaData rsmd;
    
        private static final String Dbname = "applicationform";
	private static final String DbDriver = "com.mysql.cj.jdbc.Driver";
	private static final String DbURL = "jdbc:mysql://localhost:3306/" + Dbname;
	private static final String DbUsername = "root";
	private static final String DbPassword = "";
    
        public void SQLconnection(){

         try {
                   Class.forName(DbDriver);
                   con = DriverManager.getConnection(DbURL, DbUsername, DbPassword);
                   System.out.println("Connection successful!");
                   
         } catch (ClassNotFoundException e) {
             
                   System.err.println("JDBC Driver not found: " + e.getMessage());
                   e.printStackTrace();
         } catch (SQLException e) {
             
                   System.err.println("Database connection failed: " + e.getMessage());
                  e.printStackTrace();
         }
         } // SQLconnection END
    
    public void StudentsApplicantsTable(){
        
            try {
                pst = con.prepareStatement("SELECT * FROM table1");
                rs = pst.executeQuery();
                rsmd = rs.getMetaData();
                
                String StudentNumber;
                String StudentLastName;
                String StudentFirstName;
                String StudentMiddleName;
                String StudentEmailAddress;
                String StudentContactNumber;
                String StudentCourse;
                
                DefaultTableModel ApplicantTable = new DefaultTableModel();
                ApplicantTable.setColumnIdentifiers(new String[]{"No.","Last Name", "First Name", "Middle Name", "Email Address", "Contact Number", "Course"});
                
                while(rs.next()){
                    StudentNumber = rs.getString("number");
                    StudentLastName = rs.getString("studentlastname");
                    StudentFirstName = rs.getString("studentfirstname");
                    StudentMiddleName = rs.getString("studentmiddlename");
                    StudentEmailAddress = rs.getString("emailaddress");
                    StudentContactNumber = rs.getString("contactnumber");
                    StudentCourse = rs.getString("course");
                    
                    ApplicantTable.addRow(new Object[]{StudentNumber, StudentLastName, StudentFirstName, StudentMiddleName, StudentEmailAddress, StudentContactNumber, StudentCourse});
                    
                }
                Table1.setModel(ApplicantTable);
   
            } catch (SQLException ex) {
                Logger.getLogger(StudentApplicants.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    private void updateRowNumbers() {
    DefaultTableModel model = (DefaultTableModel) Table1.getModel();

    for (int i = 0; i < model.getRowCount(); i++) {
        model.setValueAt(i + 1, i, 0);
    }
}
    public void hideComponents(){
       
    }
    
   
    


    public StudentApplicants() {
        initComponents();
        SQLconnection();
        StudentsApplicantsTable();
//        updateRowNumbers();
        hideComponents();
        
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        txtLogout = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        FunctionBtnBox1 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        SelectClassBtn = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        StudentApplicantBox = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        Table1 = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        coursee = new javax.swing.JTextField();
        middle_name = new javax.swing.JTextField();
        last_name = new javax.swing.JTextField();
        year_level = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        first_name = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        sem = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jButton7 = new javax.swing.JButton();
        TypeOfPayment = new javax.swing.JComboBox<>();
        ComboSelectClass = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        table_number = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("INPUT FRAME");
        setName("DashboardFrame"); // NOI18N
        setUndecorated(true);
        setResizable(false);

        jPanel5.setBackground(new java.awt.Color(249, 246, 238));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 66, 37));

        jButton10.setBackground(new java.awt.Color(0, 66, 37));
        jButton10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("x");
        jButton10.setBorder(null);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton12.setBackground(new java.awt.Color(0, 66, 37));
        jButton12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("-");
        jButton12.setBorder(null);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(1714, Short.MAX_VALUE)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel5.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1800, 60));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(153, 153, 153));
        jButton2.setText("Student Records Table");
        jButton2.setBorder(null);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 359, 250, 50));

        txtLogout.setBackground(new java.awt.Color(255, 255, 255));
        txtLogout.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtLogout.setForeground(new java.awt.Color(153, 153, 153));
        txtLogout.setText("Logout");
        txtLogout.setBorder(null);
        txtLogout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txtLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLogoutActionPerformed(evt);
            }
        });
        jPanel1.add(txtLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 920, 250, 50));

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(153, 153, 153));
        jButton3.setText("Dashboard");
        jButton3.setBorder(null);
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 191, 250, 50));

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(153, 153, 153));
        jButton5.setText("Cashier / Payment");
        jButton5.setBorder(null);
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 303, 250, 50));

        jButton8.setBackground(new java.awt.Color(204, 204, 204));
        jButton8.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton8.setForeground(new java.awt.Color(153, 153, 153));
        jButton8.setText("Student Applicants Table");
        jButton8.setBorder(null);
        jButton8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 247, 250, 50));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/462583466_27828866910093434_8179531832153963087_n (1).png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 80, -1, -1));

        jPanel5.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 970));

        FunctionBtnBox1.setBackground(new java.awt.Color(255, 255, 255));
        FunctionBtnBox1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel11.setText("Function Buttons:");
        FunctionBtnBox1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        SelectClassBtn.setBackground(new java.awt.Color(0, 66, 37));
        SelectClassBtn.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        SelectClassBtn.setForeground(new java.awt.Color(255, 255, 255));
        SelectClassBtn.setText("Select");
        SelectClassBtn.setBorder(null);
        SelectClassBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SelectClassBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectClassBtnActionPerformed(evt);
            }
        });
        FunctionBtnBox1.add(SelectClassBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 210, 50));

        jButton13.setBackground(new java.awt.Color(235, 235, 235));
        jButton13.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton13.setForeground(new java.awt.Color(153, 153, 153));
        jButton13.setText("Remove");
        jButton13.setBorder(null);
        jButton13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        FunctionBtnBox1.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 210, 50));

        jButton6.setBackground(new java.awt.Color(255, 204, 0));
        jButton6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(0, 66, 37));
        jButton6.setText("View");
        jButton6.setBorder(null);
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        FunctionBtnBox1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 210, 50));

        jPanel5.add(FunctionBtnBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1570, 140, 210, 370));

        StudentApplicantBox.setBackground(new java.awt.Color(255, 255, 255));
        StudentApplicantBox.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Table1.setBackground(new java.awt.Color(255, 255, 255));
        Table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        Table1.setGridColor(new java.awt.Color(204, 204, 204));
        Table1.setSelectionBackground(new java.awt.Color(255, 204, 0));
        Table1.setSelectionForeground(new java.awt.Color(51, 51, 51));
        Table1.setShowHorizontalLines(true);
        Table1.setShowVerticalLines(true);
        jScrollPane3.setViewportView(Table1);

        StudentApplicantBox.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 50, 1220, 290));

        jLabel9.setFont(new java.awt.Font("Bahnschrift", 0, 13)); // NOI18N
        jLabel9.setText("Student Applicants Table");
        StudentApplicantBox.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 170, 50));

        jPanel5.add(StudentApplicantBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, 1270, 370));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        coursee.setEditable(false);
        coursee.setBackground(new java.awt.Color(255, 255, 255));
        coursee.setFont(new java.awt.Font("Bahnschrift", 0, 11)); // NOI18N
        coursee.setForeground(new java.awt.Color(51, 51, 51));
        coursee.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel3.add(coursee, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 160, 300, 40));

        middle_name.setEditable(false);
        middle_name.setBackground(new java.awt.Color(255, 255, 255));
        middle_name.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        middle_name.setForeground(new java.awt.Color(51, 51, 51));
        middle_name.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel3.add(middle_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 80, 300, 40));

        last_name.setEditable(false);
        last_name.setBackground(new java.awt.Color(255, 255, 255));
        last_name.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        last_name.setForeground(new java.awt.Color(51, 51, 51));
        last_name.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel3.add(last_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 300, 40));

        year_level.setEditable(false);
        year_level.setBackground(new java.awt.Color(255, 255, 255));
        year_level.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        year_level.setForeground(new java.awt.Color(51, 51, 51));
        year_level.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel3.add(year_level, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 300, 40));

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Course");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 140, 100, -1));

        jLabel2.setBackground(new java.awt.Color(153, 153, 153));
        jLabel2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 153, 153));
        jLabel2.setText("Last Name");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 100, -1));

        first_name.setEditable(false);
        first_name.setBackground(new java.awt.Color(255, 255, 255));
        first_name.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        first_name.setForeground(new java.awt.Color(51, 51, 51));
        first_name.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel3.add(first_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 80, 300, 40));

        jLabel3.setBackground(new java.awt.Color(153, 153, 153));
        jLabel3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 153, 153));
        jLabel3.setText("First Name");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 60, 100, -1));

        jLabel5.setBackground(new java.awt.Color(153, 153, 153));
        jLabel5.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 153));
        jLabel5.setText("Year");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 100, -1));

        sem.setEditable(false);
        sem.setBackground(new java.awt.Color(255, 255, 255));
        sem.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        sem.setForeground(new java.awt.Color(51, 51, 51));
        sem.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel3.add(sem, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 160, 300, 40));

        jLabel6.setBackground(new java.awt.Color(153, 153, 153));
        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 153, 153));
        jLabel6.setText("Semester");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 140, 100, -1));

        jPanel4.setBackground(new java.awt.Color(239, 239, 239));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton7.setBackground(new java.awt.Color(0, 66, 37));
        jButton7.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("SUBMIT");
        jButton7.setBorder(null);
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 230, 50));

        TypeOfPayment.setBackground(new java.awt.Color(255, 255, 255));
        TypeOfPayment.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        TypeOfPayment.setForeground(new java.awt.Color(25, 25, 25));
        TypeOfPayment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Type of Payment", "Full Payment", "Monthly Payment" }));
        TypeOfPayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TypeOfPaymentActionPerformed(evt);
            }
        });
        jPanel4.add(TypeOfPayment, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 170, 40));

        ComboSelectClass.setBackground(new java.awt.Color(255, 255, 255));
        ComboSelectClass.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        ComboSelectClass.setForeground(new java.awt.Color(25, 25, 25));
        ComboSelectClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboSelectClassActionPerformed(evt);
            }
        });
        jPanel4.add(ComboSelectClass, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 170, 40));

        jLabel10.setBackground(new java.awt.Color(153, 153, 153));
        jLabel10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 153, 153));
        jLabel10.setText("Type of Payment");
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 100, -1));

        jLabel12.setBackground(new java.awt.Color(153, 153, 153));
        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 153, 153));
        jLabel12.setText("Select Class");
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 100, -1));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 0, 230, 370));

        jLabel7.setBackground(new java.awt.Color(153, 153, 153));
        jLabel7.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 153, 153));
        jLabel7.setText("Middle Name");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 60, 100, -1));

        table_number.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        table_number.setForeground(new java.awt.Color(153, 153, 153));
        jPanel3.add(table_number, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 30, 30));

        jPanel5.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 530, 1270, 370));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 1800, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLogoutActionPerformed
        // TODO add your handling code here:
        Login login = new Login();
        login.setVisible(true);
        dispose();
    }//GEN-LAST:event_txtLogoutActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        
        EnrolledStudents enrolledstudents = new EnrolledStudents();
        enrolledstudents.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        StudentApplicants dashboard = new StudentApplicants();
        this.setState(dashboard.ICONIFIED);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Dashboard frame = new Dashboard();
        frame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed

            try{
                
                int SelectRow = Table1.getSelectedRow();
                
                if(SelectRow == -1){
                    JOptionPane.showMessageDialog(null, "Please select a row in Student Applicant Table to delete");
                    return;
                }
                
                String SelectedRow = Table1.getValueAt(SelectRow, 0).toString();
                
                int ConfirmationMessage = JOptionPane.showConfirmDialog(null, "You want to delete this row?");
                if(ConfirmationMessage == JOptionPane.YES_NO_OPTION){
                    pst = con.prepareStatement("DELETE FROM table1 WHERE number = ?");
                    pst.setString(1, SelectedRow);
                    pst.executeUpdate();
                        
                    JOptionPane.showMessageDialog(null, "Row deleted successfully.");
                    StudentsApplicantsTable();
                    updateRowNumbers();
                    StudentsApplicantsTable();
                }
                
  
            } catch (SQLException ex) {
                Logger.getLogger(StudentApplicants.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        
            try {
                
                int selectedRow = Table1.getSelectedRow();
                
                if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Please select a row first.");
                return;
                }
                
                String selectedStudentRow = (String) Table1.getValueAt(selectedRow, 0);
                
                pst = con.prepareStatement("SELECT * FROM table1 WHERE number = ?");
                pst.setString(1, selectedStudentRow);
                rs = pst.executeQuery();

                while(rs.next()){

          String Number = rs.getString(1);
          String AdmitType = rs.getString(1);
          String YearLevel = rs.getString(2);
          String SchoolYear = rs.getString(3);
          String Term = rs.getString(4);
          String Course = rs.getString(5);

          String StudentFirstName = rs.getString(6);
          String StudentLastName = rs.getString(7);
          String StudentMiddleName = rs.getString(8);
          String StudentSuffix = rs.getString(9);
          String StudentGender = rs.getString(10);
          String StudentStatus = rs.getString(11);
          String StudentCitezenship = rs.getString(12);
          String formattedDate = rs.getString(13);
          String StudentBirthplace = rs.getString(14);
          String StudentReligion = rs.getString(15);

          String Block = rs.getString(16);
          String Street = rs.getString(17);
          String Subdivision = rs.getString(18);
          String Baranggay = rs.getString(19);
          String Municipality = rs.getString(20);
          String Province = rs.getString(21);
          String ZipCode = rs.getString(22);

          String StudentEmailAddress = rs.getString(23);
          String StudentContactNumber = rs.getString(24);

          String SchoolType = rs.getString(25);
          String NameOfSchool = rs.getString(26);
          String Strand = rs.getString(27);
          String PreviousSchoolYear = rs.getString(28);

          String FatherFirstName = rs.getString(29);
          String FatherLastName = rs.getString(30);
          String FatherMiddleInitial = rs.getString(31);
          String FatherSuffix = rs.getString(32);
          String FatherContactNumber = rs.getString(33);
          String FatherEmailAddress = rs.getString(34);
          String FatherOccupation = rs.getString(35);

          String MotherFirstName = rs.getString(36);
          String MotherLastName = rs.getString(37);
          String MotherMiddleInitial = rs.getString(38);
          String MotherSuffix = rs.getString(39);
          String MotherContactNumber = rs.getString(40);
          String MotherEmailAddress = rs.getString(41);
          String MotherOccupation = rs.getString(42);

          String GuirdianFirstName = rs.getString(43);
          String GuirdianLastName = rs.getString(44);
          String GuirdianMiddleInitial = rs.getString(45);
          String GuirdianSuffix = rs.getString(46);
          String GuirdianContactNumber = rs.getString(47);
          String GuirdianEmailAddress = rs.getString(48);
          String GuirdianOccupation = rs.getString(49);
          String GuirdianRelationship = rs.getString(50);
          Blob StudentPicture = rs.getBlob(52);
          
          byte[] StudentImage = null;
          
          if (StudentPicture != null) {
          StudentImage = StudentPicture.getBytes(1, (int) StudentPicture.length());
          }
          
          
                     View view = new View(
    Number, AdmitType, YearLevel, SchoolYear, Term, Course,
    StudentFirstName, StudentLastName, StudentMiddleName,
    StudentSuffix, StudentGender, StudentStatus, StudentCitezenship,
    formattedDate, StudentBirthplace, StudentReligion,
    Block, Street, Subdivision, Baranggay, Municipality,
    Province, ZipCode, StudentEmailAddress, StudentContactNumber,
    SchoolType, NameOfSchool, Strand, PreviousSchoolYear,
    FatherFirstName, FatherLastName, FatherMiddleInitial, FatherSuffix,
    FatherContactNumber, FatherEmailAddress, FatherOccupation,
    MotherFirstName, MotherLastName, MotherMiddleInitial, MotherSuffix,
    MotherContactNumber, MotherEmailAddress, MotherOccupation,
    GuirdianFirstName, GuirdianLastName, GuirdianMiddleInitial,
    GuirdianSuffix, GuirdianContactNumber, GuirdianEmailAddress,
    GuirdianOccupation, GuirdianRelationship, StudentImage
);
                     view.setVisible(true);

            }

            } catch (SQLException ex) {
                Logger.getLogger(StudentApplicants.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        Payment frame = new Payment();
        frame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        StudentApplicants frame = new StudentApplicants();
        frame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void SelectClassBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectClassBtnActionPerformed
        
        int selectedRow = Table1.getSelectedRow();
                
        if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Please select a row first.");
                return;
                }
         String selectedStudentRow = (String) Table1.getValueAt(selectedRow, 0);
         
            try {
          pst = con.prepareStatement("SELECT * FROM table1 WHERE number = ?");
          pst.setString(1, selectedStudentRow);
          rs = pst.executeQuery();
                
          while(rs.next()){
                    
          String StudentNumber = rs.getString(1);          
          String AdmitType = rs.getString(2);              
          String YearLevel = rs.getString(3);              
          String SchoolYear = rs.getString(4);             
          String Term = rs.getString(5);                   
          String Course = rs.getString(6);                 

          String StudentFirstName = rs.getString(7);      
          String StudentLastName = rs.getString(8);     
          String StudentMiddleName = rs.getString(9);    
          String StudentSuffix = rs.getString(10);        
          String StudentGender = rs.getString(11);        
          String StudentStatus = rs.getString(12);       
          String StudentCitezenship = rs.getString(13);   
          String formattedDate = rs.getString(14);      
          String StudentBirthplace = rs.getString(15);    
          String StudentReligion = rs.getString(16);      

          String Block = rs.getString(17);               
          String Street = rs.getString(18);          
          String Subdivision = rs.getString(19);         
          String Baranggay = rs.getString(20);      
          String Municipality = rs.getString(21);         
          String Province = rs.getString(22);          
          String ZipCode = rs.getString(23);             

         String StudentEmailAddress = rs.getString(24);  
         String StudentContactNumber = rs.getString(25); 

         String SchoolType = rs.getString(26);          
         String NameOfSchool = rs.getString(27);        
         String Strand = rs.getString(28);             
         String PreviousSchoolYear = rs.getString(29);  

         String FatherFirstName = rs.getString(30);     
         String FatherLastName = rs.getString(31);    
         String FatherMiddleInitial = rs.getString(32); 
         String FatherSuffix = rs.getString(33);       
         String FatherContactNumber = rs.getString(34);  
         String FatherEmailAddress = rs.getString(35);  
         String FatherOccupation = rs.getString(36);   

         String MotherFirstName = rs.getString(37);      
         String MotherLastName = rs.getString(38);     
         String MotherMiddleInitial = rs.getString(39); 
         String MotherSuffix = rs.getString(40);        
         String MotherContactNumber = rs.getString(41);   
         String MotherEmailAddress = rs.getString(42);    
         String MotherOccupation = rs.getString(43);     

         String GuirdianFirstName = rs.getString(44);     
         String GuirdianLastName = rs.getString(45);  
         String GuirdianMiddleInitial = rs.getString(46);
         String GuirdianSuffix = rs.getString(47);      
         String GuirdianContactNumber = rs.getString(48); 
         String GuirdianEmailAddress = rs.getString(49);  
         String GuirdianOccupation = rs.getString(50);   
         String GuirdianRelationship = rs.getString(51);  

         Blob StudentPicture = rs.getBlob(52);       
                
         
         try {
               InputStream inputStream = StudentPicture.getBinaryStream();
               BufferedImage image = ImageIO.read(inputStream);
         } catch (IOException ex) {
               Logger.getLogger(StudentApplicants.class.getName()).log(Level.SEVERE, null, ex);
         }

          if(YearLevel.equals("First Year Level") && Course.equals("BSIT - Bachelor of Science in Information Technology")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSIT - 101");
              ComboSelectClass.addItem("BSIT - 102");
              ComboSelectClass.addItem("BSIT - 103");
              ComboSelectClass.addItem("BSIT - 104");
              
              
              
         } else if(YearLevel.equals("Second Year Level") && Course.equals("BSIT - Bachelor of Science in Information Technology")){
              
             
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSIT - 201");
              ComboSelectClass.addItem("BSIT - 202");
              ComboSelectClass.addItem("BSIT - 203");
              ComboSelectClass.addItem("BSIT - 204");
              
              
                 
              
              
         } else if(YearLevel.equals("Third Year Level") && Course.equals("BSIT - Bachelor of Science in Information Technology")){
                  
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSIT - 301");
              ComboSelectClass.addItem("BSIT - 302");
              ComboSelectClass.addItem("BSIT - 303");
              ComboSelectClass.addItem("BSIT - 304");
              
         } else if(YearLevel.equals("Fourth Year Level") && Course.equals("BSIT - Bachelor of Science in Information Technology")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSIT - 401");
              ComboSelectClass.addItem("BSIT - 402");
              ComboSelectClass.addItem("BSIT - 403");
              ComboSelectClass.addItem("BSIT - 404");
              
         } else if(YearLevel.equals("First Year Level") && Course.equals("BSTM - Bachelor of Science in Tourism and Management")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSTM - 101");
              ComboSelectClass.addItem("BSTM - 102");
              ComboSelectClass.addItem("BSTM - 103");
              ComboSelectClass.addItem("BSTM - 104");
              
         } else if(YearLevel.equals("Second Year Level") && Course.equals("BSTM - Bachelor of Science in Tourism and Management")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSTM - 201");
              ComboSelectClass.addItem("BSTM - 202");
              ComboSelectClass.addItem("BSTM - 203");
              ComboSelectClass.addItem("BSTM - 204");
              
         } else if(YearLevel.equals("Third Year Level") && Course.equals("BSTM - Bachelor of Science in Tourism and Management")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSTM - 301");
              ComboSelectClass.addItem("BSTM - 302");
              ComboSelectClass.addItem("BSTM - 303");
              ComboSelectClass.addItem("BSTM - 304");
              
         } else if(YearLevel.equals("Fourth Year Level") && Course.equals("BSTM - Bachelor of Science in Tourism and Management")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSTM - 401");
              ComboSelectClass.addItem("BSTM - 402");
              ComboSelectClass.addItem("BSTM - 403");
              ComboSelectClass.addItem("BSTM - 404");
              
         } else if(YearLevel.equals("First Year Level") && Course.equals("BSA - Bachelor of Science in Accountancy")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSA - 101");
              ComboSelectClass.addItem("BSA - 102");
              ComboSelectClass.addItem("BSA - 103");
              ComboSelectClass.addItem("BSA - 104");
              
         } else if(YearLevel.equals("Second Year Level") && Course.equals("BSA - Bachelor of Science in Accountancy")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSA - 201");
              ComboSelectClass.addItem("BSA - 202");
              ComboSelectClass.addItem("BSA - 203");
              ComboSelectClass.addItem("BSA - 204");
              
         } else if(YearLevel.equals("Third Year Level") && Course.equals("BSA - Bachelor of Science in Accountancy")){
                     
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSA - 301");
              ComboSelectClass.addItem("BSA - 302");
              ComboSelectClass.addItem("BSA - 303");
              ComboSelectClass.addItem("BSA - 304");
              
         } else if(YearLevel.equals("Fourth Year Level") && Course.equals("BSA - Bachelor of Science in Accountancy")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSA - 401");
              ComboSelectClass.addItem("BSA - 402");
              ComboSelectClass.addItem("BSA - 403");
              ComboSelectClass.addItem("BSA - 404");
              
         } else if(YearLevel.equals("First Year Level") && Course.equals("BSCpE - Bachelor of Science in Computer Engineering")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSCpE - 101");
              ComboSelectClass.addItem("BSCpE - 102");
              ComboSelectClass.addItem("BSCpE - 103");
              ComboSelectClass.addItem("BSCpE - 104");
              
         } else if(YearLevel.equals("Second Year Level") && Course.equals("BSCpE - Bachelor of Science in Computer Engineering")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSCpE - 201");
              ComboSelectClass.addItem("BSCpE - 202");
              ComboSelectClass.addItem("BSCpE - 203");
              ComboSelectClass.addItem("BSCpE - 204");
              
         } else if(YearLevel.equals("Third Year Level") && Course.equals("BSCpE - Bachelor of Science in Computer Engineering")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSCpE - 301");
              ComboSelectClass.addItem("BSCpE - 302");
              ComboSelectClass.addItem("BSCpE - 303");
              ComboSelectClass.addItem("BSCpE - 304");
              
         } else if(YearLevel.equals("Fourth Year Level") && Course.equals("BSCpE - Bachelor of Science in Computer Engineering")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSCpE - 401");
              ComboSelectClass.addItem("BSCpE - 402");
              ComboSelectClass.addItem("BSCpE - 403");
              ComboSelectClass.addItem("BSCpE - 404");
              
         } else if(YearLevel.equals("First Year Level") && Course.equals("BSHM - Bachelor of Science in Hospitality Management")){
                     
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSHM - 101");
              ComboSelectClass.addItem("BSHM - 102");
              ComboSelectClass.addItem("BSHM - 103");
              ComboSelectClass.addItem("BSHM - 104");
              
         } else if(YearLevel.equals("Second Year Level") && Course.equals("BSHM - Bachelor of Science in Hospitality Management")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSHM - 201");
              ComboSelectClass.addItem("BSHM - 202");
              ComboSelectClass.addItem("BSHM - 203");
              ComboSelectClass.addItem("BSHM - 204");
              
         } else if(YearLevel.equals("Third Year Level") && Course.equals("BSHM - Bachelor of Science in Hospitality Management")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSHM - 301");
              ComboSelectClass.addItem("BSHM - 302");
              ComboSelectClass.addItem("BSHM - 303");
              ComboSelectClass.addItem("BSHM - 304");
              
         } else if(YearLevel.equals("Fourth Year Level") && Course.equals("BSHM - Bachelor of Science in Hospitality Management")){
                    
              ComboSelectClass.removeAllItems();
              
              table_number.setText(StudentNumber);
              last_name.setText(StudentLastName);
              first_name.setText(StudentFirstName);
              middle_name.setText(StudentMiddleName);
              year_level.setText(YearLevel);
              sem.setText(Term);
              coursee.setText(Course);
              
              ComboSelectClass.addItem("Select Class Section");
              ComboSelectClass.addItem("BSHM - 401");
              ComboSelectClass.addItem("BSHM - 402");
              ComboSelectClass.addItem("BSHM - 403");
              ComboSelectClass.addItem("BSHM - 404");
              
         } else {
             JOptionPane.showMessageDialog(null, "Unidentified Year or Course!");
         }
                    
                } // While-Loop End
                

                
            } catch (SQLException ex) {
                Logger.getLogger(StudentApplicants.class.getName()).log(Level.SEVERE, null, ex);
            }
       
    }//GEN-LAST:event_SelectClassBtnActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed

        String tableNumber = table_number.getText(); // jlabel
        try {
                
         pst = con.prepareStatement("SELECT * FROM table1 WHERE number = ?");
         pst.setString(1, tableNumber);
         rs = pst.executeQuery();
                
         while(rs.next()){ 
         String StudentNumber = rs.getString(1);          
         String AdmitType = rs.getString(2);              
         String YearLevel = rs.getString(3);              
         String SchoolYear = rs.getString(4);             
         String Term = rs.getString(5);                   
         String Course = rs.getString(6);                 
         String StudentFirstName = rs.getString(7);      
         String StudentLastName = rs.getString(8);     
         String StudentMiddleName = rs.getString(9);    
         String StudentSuffix = rs.getString(10);        
         String StudentGender = rs.getString(11);        
         String StudentStatus = rs.getString(12);       
         String StudentCitezenship = rs.getString(13);   
         String formattedDate = rs.getString(14);      
         String StudentBirthplace = rs.getString(15);    
         String StudentReligion = rs.getString(16);      
         String Block = rs.getString(17);               
         String Street = rs.getString(18);          
         String Subdivision = rs.getString(19);         
         String Baranggay = rs.getString(20);      
         String Municipality = rs.getString(21);         
         String Province = rs.getString(22);          
         String ZipCode = rs.getString(23);             
         String StudentEmailAddress = rs.getString(24);  
         String StudentContactNumber = rs.getString(25); 
         String SchoolType = rs.getString(26);          
         String NameOfSchool = rs.getString(27);        
         String Strand = rs.getString(28);             
         String PreviousSchoolYear = rs.getString(29);  
         String FatherFirstName = rs.getString(30);     
         String FatherLastName = rs.getString(31);    
         String FatherMiddleInitial = rs.getString(32); 
         String FatherSuffix = rs.getString(33);       
         String FatherContactNumber = rs.getString(34);  
         String FatherEmailAddress = rs.getString(35);  
         String FatherOccupation = rs.getString(36);   
         String MotherFirstName = rs.getString(37);      
         String MotherLastName = rs.getString(38);     
         String MotherMiddleInitial = rs.getString(39); 
         String MotherSuffix = rs.getString(40);        
         String MotherContactNumber = rs.getString(41);   
         String MotherEmailAddress = rs.getString(42);    
         String MotherOccupation = rs.getString(43);     
         String GuardianFirstName = rs.getString(44);     
         String GuardianLastName = rs.getString(45);  
         String GuardianMiddleInitial = rs.getString(46);
         String GuardianSuffix = rs.getString(47);      
         String GuardianContactNumber = rs.getString(48); 
         String GuardianEmailAddress = rs.getString(49);  
         String GuardianOccupation = rs.getString(50);   
         String GuardianRelationship = rs.getString(51);  
         Blob StudentPicture = rs.getBlob(52);      
         InputStream InputStream = null;
         
         if (StudentPicture != null) {
            try {
                InputStream = StudentPicture.getBinaryStream();
                BufferedImage image = ImageIO.read(InputStream);
                
            } catch (IOException | SQLException ex) {
                ex.printStackTrace(); // Log the error
            } finally {
                try {
                    if (InputStream != null) {
                        InputStream.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace(); // Handle exception for closing InputStream
                }
            }
        }
         
         

            pst = con.prepareStatement("INSERT INTO school_records (school_id, admit_type, year_level, school_year, semester, student_course, student_firstname, student_lastname, student_middlename, student_suffix, student_gender, student_status, student_citizenship, student_birthdate, student_birthplace, student_religion, student_block, student_street, student_subdivision, student_baranggay, student_municipality, student_province, student_zipcode, student_email, student_contact, previous_schooltype, previous_nameofschool, previous_strand, previous_schoolyear, father_fullname, father_contact, father_email, father_occupation, mother_fullname, mother_contact, mother_email, mother_occupation, guardian_fullname, guardian_contact, guardian_email, guardian_occupation, guardian_relationship, transcript_of_records, good_moral, report_card, miscellaneous_tuition, prelim_tuition, midterm_tuition, prefinals_tuition, finals_tuition, total_tuition, student_section, submit_date, student_picture) "
                    + "                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

            if(TypeOfPayment.getSelectedItem().equals("Select Type of Payment")){
                JOptionPane.showMessageDialog(null, "Please Select Payment!");
                return;
            }
            if(ComboSelectClass.getSelectedItem().equals("Select Class Section") || ComboSelectClass.getSelectedItem().equals("")){
                JOptionPane.showMessageDialog(null, "Please Select Class!");
                return;
            }
            
            Random random = new Random();
            int IDGenerator = 100000 + random.nextInt(900000);
            String GeneratedID = Integer.toString(IDGenerator);

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            String UpdatedDate = formatter.format(new Date());

            String StudentSection = ComboSelectClass.getSelectedItem().toString();
            
            
         pst.setString(1, GeneratedID);
         pst.setString(2, AdmitType);
         pst.setString(3, YearLevel);
         pst.setString(4, SchoolYear);
         pst.setString(5, Term);
         pst.setString(6, Course);
         pst.setString(7, StudentFirstName);
         pst.setString(8, StudentLastName);
         pst.setString(9, StudentMiddleName);
         pst.setString(10, StudentSuffix);
         pst.setString(11, StudentGender);
         pst.setString(12, StudentStatus);
         pst.setString(13, StudentCitezenship);
         pst.setString(14, formattedDate);
         pst.setString(15, StudentBirthplace);
         pst.setString(16, StudentReligion);
         pst.setString(17, Block);
         pst.setString(18, Street);
         pst.setString(19, Subdivision);
         pst.setString(20, Baranggay);
         pst.setString(21, Municipality);
         pst.setString(22, Province);
         pst.setString(23, ZipCode);
         pst.setString(24, StudentEmailAddress);
         pst.setString(25, StudentContactNumber);
         pst.setString(26, SchoolType);
         pst.setString(27, NameOfSchool);
         pst.setString(28, Strand);
         pst.setString(29, PreviousSchoolYear);
         pst.setString(30, FatherFirstName + " " + FatherMiddleInitial + ". " + FatherLastName);
         pst.setString(31, FatherContactNumber);
         pst.setString(32, FatherEmailAddress);
         pst.setString(33, FatherOccupation);
         pst.setString(34, MotherFirstName + " " + MotherMiddleInitial + ". " + MotherLastName);
         pst.setString(35, MotherContactNumber);
         pst.setString(36, MotherEmailAddress);
         pst.setString(37, MotherOccupation);
         pst.setString(38, GuardianFirstName + " " + GuardianMiddleInitial + ". " + GuardianLastName);
         pst.setString(39, GuardianContactNumber);
         pst.setString(40, GuardianEmailAddress);
         pst.setString(41, GuardianOccupation);
         pst.setString(42, GuardianRelationship);
         pst.setString(43, "No Value"); //
         pst.setString(44, "No Value"); //
         pst.setString(45, "No Value"); //
         
         if (coursee.getText().equals("BSTM - Bachelor of Science in Tourism and Management") && year_level.getText().equals("First Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
       
        pst.setInt(46, 0);
        pst.setInt(47, 0);
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 30000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5000);  
        pst.setInt(48, 5000);  
        pst.setInt(49, 5000);
        pst.setInt(50, 5000);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSTM - Bachelor of Science in Tourism and Management") && year_level.getText().equals("Second Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 33000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSTM - Bachelor of Science in Tourism and Management") && year_level.getText().equals("Third Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 35000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSTM - Bachelor of Science in Tourism and Management") && year_level.getText().equals("Fourth Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 40000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 7500);  
        pst.setInt(48, 7500);  
        pst.setInt(49, 7500);
        pst.setInt(50, 7500);
        pst.setInt(51, 0); 
    }
}
         
         if (coursee.getText().equals("BSIT - Bachelor of Science in Information Technology") && year_level.getText().equals("First Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 30000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5000);  
        pst.setInt(48, 5000);  
        pst.setInt(49, 5000);
        pst.setInt(50, 5000);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSIT - Bachelor of Science in Information Technology") && year_level.getText().equals("Second Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 33000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSIT - Bachelor of Science in Information Technology") && year_level.getText().equals("Third Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 35000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSIT - Bachelor of Science in Information Technology") && year_level.getText().equals("Fourth Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 40000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 7500);  
        pst.setInt(48, 7500);  
        pst.setInt(49, 7500);
        pst.setInt(50, 7500);
        pst.setInt(51, 0); 
    }
}
         
          if (coursee.getText().equals("BSA - Bachelor of Science in Accountancy") && year_level.getText().equals("First Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 30000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5000);  
        pst.setInt(48, 5000);  
        pst.setInt(49, 5000);
        pst.setInt(50, 5000);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSA - Bachelor of Science in Accountancy") && year_level.getText().equals("Second Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 33000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSA - Bachelor of Science in Accountancy") && year_level.getText().equals("Third Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 35000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSA - Bachelor of Science in Accountancy") && year_level.getText().equals("Fourth Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 40000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 7500);  
        pst.setInt(48, 7500);  
        pst.setInt(49, 7500);
        pst.setInt(50, 7500);
        pst.setInt(51, 0); 
    }
}
          
           if (coursee.getText().equals("BSCpE - Bachelor of Science in Computer Engineering") && year_level.getText().equals("First Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 30000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5000);  
        pst.setInt(48, 5000);  
        pst.setInt(49, 5000);
        pst.setInt(50, 5000);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSCpE - Bachelor of Science in Computer Engineering") && year_level.getText().equals("Second Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 33000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSCpE - Bachelor of Science in Computer Engineering") && year_level.getText().equals("Third Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 35000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSCpE - Bachelor of Science in Computer Engineering") && year_level.getText().equals("Fourth Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 40000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 7500);  
        pst.setInt(48, 7500);  
        pst.setInt(49, 7500);
        pst.setInt(50, 7500);
        pst.setInt(51, 0); 
    }
}
            if (coursee.getText().equals("BSHM - Bachelor of Science in Hospitality Management") && year_level.getText().equals("First Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 30000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5000);  
        pst.setInt(48, 5000);  
        pst.setInt(49, 5000);
        pst.setInt(50, 5000);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSHM - Bachelor of Science in Hospitality Management") && year_level.getText().equals("Second Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 33000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSHM - Bachelor of Science in Hospitality Management") && year_level.getText().equals("Third Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 35000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 5750);  
        pst.setInt(48, 5750);  
        pst.setInt(49, 5750);
        pst.setInt(50, 5750);
        pst.setInt(51, 0); 
    }
} else if (coursee.getText().equals("BSHM - Bachelor of Science in Hospitality Management") && year_level.getText().equals("Fourth Year Level")) {
    if (TypeOfPayment.getSelectedItem().toString().equals("Full Payment")) {
        pst.setInt(46, 0);
        pst.setInt(47, 0);  
        pst.setInt(48, 0);  
        pst.setInt(49, 0);
        pst.setInt(50, 0);
        pst.setInt(51, 40000); 
    } else if (TypeOfPayment.getSelectedItem().toString().equals("Monthly Payment")) {
        pst.setInt(46, 10000);
        pst.setInt(47, 7500);  
        pst.setInt(48, 7500);  
        pst.setInt(49, 7500);
        pst.setInt(50, 7500);
        pst.setInt(51, 0); 
    }
}

        pst.setString(52, StudentSection);
        pst.setString(53, UpdatedDate); 
        if (StudentPicture != null) {
        pst.setBlob(54, StudentPicture.getBinaryStream()); 
        } else {
        pst.setNull(54, java.sql.Types.BLOB); 
        }
         
        JOptionPane.showMessageDialog(null, "Successfully Transfered!");
        pst.executeUpdate();   

        table_number.setText("");
        last_name.setText("");
        first_name.setText("");
        middle_name.setText("");
        year_level.setText("");
        sem.setText("");
        coursee.setText("");
        
        TypeOfPayment.setSelectedIndex(0);
        ComboSelectClass.setSelectedIndex(-1);
        
        } // While
        pst = con.prepareStatement("DELETE FROM table1 WHERE number = ?");
        pst.setString(1, tableNumber);
        pst.executeUpdate();   
        StudentsApplicantsTable();
        updateRowNumbers();
        StudentsApplicantsTable();

            } catch (SQLException ex) {
                Logger.getLogger(StudentApplicants.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void TypeOfPaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TypeOfPaymentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TypeOfPaymentActionPerformed

    private void ComboSelectClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboSelectClassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboSelectClassActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StudentApplicants().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboSelectClass;
    private javax.swing.JPanel FunctionBtnBox1;
    private javax.swing.JButton SelectClassBtn;
    private javax.swing.JPanel StudentApplicantBox;
    private javax.swing.JTable Table1;
    private javax.swing.JComboBox<String> TypeOfPayment;
    private javax.swing.JTextField coursee;
    private javax.swing.JTextField first_name;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField last_name;
    private javax.swing.JTextField middle_name;
    private javax.swing.JTextField sem;
    private javax.swing.JLabel table_number;
    private javax.swing.JButton txtLogout;
    private javax.swing.JTextField year_level;
    // End of variables declaration//GEN-END:variables
}
