package school.project;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.table.JTableHeader;

public class Login extends javax.swing.JFrame {
    
        Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
        ResultSetMetaData rsmd;
    
        private static final String Dbname = "applicationform";
	private static final String DbDriver = "com.mysql.cj.jdbc.Driver";
	private static final String DbURL = "jdbc:mysql://localhost:3306/" + Dbname;
	private static final String DbUsername = "root";
	private static final String DbPassword = "";
    
        public void SQLconnection(){

         try {
                   Class.forName(DbDriver);
                   con = DriverManager.getConnection(DbURL, DbUsername, DbPassword);
                   System.out.println("Connection successful!");
                   
         } catch (ClassNotFoundException e) {
             
                   System.err.println("JDBC Driver not found: " + e.getMessage());
                   e.printStackTrace();
         } catch (SQLException e) {
             
                   System.err.println("Database connection failed: " + e.getMessage());
                  e.printStackTrace();
         }
         } // SQLconnection END
    
    
    
        public void notVisibleComponents(){
            LoginBox.setVisible(false);
            LoginCloseBtn.setVisible(false);
            LoginErrorMessage.setVisible(false);
        }


    public Login() {
        initComponents();
        SQLconnection();
        notVisibleComponents();
        
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        LoginCloseBtn = new javax.swing.JButton();
        LoginBtn = new javax.swing.JButton();
        LoginBox = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        Username = new javax.swing.JTextField();
        Password = new javax.swing.JPasswordField();
        jButton2 = new javax.swing.JButton();
        PasswordLabel = new javax.swing.JLabel();
        UsernameLabel = new javax.swing.JLabel();
        LoginErrorMessage = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("INPUT FRAME");
        setName("DashboardFrame"); // NOI18N
        setUndecorated(true);
        setResizable(false);

        jPanel5.setBackground(new java.awt.Color(249, 246, 238));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 66, 37));

        jButton10.setBackground(new java.awt.Color(0, 66, 37));
        jButton10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("x");
        jButton10.setBorder(null);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton12.setBackground(new java.awt.Color(0, 66, 37));
        jButton12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("-");
        jButton12.setBorder(null);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 1714, Short.MAX_VALUE)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 30, Short.MAX_VALUE))
        );

        jPanel5.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1800, 60));

        jLabel2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("• Crediting for Transferees");
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 520, 520, 20));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("© 2024 School Admission Management System.  ");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 0, -1, 120));

        jPanel5.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 850, 1800, 120));

        jButton1.setBackground(new java.awt.Color(255, 204, 0));
        jButton1.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Don’t wait—enroll today!  ");
        jButton1.setBorder(null);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 550, 230, 50));

        jLabel3.setFont(new java.awt.Font("Impact", 1, 60)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Your Future, Your Way");
        jPanel5.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 280, -1, -1));

        jLabel5.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Choose from expertly designed programs and start building the future");
        jPanel5.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 380, 520, -1));

        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("you've always dreamed of.");
        jPanel5.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 400, 520, -1));

        jLabel7.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("NEW STUDENTS AND");
        jPanel5.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 440, 520, 20));

        jLabel8.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("TRANSFEREES ACCPETED");
        jPanel5.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 460, 520, 20));

        jLabel10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("• Scholarship Available");
        jPanel5.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 500, 520, 20));

        LoginCloseBtn.setBackground(new java.awt.Color(255, 255, 255));
        LoginCloseBtn.setForeground(new java.awt.Color(153, 153, 153));
        LoginCloseBtn.setText("-");
        LoginCloseBtn.setBorder(null);
        LoginCloseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginCloseBtnActionPerformed(evt);
            }
        });
        jPanel5.add(LoginCloseBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1510, 100, 40, 30));

        LoginBtn.setBackground(new java.awt.Color(255, 255, 255));
        LoginBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/arrow_forward_16dp_FFFFFF_FILL0_wght400_GRAD0_opsz20.png"))); // NOI18N
        LoginBtn.setBorderPainted(false);
        LoginBtn.setContentAreaFilled(false);
        LoginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginBtnActionPerformed(evt);
            }
        });
        jPanel5.add(LoginBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1510, 100, 40, 30));

        LoginBox.setBackground(new java.awt.Color(255, 255, 255));
        LoginBox.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(25, 25, 25));
        jLabel4.setText("LOGIN INTO ACCOUNT");
        LoginBox.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 200, 190, -1));

        Username.setBackground(new java.awt.Color(255, 255, 255));
        Username.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Username.setForeground(new java.awt.Color(51, 51, 51));
        Username.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        LoginBox.add(Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 360, 50));

        Password.setBackground(new java.awt.Color(255, 255, 255));
        Password.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Password.setForeground(new java.awt.Color(51, 51, 51));
        Password.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        LoginBox.add(Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 360, 50));

        jButton2.setBackground(new java.awt.Color(0, 66, 37));
        jButton2.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("LOGIN");
        jButton2.setBorder(null);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        LoginBox.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 450, 360, 50));

        PasswordLabel.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        PasswordLabel.setForeground(new java.awt.Color(204, 204, 204));
        PasswordLabel.setText("Password");
        LoginBox.add(PasswordLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 90, 20));

        UsernameLabel.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        UsernameLabel.setForeground(new java.awt.Color(204, 204, 204));
        UsernameLabel.setText("Username");
        LoginBox.add(UsernameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 90, 20));

        LoginErrorMessage.setBackground(new java.awt.Color(255, 204, 204));
        LoginErrorMessage.setForeground(new java.awt.Color(102, 0, 0));
        LoginErrorMessage.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Bahnschrift", 0, 9)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(102, 0, 0));
        jLabel14.setText("Opps! it seems that you Username or Password is incorrect. Please try again.");
        LoginErrorMessage.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        LoginBox.add(LoginErrorMessage, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, 360, 50));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/462583466_27828866910093434_8179531832153963087_n (2).png"))); // NOI18N
        LoginBox.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 170, 180));

        jPanel5.add(LoginBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 100, 420, 710));

        jLabel11.setFont(new java.awt.Font("Bahnschrift", 3, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 204, 0));
        jLabel11.setText("Your journey to success begins here.");
        jPanel5.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 350, 360, -1));

        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("• No Tuition Fee Increace");
        jPanel5.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 480, 520, 20));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Login Picture.png"))); // NOI18N
        jPanel5.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 1800, 910));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 1800, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        ApplicationForm frame = new ApplicationForm();
        frame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        Login dashboard = new Login();
        this.setState(dashboard.ICONIFIED);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void LoginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginBtnActionPerformed
        // TODO add your handling code here:
        LoginBox.setVisible(true);
        LoginBtn.setVisible(false);
        LoginCloseBtn.setVisible(true);
    }//GEN-LAST:event_LoginBtnActionPerformed

    private void LoginCloseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginCloseBtnActionPerformed
        // TODO add your handling code here:
        LoginBox.setVisible(false);
        LoginBtn.setVisible(true);
        LoginCloseBtn.setVisible(false);
    }//GEN-LAST:event_LoginCloseBtnActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        try {
            if(Username.getText().equals("admin") && Password.getText().equals("admin")){
                Dashboard dashboard = new Dashboard();
                dashboard.setVisible(true);
                dispose();
            } else {
                LoginErrorMessage.setVisible(true);
                UsernameLabel.setForeground(new Color(255,204,204));
                PasswordLabel.setForeground(new Color(255,204,204));
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel LoginBox;
    private javax.swing.JButton LoginBtn;
    private javax.swing.JButton LoginCloseBtn;
    private javax.swing.JPanel LoginErrorMessage;
    private javax.swing.JPasswordField Password;
    private javax.swing.JLabel PasswordLabel;
    private javax.swing.JTextField Username;
    private javax.swing.JLabel UsernameLabel;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    // End of variables declaration//GEN-END:variables
}
