package school.project;
import javax.swing.JOptionPane;

public class ApplicationForm extends javax.swing.JFrame {

    public ApplicationForm() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jComboBox5 = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jComboBox6 = new javax.swing.JComboBox<>();
        jLabel24 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jTextField16 = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jComboBox8 = new javax.swing.JComboBox<>();
        jTextField10 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel30 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jTextField17 = new javax.swing.JTextField();
        jTextField18 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jComboBox7 = new javax.swing.JComboBox<>();
        jComboBox9 = new javax.swing.JComboBox<>();
        jComboBox11 = new javax.swing.JComboBox<>();
        jComboBox12 = new javax.swing.JComboBox<>();
        jLabel33 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField21 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField24 = new javax.swing.JTextField();
        jTextField25 = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jTextField26 = new javax.swing.JTextField();
        jTextField27 = new javax.swing.JTextField();
        jTextField28 = new javax.swing.JTextField();
        jTextField29 = new javax.swing.JTextField();
        jTextField30 = new javax.swing.JTextField();
        jTextField31 = new javax.swing.JTextField();
        jTextField32 = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jTextField33 = new javax.swing.JTextField();
        jTextField34 = new javax.swing.JTextField();
        jTextField35 = new javax.swing.JTextField();
        jTextField36 = new javax.swing.JTextField();
        jTextField37 = new javax.swing.JTextField();
        jTextField38 = new javax.swing.JTextField();
        jTextField39 = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jTextField40 = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("INPUT FRAME");
        setName("DashboardFrame"); // NOI18N
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jComboBox2.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel6.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, 570, 30));

        jLabel3.setBackground(new java.awt.Color(0, 102, 153));
        jLabel3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 153, 153));
        jLabel3.setText("Term");
        jPanel6.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 120, -1, -1));

        jLabel4.setBackground(new java.awt.Color(0, 102, 153));
        jLabel4.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 153));
        jLabel4.setText("Field");
        jPanel6.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jComboBox4.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel6.add(jComboBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 530, 30));

        jComboBox5.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel6.add(jComboBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 70, 570, 30));

        jLabel6.setBackground(new java.awt.Color(0, 102, 153));
        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 153, 153));
        jLabel6.setText("School Year");
        jPanel6.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel7.setBackground(new java.awt.Color(0, 102, 153));
        jLabel7.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 153, 153));
        jLabel7.setText("Year Level");
        jPanel6.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 50, -1, -1));

        jComboBox6.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel6.add(jComboBox6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 530, 30));

        jLabel24.setBackground(new java.awt.Color(0, 102, 153));
        jLabel24.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(153, 153, 153));
        jLabel24.setText("Admit Type");
        jPanel6.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, 20));

        jLabel64.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 0, 0));
        jLabel64.setText("*");
        jPanel6.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 20, -1));

        jLabel66.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 0, 0));
        jLabel66.setText("*");
        jPanel6.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 120, 20, -1));

        jLabel67.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(255, 0, 0));
        jLabel67.setText("*");
        jPanel6.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, 20, -1));

        jLabel68.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 0, 0));
        jLabel68.setText("*");
        jPanel6.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 20, -1));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 1180, 190));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField3.setBackground(new java.awt.Color(255, 255, 255));
        jTextField3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 210, 580, 30));

        jTextField4.setBackground(new java.awt.Color(255, 255, 255));
        jTextField4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, 250, 30));

        jTextField5.setBackground(new java.awt.Color(255, 255, 255));
        jTextField5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 140, 250, 30));

        jLabel1.setBackground(new java.awt.Color(0, 102, 153));
        jLabel1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Birthdate");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 120, -1, -1));

        jLabel11.setBackground(new java.awt.Color(0, 102, 153));
        jLabel11.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(153, 153, 153));
        jLabel11.setText("Citezenship");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 120, -1, -1));

        jLabel12.setBackground(new java.awt.Color(0, 102, 153));
        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 153, 153));
        jLabel12.setText("Last name");
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, -1, -1));

        jLabel13.setBackground(new java.awt.Color(0, 102, 153));
        jLabel13.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 153, 153));
        jLabel13.setText("Middle name");
        jPanel4.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, -1));

        jComboBox3.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel4.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 140, 250, 30));

        jLabel14.setBackground(new java.awt.Color(0, 102, 153));
        jLabel14.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 153, 153));
        jLabel14.setText("First name");
        jPanel4.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel15.setBackground(new java.awt.Color(0, 102, 153));
        jLabel15.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("Religion");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 190, -1, -1));

        jTextField6.setBackground(new java.awt.Color(255, 255, 255));
        jTextField6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 250, 30));

        jLabel16.setBackground(new java.awt.Color(0, 102, 153));
        jLabel16.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(153, 153, 153));
        jLabel16.setText("Status");
        jPanel4.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 120, -1, -1));

        jTextField7.setBackground(new java.awt.Color(255, 255, 255));
        jTextField7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 390, 420, 30));

        jTextField8.setBackground(new java.awt.Color(255, 255, 255));
        jTextField8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 530, 30));

        jLabel17.setBackground(new java.awt.Color(0, 102, 153));
        jLabel17.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(153, 153, 153));
        jLabel17.setText("Zip Code");
        jPanel4.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 370, -1, -1));

        jLabel18.setBackground(new java.awt.Color(0, 102, 153));
        jLabel18.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(153, 153, 153));
        jLabel18.setText("Birthplace");
        jPanel4.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, -1));

        jLabel19.setBackground(new java.awt.Color(0, 102, 153));
        jLabel19.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 51, 153));
        jLabel19.setText("Current Address");
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));

        jLabel20.setBackground(new java.awt.Color(0, 102, 153));
        jLabel20.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 51, 153));
        jLabel20.setText("Student Information");
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel21.setBackground(new java.awt.Color(0, 102, 153));
        jLabel21.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 51, 153));
        jLabel21.setText("Student Information");
        jPanel4.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jTextField11.setBackground(new java.awt.Color(255, 255, 255));
        jTextField11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 320, 240, 30));

        jTextField12.setBackground(new java.awt.Color(255, 255, 255));
        jTextField12.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 320, 250, 30));

        jTextField13.setBackground(new java.awt.Color(255, 255, 255));
        jTextField13.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField13, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 390, 130, 30));

        jTextField14.setBackground(new java.awt.Color(255, 255, 255));
        jTextField14.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(jTextField14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 530, 30));

        jTextField15.setBackground(new java.awt.Color(255, 255, 255));
        jTextField15.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField15ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField15, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 320, 310, 30));

        jLabel22.setBackground(new java.awt.Color(0, 102, 153));
        jLabel22.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(153, 153, 153));
        jLabel22.setText("Gender");
        jPanel4.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel23.setBackground(new java.awt.Color(0, 102, 153));
        jLabel23.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(153, 153, 153));
        jLabel23.setText("Block / Unit");
        jPanel4.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, -1, -1));

        jLabel25.setBackground(new java.awt.Color(0, 102, 153));
        jLabel25.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(153, 153, 153));
        jLabel25.setText("Subdivision/Village/Etc.");
        jPanel4.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 300, -1, -1));

        jLabel26.setBackground(new java.awt.Color(0, 102, 153));
        jLabel26.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(153, 153, 153));
        jLabel26.setText("Baranggay");
        jPanel4.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 300, -1, -1));

        jLabel27.setBackground(new java.awt.Color(0, 102, 153));
        jLabel27.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(153, 153, 153));
        jLabel27.setText("City/Municipality");
        jPanel4.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, -1, -1));

        jLabel28.setBackground(new java.awt.Color(0, 102, 153));
        jLabel28.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(153, 153, 153));
        jLabel28.setText("Province");
        jPanel4.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 370, -1, -1));

        jTextField16.setBackground(new java.awt.Color(255, 255, 255));
        jTextField16.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(jTextField16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 250, 30));

        jLabel29.setBackground(new java.awt.Color(0, 102, 153));
        jLabel29.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(153, 153, 153));
        jLabel29.setText("Street");
        jPanel4.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 300, -1, -1));

        jComboBox8.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel4.add(jComboBox8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 250, 30));

        jTextField10.setBackground(new java.awt.Color(255, 255, 255));
        jTextField10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 250, 30));

        jTextField23.setBackground(new java.awt.Color(255, 255, 255));
        jTextField23.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(jTextField23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 70, 150, 30));

        jLabel65.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(255, 0, 0));
        jLabel65.setText("*");
        jPanel4.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 370, 20, -1));

        jLabel69.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(255, 0, 0));
        jLabel69.setText("*");
        jPanel4.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 20, -1));

        jLabel70.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(255, 0, 0));
        jLabel70.setText("*");
        jPanel4.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 50, 20, -1));

        jLabel71.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(255, 0, 0));
        jLabel71.setText("*");
        jPanel4.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, 20, -1));

        jLabel72.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel72.setForeground(new java.awt.Color(255, 0, 0));
        jLabel72.setText("*");
        jPanel4.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 120, 20, -1));

        jLabel73.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel73.setForeground(new java.awt.Color(255, 0, 0));
        jLabel73.setText("*");
        jPanel4.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 120, 20, -1));

        jLabel74.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel74.setForeground(new java.awt.Color(255, 0, 0));
        jLabel74.setText("*");
        jPanel4.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 20, -1));

        jLabel75.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(255, 0, 0));
        jLabel75.setText("*");
        jPanel4.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, 20, -1));

        jLabel76.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(255, 0, 0));
        jLabel76.setText("*");
        jPanel4.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 190, 20, -1));

        jLabel77.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(255, 0, 0));
        jLabel77.setText("*");
        jPanel4.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 300, 20, -1));

        jLabel78.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(255, 0, 0));
        jLabel78.setText("*");
        jPanel4.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 300, 20, -1));

        jLabel79.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel79.setForeground(new java.awt.Color(255, 0, 0));
        jLabel79.setText("*");
        jPanel4.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 300, 20, -1));

        jLabel81.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel81.setForeground(new java.awt.Color(255, 0, 0));
        jLabel81.setText("*");
        jPanel4.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 300, 20, -1));

        jLabel82.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel82.setForeground(new java.awt.Color(255, 0, 0));
        jLabel82.setText("*");
        jPanel4.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 300, 20, -1));

        jLabel83.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(255, 0, 0));
        jLabel83.setText("*");
        jPanel4.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 370, 20, -1));

        jLabel84.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(255, 0, 0));
        jLabel84.setText("*");
        jPanel4.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 370, 20, -1));

        jDateChooser1.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        jPanel4.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1008, 140, 150, 30));

        jLabel30.setBackground(new java.awt.Color(0, 102, 153));
        jLabel30.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(153, 153, 153));
        jLabel30.setText("Suffix");
        jPanel4.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 50, -1, -1));

        jLabel110.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel110.setForeground(new java.awt.Color(255, 0, 0));
        jLabel110.setText("*");
        jPanel4.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 120, 20, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 290, 1180, 460));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField17.setBackground(new java.awt.Color(255, 255, 255));
        jTextField17.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel3.add(jTextField17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 520, 30));

        jTextField18.setBackground(new java.awt.Color(255, 255, 255));
        jTextField18.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField18ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField18, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 580, 30));

        jLabel31.setBackground(new java.awt.Color(0, 102, 153));
        jLabel31.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(153, 153, 153));
        jLabel31.setText("Contact Number");
        jPanel3.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, -1));

        jLabel8.setBackground(new java.awt.Color(0, 102, 153));
        jLabel8.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 153));
        jLabel8.setText("Contact Details");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel32.setBackground(new java.awt.Color(0, 102, 153));
        jLabel32.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(153, 153, 153));
        jLabel32.setText("Email Address");
        jPanel3.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel85.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel85.setForeground(new java.awt.Color(255, 0, 0));
        jLabel85.setText("*");
        jPanel3.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 20, -1));

        jLabel86.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel86.setForeground(new java.awt.Color(255, 0, 0));
        jLabel86.setText("*");
        jPanel3.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 50, 20, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 770, 1180, 120));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Bahnschrift", 1, 36)); // NOI18N
        jButton1.setForeground(new java.awt.Color(235, 235, 235));
        jButton1.setText("<");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 80, 60, 50));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jComboBox7.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel2.add(jComboBox7, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 70, 360, 30));

        jComboBox9.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel2.add(jComboBox9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 360, 30));

        jComboBox11.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox11.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel2.add(jComboBox11, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 70, 360, 30));

        jComboBox12.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox12.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel2.add(jComboBox12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 360, 30));

        jLabel33.setBackground(new java.awt.Color(0, 102, 153));
        jLabel33.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(153, 153, 153));
        jLabel33.setText("School Type");
        jPanel2.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel35.setBackground(new java.awt.Color(0, 102, 153));
        jLabel35.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(153, 153, 153));
        jLabel35.setText("Strand");
        jPanel2.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 50, -1, -1));

        jLabel36.setBackground(new java.awt.Color(0, 102, 153));
        jLabel36.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(153, 153, 153));
        jLabel36.setText("School Year");
        jPanel2.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel37.setBackground(new java.awt.Color(0, 102, 153));
        jLabel37.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(153, 153, 153));
        jPanel2.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, -1, -1));

        jLabel9.setBackground(new java.awt.Color(0, 102, 153));
        jLabel9.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 51, 153));
        jLabel9.setText("Current / Last School Attended");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel10.setBackground(new java.awt.Color(0, 102, 153));
        jLabel10.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 153));
        jLabel10.setText("Current / Last School Attended");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel38.setBackground(new java.awt.Color(0, 102, 153));
        jLabel38.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(153, 153, 153));
        jLabel38.setText("Name of School");
        jPanel2.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 50, -1, -1));

        jLabel87.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel87.setForeground(new java.awt.Color(255, 0, 0));
        jLabel87.setText("*");
        jPanel2.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 20, -1));

        jLabel88.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel88.setForeground(new java.awt.Color(255, 0, 0));
        jLabel88.setText("*");
        jPanel2.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 50, 20, -1));

        jLabel89.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(255, 0, 0));
        jLabel89.setText("*");
        jPanel2.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 50, 20, -1));

        jLabel90.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel90.setForeground(new java.awt.Color(255, 0, 0));
        jLabel90.setText("*");
        jPanel2.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 20, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 910, 1180, 190));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 102, 153));
        jLabel2.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 153));
        jLabel2.setText("Parent / Guardian Inforamation");
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jTextField9.setBackground(new java.awt.Color(255, 255, 255));
        jTextField9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 170, 250, 30));

        jTextField19.setBackground(new java.awt.Color(255, 255, 255));
        jTextField19.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 250, 30));

        jTextField20.setBackground(new java.awt.Color(255, 255, 255));
        jTextField20.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField20, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 100, 250, 30));

        jTextField21.setBackground(new java.awt.Color(255, 255, 255));
        jTextField21.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 250, 30));

        jTextField22.setBackground(new java.awt.Color(255, 255, 255));
        jTextField22.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField22, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 250, 30));

        jTextField24.setBackground(new java.awt.Color(255, 255, 255));
        jTextField24.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 100, 150, 30));

        jTextField25.setBackground(new java.awt.Color(255, 255, 255));
        jTextField25.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField25ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField25, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, 250, 30));

        jLabel34.setBackground(new java.awt.Color(0, 102, 153));
        jLabel34.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(153, 153, 153));
        jLabel34.setText("Father Suffix");
        jPanel5.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 80, -1, -1));

        jLabel39.setBackground(new java.awt.Color(0, 102, 153));
        jLabel39.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(153, 153, 153));
        jLabel39.setText("* Father Information");
        jPanel5.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel40.setBackground(new java.awt.Color(0, 102, 153));
        jLabel40.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(153, 153, 153));
        jLabel40.setText("Contact Number");
        jPanel5.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        jLabel41.setBackground(new java.awt.Color(0, 102, 153));
        jLabel41.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(153, 153, 153));
        jLabel41.setText("Email Address");
        jPanel5.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, -1, -1));

        jLabel42.setBackground(new java.awt.Color(0, 102, 153));
        jLabel42.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(153, 153, 153));
        jLabel42.setText("Father Last Name");
        jPanel5.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, -1, -1));

        jLabel43.setBackground(new java.awt.Color(0, 102, 153));
        jLabel43.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(153, 153, 153));
        jLabel43.setText("Father Middle Name");
        jPanel5.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 80, -1, -1));

        jLabel44.setBackground(new java.awt.Color(0, 102, 153));
        jLabel44.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(153, 153, 153));
        jLabel44.setText("Occupation");
        jPanel5.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 150, -1, -1));

        jLabel45.setBackground(new java.awt.Color(0, 102, 153));
        jLabel45.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(153, 153, 153));
        jLabel45.setText("Father First Name");
        jPanel5.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jTextField26.setBackground(new java.awt.Color(255, 255, 255));
        jTextField26.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField26ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField26, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 340, 250, 30));

        jTextField27.setBackground(new java.awt.Color(255, 255, 255));
        jTextField27.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 250, 30));

        jTextField28.setBackground(new java.awt.Color(255, 255, 255));
        jTextField28.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField28, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 270, 250, 30));

        jTextField29.setBackground(new java.awt.Color(255, 255, 255));
        jTextField29.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField29ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 250, 30));

        jTextField30.setBackground(new java.awt.Color(255, 255, 255));
        jTextField30.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField30, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 250, 30));

        jTextField31.setBackground(new java.awt.Color(255, 255, 255));
        jTextField31.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField31ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField31, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 270, 150, 30));

        jTextField32.setBackground(new java.awt.Color(255, 255, 255));
        jTextField32.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField32ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField32, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 270, 250, 30));

        jLabel46.setBackground(new java.awt.Color(0, 102, 153));
        jLabel46.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(153, 153, 153));
        jLabel46.setText("Mother Suffix");
        jPanel5.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 250, -1, -1));

        jLabel47.setBackground(new java.awt.Color(0, 102, 153));
        jLabel47.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(153, 153, 153));
        jLabel47.setText("* Father Information");
        jPanel5.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        jLabel48.setBackground(new java.awt.Color(0, 102, 153));
        jLabel48.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(153, 153, 153));
        jLabel48.setText("Contact Number");
        jPanel5.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        jLabel49.setBackground(new java.awt.Color(0, 102, 153));
        jLabel49.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(153, 153, 153));
        jLabel49.setText("Email Address");
        jPanel5.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 320, -1, -1));

        jLabel50.setBackground(new java.awt.Color(0, 102, 153));
        jLabel50.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(153, 153, 153));
        jLabel50.setText("Mother Last Name");
        jPanel5.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 250, -1, -1));

        jLabel51.setBackground(new java.awt.Color(0, 102, 153));
        jLabel51.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(153, 153, 153));
        jLabel51.setText("Mother Middle Name");
        jPanel5.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 250, -1, -1));

        jLabel52.setBackground(new java.awt.Color(0, 102, 153));
        jLabel52.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(153, 153, 153));
        jLabel52.setText("Occupation");
        jPanel5.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 320, -1, -1));

        jLabel53.setBackground(new java.awt.Color(0, 102, 153));
        jLabel53.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(153, 153, 153));
        jLabel53.setText("Mother First Name");
        jPanel5.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        jTextField33.setBackground(new java.awt.Color(255, 255, 255));
        jTextField33.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField33ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField33, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 520, 250, 30));

        jTextField34.setBackground(new java.awt.Color(255, 255, 255));
        jTextField34.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField34ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField34, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 250, 30));

        jTextField35.setBackground(new java.awt.Color(255, 255, 255));
        jTextField35.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField35, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 450, 250, 30));

        jTextField36.setBackground(new java.awt.Color(255, 255, 255));
        jTextField36.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField36, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 250, 30));

        jTextField37.setBackground(new java.awt.Color(255, 255, 255));
        jTextField37.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField37, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 520, 250, 30));

        jTextField38.setBackground(new java.awt.Color(255, 255, 255));
        jTextField38.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField38ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField38, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 520, 150, 30));

        jTextField39.setBackground(new java.awt.Color(255, 255, 255));
        jTextField39.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jTextField39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField39ActionPerformed(evt);
            }
        });
        jPanel5.add(jTextField39, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 450, 250, 30));

        jLabel54.setBackground(new java.awt.Color(0, 102, 153));
        jLabel54.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(153, 153, 153));
        jLabel54.setText("Relationship");
        jPanel5.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 500, -1, -1));

        jLabel55.setBackground(new java.awt.Color(0, 102, 153));
        jLabel55.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(153, 153, 153));
        jLabel55.setText("* Guardian Information");
        jPanel5.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, -1));

        jLabel56.setBackground(new java.awt.Color(0, 102, 153));
        jLabel56.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(153, 153, 153));
        jLabel56.setText("Contact Number");
        jPanel5.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, -1, -1));

        jLabel57.setBackground(new java.awt.Color(0, 102, 153));
        jLabel57.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(153, 153, 153));
        jLabel57.setText("Email Address");
        jPanel5.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 500, -1, -1));

        jLabel58.setBackground(new java.awt.Color(0, 102, 153));
        jLabel58.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(153, 153, 153));
        jLabel58.setText("Guirdian Last Name");
        jPanel5.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 430, -1, -1));

        jLabel59.setBackground(new java.awt.Color(0, 102, 153));
        jLabel59.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(153, 153, 153));
        jLabel59.setText("Guirdian Middle Name");
        jPanel5.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 430, -1, -1));

        jLabel60.setBackground(new java.awt.Color(0, 102, 153));
        jLabel60.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(153, 153, 153));
        jLabel60.setText("Occupation");
        jPanel5.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 500, -1, -1));

        jLabel61.setBackground(new java.awt.Color(0, 102, 153));
        jLabel61.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(153, 153, 153));
        jLabel61.setText("Guirdian First Name");
        jPanel5.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, -1, -1));

        jTextField40.setBackground(new java.awt.Color(255, 255, 255));
        jTextField40.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(jTextField40, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 450, 150, 30));

        jLabel62.setBackground(new java.awt.Color(0, 102, 153));
        jLabel62.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(153, 153, 153));
        jLabel62.setText("Guirdian Suffix");
        jPanel5.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 430, -1, -1));

        jLabel80.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel80.setForeground(new java.awt.Color(255, 0, 0));
        jLabel80.setText("*");
        jPanel5.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 430, 20, -1));

        jLabel91.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel91.setForeground(new java.awt.Color(255, 0, 0));
        jLabel91.setText("*");
        jPanel5.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 20, -1));

        jLabel92.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel92.setForeground(new java.awt.Color(255, 0, 0));
        jLabel92.setText("*");
        jPanel5.add(jLabel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 80, 20, -1));

        jLabel93.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel93.setForeground(new java.awt.Color(255, 0, 0));
        jLabel93.setText("*");
        jPanel5.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 80, 20, -1));

        jLabel94.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel94.setForeground(new java.awt.Color(255, 0, 0));
        jLabel94.setText("*");
        jPanel5.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 20, -1));

        jLabel95.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel95.setForeground(new java.awt.Color(255, 0, 0));
        jLabel95.setText("*");
        jPanel5.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, 20, -1));

        jLabel96.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel96.setForeground(new java.awt.Color(255, 0, 0));
        jLabel96.setText("*");
        jPanel5.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 150, 20, -1));

        jLabel97.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel97.setForeground(new java.awt.Color(255, 0, 0));
        jLabel97.setText("*");
        jPanel5.add(jLabel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 20, -1));

        jLabel98.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel98.setForeground(new java.awt.Color(255, 0, 0));
        jLabel98.setText("*");
        jPanel5.add(jLabel98, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, 20, -1));

        jLabel99.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel99.setForeground(new java.awt.Color(255, 0, 0));
        jLabel99.setText("*");
        jPanel5.add(jLabel99, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, 20, -1));

        jLabel100.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel100.setForeground(new java.awt.Color(255, 0, 0));
        jLabel100.setText("*");
        jPanel5.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 320, 20, -1));

        jLabel101.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel101.setForeground(new java.awt.Color(255, 0, 0));
        jLabel101.setText("*");
        jPanel5.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 320, 20, -1));

        jLabel102.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel102.setForeground(new java.awt.Color(255, 0, 0));
        jLabel102.setText("*");
        jPanel5.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 500, 20, -1));

        jLabel103.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel103.setForeground(new java.awt.Color(255, 0, 0));
        jLabel103.setText("*");
        jPanel5.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 430, 20, -1));

        jLabel104.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel104.setForeground(new java.awt.Color(255, 0, 0));
        jLabel104.setText("*");
        jPanel5.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 500, 30, -1));

        jLabel105.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel105.setForeground(new java.awt.Color(255, 0, 0));
        jLabel105.setText("*");
        jPanel5.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 430, 30, -1));

        jLabel106.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel106.setForeground(new java.awt.Color(255, 0, 0));
        jLabel106.setText("*");
        jPanel5.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 430, 30, -1));

        jLabel107.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel107.setForeground(new java.awt.Color(255, 0, 0));
        jLabel107.setText("*");
        jPanel5.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 500, 30, -1));

        jLabel108.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel108.setForeground(new java.awt.Color(255, 0, 0));
        jLabel108.setText("*");
        jPanel5.add(jLabel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 500, 30, -1));

        jLabel109.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel109.setForeground(new java.awt.Color(255, 0, 0));
        jLabel109.setText("*");
        jPanel5.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 320, 20, -1));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 1120, 1180, 570));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1180, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 1740, 1180, 30));

        jLabel5.setBackground(new java.awt.Color(0, 102, 153));
        jLabel5.setFont(new java.awt.Font("Bahnschrift", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 153));
        jLabel5.setText("Student Application Form");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, -1, -1));

        jButton2.setBackground(new java.awt.Color(0, 102, 153));
        jButton2.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Proceed");
        jButton2.setBorder(null);
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1370, 1710, 120, 30));

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 1800, 910));

        jPanel7.setBackground(new java.awt.Color(0, 51, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1800, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1800, 60));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jTextField18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField18ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jTextField25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField25ActionPerformed

    private void jTextField26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField26ActionPerformed

    private void jTextField32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField32ActionPerformed

    private void jTextField33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField33ActionPerformed

    private void jTextField39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField39ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField39ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTextField31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField31ActionPerformed

    private void jTextField29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField29ActionPerformed

    private void jTextField34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField34ActionPerformed

    private void jTextField38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField38ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField38ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Dashboard dashboard = new Dashboard();
        dashboard.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ApplicationForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox11;
    private javax.swing.JComboBox<String> jComboBox12;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JComboBox<String> jComboBox9;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField35;
    private javax.swing.JTextField jTextField36;
    private javax.swing.JTextField jTextField37;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField40;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
