package school.project;

import java.sql.Statement;
import java.sql.Connection; // Correct JDBC Connection
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

public class ApplicationForm extends javax.swing.JFrame {
    
        Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
        
        private static final String Dbname = "applicationform";
	private static final String DbDriver = "com.mysql.cj.jdbc.Driver";
	private static final String DbURL = "jdbc:mysql://localhost:3306/" + Dbname;
	private static final String DbUsername = "root";
	private static final String DbPassword = "";
        
        public void SQLconnection(){
            
//         try {                
//                Class.forName(DbDriver);
//            try {
//                con = DriverManager.getConnection(DbURL,DbUsername,DbPassword);           
//            } catch (SQLException ex) {
//                Logger.getLogger(ApplicationForm.class.getName()).log(Level.SEVERE, null, ex);
//            }
//     
//            } catch (ClassNotFoundException ex) {
//                Logger.getLogger(ApplicationForm.class.getName()).log(Level.SEVERE, null, ex);
//            }   
         
         try {
                   Class.forName(DbDriver);
                   con = DriverManager.getConnection(DbURL, DbUsername, DbPassword);
                   System.out.println("Connection successful!");
                   
         } catch (ClassNotFoundException e) {
             
                   System.err.println("JDBC Driver not found: " + e.getMessage());
                   e.printStackTrace();
         } catch (SQLException e) {
             
                   System.err.println("Database connection failed: " + e.getMessage());
                  e.printStackTrace();
         }
         } // SQLconnection END
        
        
        
        

    public ApplicationForm() {
        initComponents();
        SQLconnection();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        Course = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        SchoolYear = new javax.swing.JComboBox<>();
        YearLevel = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        AdmitType = new javax.swing.JComboBox<>();
        jLabel24 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        Term = new javax.swing.JComboBox<>();
        jLabel63 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        StudentReligion = new javax.swing.JTextField();
        StudentLastName = new javax.swing.JTextField();
        StudentCitezenship = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        StudentStatus = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        StudentMiddleName = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        Province = new javax.swing.JTextField();
        StudentBirthplace = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        Baranggay = new javax.swing.JTextField();
        Street = new javax.swing.JTextField();
        ZipCode = new javax.swing.JTextField();
        Municipality = new javax.swing.JTextField();
        Subdivision = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        Block = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        StudentGender = new javax.swing.JComboBox<>();
        StudentFirstName = new javax.swing.JTextField();
        StudentSuffix = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        StudentBirthdate = new com.toedter.calendar.JDateChooser();
        jLabel30 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        StudentEmailAddress = new javax.swing.JTextField();
        StudentContactNumber = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        Strand = new javax.swing.JComboBox<>();
        SchoolType = new javax.swing.JComboBox<>();
        PreviousSchoolYear = new javax.swing.JComboBox<>();
        jLabel33 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        NameOfSchool = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        FatherOccupation = new javax.swing.JTextField();
        FatherFirstName = new javax.swing.JTextField();
        FatherLastName = new javax.swing.JTextField();
        FatherContactNumber = new javax.swing.JTextField();
        FatherEmailAddress = new javax.swing.JTextField();
        FatherSuffix = new javax.swing.JTextField();
        FatherMiddleInitial = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        MotherOccupation = new javax.swing.JTextField();
        MotherFirstName = new javax.swing.JTextField();
        MotherLastName = new javax.swing.JTextField();
        MotherContactNumber = new javax.swing.JTextField();
        MotherEmailAddress = new javax.swing.JTextField();
        MotherSuffix = new javax.swing.JTextField();
        MotherMiddleInitial = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        GuirdianOccupation = new javax.swing.JTextField();
        GuirdianFirstName = new javax.swing.JTextField();
        GuirdianLastName = new javax.swing.JTextField();
        GuirdianContactNumber = new javax.swing.JTextField();
        GuirdianEmailAddress = new javax.swing.JTextField();
        GuirdianRelationship = new javax.swing.JTextField();
        GuirdianMiddleInitial = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        GuirdianSuffix = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        DoneBtn = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("INPUT FRAME");
        setName("DashboardFrame"); // NOI18N
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Course.setBackground(new java.awt.Color(255, 255, 255));
        Course.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Course.setForeground(new java.awt.Color(204, 204, 204));
        Course.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Course", "BSIT - Bachelor of Science in Information Technology", "BSTM - Bachelor of Science in Tourism and Management", "BSA - Bachelor of Science in Accountancy", "BSCpE - Bachelor of Science in Computer Engineering", "BSHM - Bachelor of Science in Hospitality Management", " " }));
        jPanel6.add(Course, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, 570, 30));

        jLabel3.setBackground(new java.awt.Color(0, 102, 153));
        jLabel3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 153, 153));
        jLabel3.setText("Course");
        jPanel6.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 120, -1, -1));

        jLabel4.setBackground(new java.awt.Color(0, 102, 153));
        jLabel4.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 66, 37));
        jLabel4.setText("Field");
        jPanel6.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        SchoolYear.setBackground(new java.awt.Color(255, 255, 255));
        SchoolYear.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        SchoolYear.setForeground(new java.awt.Color(204, 204, 204));
        SchoolYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose School Year", "2024-2025" }));
        jPanel6.add(SchoolYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 240, 30));

        YearLevel.setBackground(new java.awt.Color(255, 255, 255));
        YearLevel.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        YearLevel.setForeground(new java.awt.Color(204, 204, 204));
        YearLevel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Year Level", "First Year Level", "Second Year Level", "Third Year Level", "Fourth Year Level" }));
        jPanel6.add(YearLevel, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 70, 570, 30));

        jLabel6.setBackground(new java.awt.Color(0, 102, 153));
        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 153, 153));
        jLabel6.setText("School Year");
        jPanel6.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel7.setBackground(new java.awt.Color(0, 102, 153));
        jLabel7.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 153, 153));
        jLabel7.setText("Year Level");
        jPanel6.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 50, -1, -1));

        AdmitType.setBackground(new java.awt.Color(255, 255, 255));
        AdmitType.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        AdmitType.setForeground(new java.awt.Color(204, 204, 204));
        AdmitType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Admit Type", "New Student", "Transferee" }));
        jPanel6.add(AdmitType, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 530, 30));

        jLabel24.setBackground(new java.awt.Color(0, 102, 153));
        jLabel24.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(153, 153, 153));
        jLabel24.setText("Admit Type");
        jPanel6.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, 20));

        jLabel64.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 0, 0));
        jLabel64.setText("*");
        jPanel6.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 20, -1));

        jLabel66.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 0, 0));
        jLabel66.setText("*");
        jPanel6.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 120, 20, -1));

        jLabel67.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(255, 0, 0));
        jLabel67.setText("*");
        jPanel6.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, 20, -1));

        jLabel68.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 0, 0));
        jLabel68.setText("*");
        jPanel6.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 20, -1));

        Term.setBackground(new java.awt.Color(255, 255, 255));
        Term.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Term.setForeground(new java.awt.Color(204, 204, 204));
        Term.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Term", "First Semester", "Second Semester" }));
        jPanel6.add(Term, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 140, 240, 30));

        jLabel63.setBackground(new java.awt.Color(0, 102, 153));
        jLabel63.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(153, 153, 153));
        jLabel63.setText("Term");
        jPanel6.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 120, -1, -1));

        jLabel111.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel111.setForeground(new java.awt.Color(255, 0, 0));
        jLabel111.setText("*");
        jPanel6.add(jLabel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 120, 20, -1));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 1180, 190));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        StudentReligion.setBackground(new java.awt.Color(255, 255, 255));
        StudentReligion.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentReligion.setForeground(new java.awt.Color(204, 204, 204));
        StudentReligion.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        StudentReligion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentReligionActionPerformed(evt);
            }
        });
        jPanel4.add(StudentReligion, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 210, 580, 30));

        StudentLastName.setBackground(new java.awt.Color(255, 255, 255));
        StudentLastName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentLastName.setForeground(new java.awt.Color(204, 204, 204));
        StudentLastName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        StudentLastName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentLastNameActionPerformed(evt);
            }
        });
        jPanel4.add(StudentLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, 250, 30));

        StudentCitezenship.setBackground(new java.awt.Color(255, 255, 255));
        StudentCitezenship.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentCitezenship.setForeground(new java.awt.Color(204, 204, 204));
        StudentCitezenship.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        StudentCitezenship.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentCitezenshipActionPerformed(evt);
            }
        });
        jPanel4.add(StudentCitezenship, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 140, 250, 30));

        jLabel1.setBackground(new java.awt.Color(0, 102, 153));
        jLabel1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Birthdate");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 120, -1, -1));

        jLabel11.setBackground(new java.awt.Color(0, 102, 153));
        jLabel11.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(153, 153, 153));
        jLabel11.setText("Citezenship");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 120, -1, -1));

        jLabel12.setBackground(new java.awt.Color(0, 102, 153));
        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 153, 153));
        jLabel12.setText("Last name");
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, -1, -1));

        jLabel13.setBackground(new java.awt.Color(0, 102, 153));
        jLabel13.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 153, 153));
        jLabel13.setText("Middle name");
        jPanel4.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, -1));

        StudentStatus.setBackground(new java.awt.Color(255, 255, 255));
        StudentStatus.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentStatus.setForeground(new java.awt.Color(204, 204, 204));
        StudentStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Status", "Single", "Married" }));
        jPanel4.add(StudentStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 140, 250, 30));

        jLabel14.setBackground(new java.awt.Color(0, 102, 153));
        jLabel14.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 153, 153));
        jLabel14.setText("First name");
        jPanel4.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel15.setBackground(new java.awt.Color(0, 102, 153));
        jLabel15.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("Religion");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 190, -1, -1));

        StudentMiddleName.setBackground(new java.awt.Color(255, 255, 255));
        StudentMiddleName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentMiddleName.setForeground(new java.awt.Color(204, 204, 204));
        StudentMiddleName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        StudentMiddleName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentMiddleNameActionPerformed(evt);
            }
        });
        jPanel4.add(StudentMiddleName, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 250, 30));

        jLabel16.setBackground(new java.awt.Color(0, 102, 153));
        jLabel16.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(153, 153, 153));
        jLabel16.setText("Status");
        jPanel4.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 120, -1, -1));

        Province.setBackground(new java.awt.Color(255, 255, 255));
        Province.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Province.setForeground(new java.awt.Color(204, 204, 204));
        Province.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        Province.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProvinceActionPerformed(evt);
            }
        });
        jPanel4.add(Province, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 390, 420, 30));

        StudentBirthplace.setBackground(new java.awt.Color(255, 255, 255));
        StudentBirthplace.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentBirthplace.setForeground(new java.awt.Color(204, 204, 204));
        StudentBirthplace.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        StudentBirthplace.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentBirthplaceActionPerformed(evt);
            }
        });
        jPanel4.add(StudentBirthplace, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 530, 30));

        jLabel17.setBackground(new java.awt.Color(0, 102, 153));
        jLabel17.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(153, 153, 153));
        jLabel17.setText("Zip Code");
        jPanel4.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 370, -1, -1));

        jLabel18.setBackground(new java.awt.Color(0, 102, 153));
        jLabel18.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(153, 153, 153));
        jLabel18.setText("Birthplace");
        jPanel4.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, -1));

        jLabel19.setBackground(new java.awt.Color(0, 102, 153));
        jLabel19.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 66, 37));
        jLabel19.setText("Current Address");
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));

        jLabel20.setBackground(new java.awt.Color(0, 102, 153));
        jLabel20.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 66, 37));
        jLabel20.setText("Student Information");
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel21.setBackground(new java.awt.Color(0, 102, 153));
        jLabel21.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 51, 153));
        jLabel21.setText("Student Information");
        jPanel4.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        Baranggay.setBackground(new java.awt.Color(255, 255, 255));
        Baranggay.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Baranggay.setForeground(new java.awt.Color(204, 204, 204));
        Baranggay.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        Baranggay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BaranggayActionPerformed(evt);
            }
        });
        jPanel4.add(Baranggay, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 320, 240, 30));

        Street.setBackground(new java.awt.Color(255, 255, 255));
        Street.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Street.setForeground(new java.awt.Color(204, 204, 204));
        Street.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(Street, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 320, 250, 30));

        ZipCode.setBackground(new java.awt.Color(255, 255, 255));
        ZipCode.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        ZipCode.setForeground(new java.awt.Color(204, 204, 204));
        ZipCode.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        ZipCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ZipCodeActionPerformed(evt);
            }
        });
        jPanel4.add(ZipCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 390, 130, 30));

        Municipality.setBackground(new java.awt.Color(255, 255, 255));
        Municipality.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Municipality.setForeground(new java.awt.Color(204, 204, 204));
        Municipality.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(Municipality, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 530, 30));

        Subdivision.setBackground(new java.awt.Color(255, 255, 255));
        Subdivision.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Subdivision.setForeground(new java.awt.Color(204, 204, 204));
        Subdivision.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        Subdivision.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubdivisionActionPerformed(evt);
            }
        });
        jPanel4.add(Subdivision, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 320, 310, 30));

        jLabel22.setBackground(new java.awt.Color(0, 102, 153));
        jLabel22.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(153, 153, 153));
        jLabel22.setText("Gender");
        jPanel4.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel23.setBackground(new java.awt.Color(0, 102, 153));
        jLabel23.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(153, 153, 153));
        jLabel23.setText("Block / Unit");
        jPanel4.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, -1, -1));

        jLabel25.setBackground(new java.awt.Color(0, 102, 153));
        jLabel25.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(153, 153, 153));
        jLabel25.setText("Subdivision/Village/Etc.");
        jPanel4.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 300, -1, -1));

        jLabel26.setBackground(new java.awt.Color(0, 102, 153));
        jLabel26.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(153, 153, 153));
        jLabel26.setText("Baranggay");
        jPanel4.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 300, -1, -1));

        jLabel27.setBackground(new java.awt.Color(0, 102, 153));
        jLabel27.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(153, 153, 153));
        jLabel27.setText("City/Municipality");
        jPanel4.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, -1, -1));

        jLabel28.setBackground(new java.awt.Color(0, 102, 153));
        jLabel28.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(153, 153, 153));
        jLabel28.setText("Province");
        jPanel4.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 370, -1, -1));

        Block.setBackground(new java.awt.Color(255, 255, 255));
        Block.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Block.setForeground(new java.awt.Color(204, 204, 204));
        Block.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(Block, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 250, 30));

        jLabel29.setBackground(new java.awt.Color(0, 102, 153));
        jLabel29.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(153, 153, 153));
        jLabel29.setText("Street");
        jPanel4.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 300, -1, -1));

        StudentGender.setBackground(new java.awt.Color(255, 255, 255));
        StudentGender.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentGender.setForeground(new java.awt.Color(204, 204, 204));
        StudentGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Gender", "Male", "Female" }));
        jPanel4.add(StudentGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 250, 30));

        StudentFirstName.setBackground(new java.awt.Color(255, 255, 255));
        StudentFirstName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentFirstName.setForeground(new java.awt.Color(204, 204, 204));
        StudentFirstName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(StudentFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 250, 30));

        StudentSuffix.setBackground(new java.awt.Color(255, 255, 255));
        StudentSuffix.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentSuffix.setForeground(new java.awt.Color(204, 204, 204));
        StudentSuffix.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(StudentSuffix, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 70, 150, 30));

        jLabel65.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(255, 0, 0));
        jLabel65.setText("*");
        jPanel4.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 370, 20, -1));

        jLabel69.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(255, 0, 0));
        jLabel69.setText("*");
        jPanel4.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 20, -1));

        jLabel70.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(255, 0, 0));
        jLabel70.setText("*");
        jPanel4.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 50, 20, -1));

        jLabel71.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(255, 0, 0));
        jLabel71.setText("*");
        jPanel4.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, 20, -1));

        jLabel72.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel72.setForeground(new java.awt.Color(255, 0, 0));
        jLabel72.setText("*");
        jPanel4.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 120, 20, -1));

        jLabel73.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel73.setForeground(new java.awt.Color(255, 0, 0));
        jLabel73.setText("*");
        jPanel4.add(jLabel73, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 120, 20, -1));

        jLabel74.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel74.setForeground(new java.awt.Color(255, 0, 0));
        jLabel74.setText("*");
        jPanel4.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 20, -1));

        jLabel75.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(255, 0, 0));
        jLabel75.setText("*");
        jPanel4.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 190, 20, -1));

        jLabel76.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(255, 0, 0));
        jLabel76.setText("*");
        jPanel4.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 190, 20, -1));

        jLabel77.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(255, 0, 0));
        jLabel77.setText("*");
        jPanel4.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 300, 20, -1));

        jLabel78.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(255, 0, 0));
        jLabel78.setText("*");
        jPanel4.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 300, 20, -1));

        jLabel79.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel79.setForeground(new java.awt.Color(255, 0, 0));
        jLabel79.setText("*");
        jPanel4.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 300, 20, -1));

        jLabel81.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel81.setForeground(new java.awt.Color(255, 0, 0));
        jLabel81.setText("*");
        jPanel4.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 300, 20, -1));

        jLabel82.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel82.setForeground(new java.awt.Color(255, 0, 0));
        jLabel82.setText("*");
        jPanel4.add(jLabel82, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 300, 20, -1));

        jLabel83.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(255, 0, 0));
        jLabel83.setText("*");
        jPanel4.add(jLabel83, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 370, 20, -1));

        jLabel84.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(255, 0, 0));
        jLabel84.setText("*");
        jPanel4.add(jLabel84, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 370, 20, -1));

        StudentBirthdate.setBackground(new java.awt.Color(255, 255, 255));
        StudentBirthdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        StudentBirthdate.setForeground(new java.awt.Color(204, 204, 204));
        jPanel4.add(StudentBirthdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(1008, 140, 150, 30));

        jLabel30.setBackground(new java.awt.Color(0, 102, 153));
        jLabel30.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(153, 153, 153));
        jLabel30.setText("Suffix");
        jPanel4.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 50, -1, -1));

        jLabel110.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel110.setForeground(new java.awt.Color(255, 0, 0));
        jLabel110.setText("*");
        jPanel4.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 120, 20, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 290, 1180, 460));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        StudentEmailAddress.setBackground(new java.awt.Color(255, 255, 255));
        StudentEmailAddress.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentEmailAddress.setForeground(new java.awt.Color(204, 204, 204));
        StudentEmailAddress.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel3.add(StudentEmailAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 520, 30));

        StudentContactNumber.setBackground(new java.awt.Color(255, 255, 255));
        StudentContactNumber.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        StudentContactNumber.setForeground(new java.awt.Color(204, 204, 204));
        StudentContactNumber.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        StudentContactNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentContactNumberActionPerformed(evt);
            }
        });
        jPanel3.add(StudentContactNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 580, 30));

        jLabel31.setBackground(new java.awt.Color(0, 102, 153));
        jLabel31.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(153, 153, 153));
        jLabel31.setText("Contact Number");
        jPanel3.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, -1));

        jLabel8.setBackground(new java.awt.Color(0, 102, 153));
        jLabel8.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 66, 37));
        jLabel8.setText("Contact Details");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel32.setBackground(new java.awt.Color(0, 102, 153));
        jLabel32.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(153, 153, 153));
        jLabel32.setText("Email Address");
        jPanel3.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel85.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel85.setForeground(new java.awt.Color(255, 0, 0));
        jLabel85.setText("*");
        jPanel3.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 20, -1));

        jLabel86.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel86.setForeground(new java.awt.Color(255, 0, 0));
        jLabel86.setText("*");
        jPanel3.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 50, 20, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 770, 1180, 120));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Bahnschrift", 1, 36)); // NOI18N
        jButton1.setForeground(new java.awt.Color(235, 235, 235));
        jButton1.setText("<");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 80, 60, 50));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Strand.setBackground(new java.awt.Color(255, 255, 255));
        Strand.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Strand.setForeground(new java.awt.Color(204, 204, 204));
        Strand.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose Strand", "STEM", "ABM", "HUMSS", "TVL" }));
        jPanel2.add(Strand, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 70, 360, 30));

        SchoolType.setBackground(new java.awt.Color(255, 255, 255));
        SchoolType.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        SchoolType.setForeground(new java.awt.Color(204, 204, 204));
        SchoolType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose School Type", "Senior High School", "College" }));
        jPanel2.add(SchoolType, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 360, 30));

        PreviousSchoolYear.setBackground(new java.awt.Color(255, 255, 255));
        PreviousSchoolYear.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        PreviousSchoolYear.setForeground(new java.awt.Color(204, 204, 204));
        PreviousSchoolYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choose School Year", "2024-2025", "2023-2024", "2022-2023", "2021-2020", "2020-2019", "2019-2020", "2018-2019", "2017-2018", "2016-2017", "2015-2016", "2014-2015", "2013-2014", "2012-2013", "2011-2012", "2010-2011" }));
        jPanel2.add(PreviousSchoolYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 360, 30));

        jLabel33.setBackground(new java.awt.Color(0, 102, 153));
        jLabel33.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(153, 153, 153));
        jLabel33.setText("School Type");
        jPanel2.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel35.setBackground(new java.awt.Color(0, 102, 153));
        jLabel35.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(153, 153, 153));
        jLabel35.setText("Strand");
        jPanel2.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 50, -1, -1));

        jLabel36.setBackground(new java.awt.Color(0, 102, 153));
        jLabel36.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(153, 153, 153));
        jLabel36.setText("School Year");
        jPanel2.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel37.setBackground(new java.awt.Color(0, 102, 153));
        jLabel37.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(153, 153, 153));
        jPanel2.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, -1, -1));

        jLabel9.setBackground(new java.awt.Color(0, 102, 153));
        jLabel9.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 66, 37));
        jLabel9.setText("Current / Last School Attended");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel10.setBackground(new java.awt.Color(0, 102, 153));
        jLabel10.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 153));
        jLabel10.setText("Current / Last School Attended");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel38.setBackground(new java.awt.Color(0, 102, 153));
        jLabel38.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(153, 153, 153));
        jLabel38.setText("Name of School");
        jPanel2.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 50, -1, -1));

        jLabel87.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel87.setForeground(new java.awt.Color(255, 0, 0));
        jLabel87.setText("*");
        jPanel2.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 20, -1));

        jLabel88.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel88.setForeground(new java.awt.Color(255, 0, 0));
        jLabel88.setText("*");
        jPanel2.add(jLabel88, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 50, 20, -1));

        jLabel89.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(255, 0, 0));
        jLabel89.setText("*");
        jPanel2.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 50, 20, -1));

        jLabel90.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel90.setForeground(new java.awt.Color(255, 0, 0));
        jLabel90.setText("*");
        jPanel2.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, 20, -1));

        NameOfSchool.setBackground(new java.awt.Color(255, 255, 255));
        NameOfSchool.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        NameOfSchool.setForeground(new java.awt.Color(204, 204, 204));
        NameOfSchool.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel2.add(NameOfSchool, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 70, 350, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 910, 1180, 190));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 102, 153));
        jLabel2.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 66, 37));
        jLabel2.setText("Parent / Guardian Information");
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        FatherOccupation.setBackground(new java.awt.Color(255, 255, 255));
        FatherOccupation.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        FatherOccupation.setForeground(new java.awt.Color(204, 204, 204));
        FatherOccupation.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        FatherOccupation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FatherOccupationActionPerformed(evt);
            }
        });
        jPanel5.add(FatherOccupation, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 170, 250, 30));

        FatherFirstName.setBackground(new java.awt.Color(255, 255, 255));
        FatherFirstName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        FatherFirstName.setForeground(new java.awt.Color(204, 204, 204));
        FatherFirstName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(FatherFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 250, 30));

        FatherLastName.setBackground(new java.awt.Color(255, 255, 255));
        FatherLastName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        FatherLastName.setForeground(new java.awt.Color(204, 204, 204));
        FatherLastName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(FatherLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 100, 250, 30));

        FatherContactNumber.setBackground(new java.awt.Color(255, 255, 255));
        FatherContactNumber.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        FatherContactNumber.setForeground(new java.awt.Color(204, 204, 204));
        FatherContactNumber.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(FatherContactNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 250, 30));

        FatherEmailAddress.setBackground(new java.awt.Color(255, 255, 255));
        FatherEmailAddress.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        FatherEmailAddress.setForeground(new java.awt.Color(204, 204, 204));
        FatherEmailAddress.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(FatherEmailAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 250, 30));

        FatherSuffix.setBackground(new java.awt.Color(255, 255, 255));
        FatherSuffix.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        FatherSuffix.setForeground(new java.awt.Color(204, 204, 204));
        FatherSuffix.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(FatherSuffix, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 100, 150, 30));

        FatherMiddleInitial.setBackground(new java.awt.Color(255, 255, 255));
        FatherMiddleInitial.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        FatherMiddleInitial.setForeground(new java.awt.Color(204, 204, 204));
        FatherMiddleInitial.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        FatherMiddleInitial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FatherMiddleInitialActionPerformed(evt);
            }
        });
        jPanel5.add(FatherMiddleInitial, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, 250, 30));

        jLabel34.setBackground(new java.awt.Color(0, 102, 153));
        jLabel34.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(153, 153, 153));
        jLabel34.setText("Father Suffix");
        jPanel5.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 80, -1, -1));

        jLabel39.setBackground(new java.awt.Color(0, 102, 153));
        jLabel39.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(153, 153, 153));
        jLabel39.setText("* Father Information");
        jPanel5.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel40.setBackground(new java.awt.Color(0, 102, 153));
        jLabel40.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(153, 153, 153));
        jLabel40.setText("Contact Number");
        jPanel5.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        jLabel41.setBackground(new java.awt.Color(0, 102, 153));
        jLabel41.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(153, 153, 153));
        jLabel41.setText("Email Address");
        jPanel5.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, -1, -1));

        jLabel42.setBackground(new java.awt.Color(0, 102, 153));
        jLabel42.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(153, 153, 153));
        jLabel42.setText("Father Last Name");
        jPanel5.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, -1, -1));

        jLabel43.setBackground(new java.awt.Color(0, 102, 153));
        jLabel43.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(153, 153, 153));
        jLabel43.setText("Father Middle Initial");
        jPanel5.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 80, -1, -1));

        jLabel44.setBackground(new java.awt.Color(0, 102, 153));
        jLabel44.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(153, 153, 153));
        jLabel44.setText("Occupation");
        jPanel5.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 150, -1, -1));

        jLabel45.setBackground(new java.awt.Color(0, 102, 153));
        jLabel45.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(153, 153, 153));
        jLabel45.setText("Father First Name");
        jPanel5.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        MotherOccupation.setBackground(new java.awt.Color(255, 255, 255));
        MotherOccupation.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        MotherOccupation.setForeground(new java.awt.Color(204, 204, 204));
        MotherOccupation.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        MotherOccupation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MotherOccupationActionPerformed(evt);
            }
        });
        jPanel5.add(MotherOccupation, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 340, 250, 30));

        MotherFirstName.setBackground(new java.awt.Color(255, 255, 255));
        MotherFirstName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        MotherFirstName.setForeground(new java.awt.Color(204, 204, 204));
        MotherFirstName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(MotherFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 250, 30));

        MotherLastName.setBackground(new java.awt.Color(255, 255, 255));
        MotherLastName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        MotherLastName.setForeground(new java.awt.Color(204, 204, 204));
        MotherLastName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(MotherLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 270, 250, 30));

        MotherContactNumber.setBackground(new java.awt.Color(255, 255, 255));
        MotherContactNumber.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        MotherContactNumber.setForeground(new java.awt.Color(204, 204, 204));
        MotherContactNumber.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        MotherContactNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MotherContactNumberActionPerformed(evt);
            }
        });
        jPanel5.add(MotherContactNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 250, 30));

        MotherEmailAddress.setBackground(new java.awt.Color(255, 255, 255));
        MotherEmailAddress.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        MotherEmailAddress.setForeground(new java.awt.Color(204, 204, 204));
        MotherEmailAddress.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(MotherEmailAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 250, 30));

        MotherSuffix.setBackground(new java.awt.Color(255, 255, 255));
        MotherSuffix.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        MotherSuffix.setForeground(new java.awt.Color(204, 204, 204));
        MotherSuffix.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        MotherSuffix.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MotherSuffixActionPerformed(evt);
            }
        });
        jPanel5.add(MotherSuffix, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 270, 150, 30));

        MotherMiddleInitial.setBackground(new java.awt.Color(255, 255, 255));
        MotherMiddleInitial.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        MotherMiddleInitial.setForeground(new java.awt.Color(204, 204, 204));
        MotherMiddleInitial.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        MotherMiddleInitial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MotherMiddleInitialActionPerformed(evt);
            }
        });
        jPanel5.add(MotherMiddleInitial, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 270, 250, 30));

        jLabel46.setBackground(new java.awt.Color(0, 102, 153));
        jLabel46.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(153, 153, 153));
        jLabel46.setText("Mother Suffix");
        jPanel5.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 250, -1, -1));

        jLabel47.setBackground(new java.awt.Color(0, 102, 153));
        jLabel47.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(153, 153, 153));
        jLabel47.setText("* Father Information");
        jPanel5.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        jLabel48.setBackground(new java.awt.Color(0, 102, 153));
        jLabel48.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(153, 153, 153));
        jLabel48.setText("Contact Number");
        jPanel5.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        jLabel49.setBackground(new java.awt.Color(0, 102, 153));
        jLabel49.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(153, 153, 153));
        jLabel49.setText("Email Address");
        jPanel5.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 320, -1, -1));

        jLabel50.setBackground(new java.awt.Color(0, 102, 153));
        jLabel50.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(153, 153, 153));
        jLabel50.setText("Mother Last Name");
        jPanel5.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 250, -1, -1));

        jLabel51.setBackground(new java.awt.Color(0, 102, 153));
        jLabel51.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(153, 153, 153));
        jLabel51.setText("Mother Middle initial");
        jPanel5.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 250, -1, -1));

        jLabel52.setBackground(new java.awt.Color(0, 102, 153));
        jLabel52.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(153, 153, 153));
        jLabel52.setText("Occupation");
        jPanel5.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 320, -1, -1));

        jLabel53.setBackground(new java.awt.Color(0, 102, 153));
        jLabel53.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(153, 153, 153));
        jLabel53.setText("Mother First Name");
        jPanel5.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        GuirdianOccupation.setBackground(new java.awt.Color(255, 255, 255));
        GuirdianOccupation.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        GuirdianOccupation.setForeground(new java.awt.Color(204, 204, 204));
        GuirdianOccupation.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        GuirdianOccupation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuirdianOccupationActionPerformed(evt);
            }
        });
        jPanel5.add(GuirdianOccupation, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 520, 250, 30));

        GuirdianFirstName.setBackground(new java.awt.Color(255, 255, 255));
        GuirdianFirstName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        GuirdianFirstName.setForeground(new java.awt.Color(204, 204, 204));
        GuirdianFirstName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        GuirdianFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuirdianFirstNameActionPerformed(evt);
            }
        });
        jPanel5.add(GuirdianFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 250, 30));

        GuirdianLastName.setBackground(new java.awt.Color(255, 255, 255));
        GuirdianLastName.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        GuirdianLastName.setForeground(new java.awt.Color(204, 204, 204));
        GuirdianLastName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(GuirdianLastName, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 450, 250, 30));

        GuirdianContactNumber.setBackground(new java.awt.Color(255, 255, 255));
        GuirdianContactNumber.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        GuirdianContactNumber.setForeground(new java.awt.Color(204, 204, 204));
        GuirdianContactNumber.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(GuirdianContactNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 250, 30));

        GuirdianEmailAddress.setBackground(new java.awt.Color(255, 255, 255));
        GuirdianEmailAddress.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        GuirdianEmailAddress.setForeground(new java.awt.Color(204, 204, 204));
        GuirdianEmailAddress.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(GuirdianEmailAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 520, 250, 30));

        GuirdianRelationship.setBackground(new java.awt.Color(255, 255, 255));
        GuirdianRelationship.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        GuirdianRelationship.setForeground(new java.awt.Color(204, 204, 204));
        GuirdianRelationship.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        GuirdianRelationship.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuirdianRelationshipActionPerformed(evt);
            }
        });
        jPanel5.add(GuirdianRelationship, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 520, 150, 30));

        GuirdianMiddleInitial.setBackground(new java.awt.Color(255, 255, 255));
        GuirdianMiddleInitial.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        GuirdianMiddleInitial.setForeground(new java.awt.Color(204, 204, 204));
        GuirdianMiddleInitial.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        GuirdianMiddleInitial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuirdianMiddleInitialActionPerformed(evt);
            }
        });
        jPanel5.add(GuirdianMiddleInitial, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 450, 250, 30));

        jLabel54.setBackground(new java.awt.Color(0, 102, 153));
        jLabel54.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(153, 153, 153));
        jLabel54.setText("Relationship");
        jPanel5.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 500, -1, -1));

        jLabel55.setBackground(new java.awt.Color(0, 102, 153));
        jLabel55.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(153, 153, 153));
        jLabel55.setText("* Guardian Information");
        jPanel5.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, -1));

        jLabel56.setBackground(new java.awt.Color(0, 102, 153));
        jLabel56.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(153, 153, 153));
        jLabel56.setText("Contact Number");
        jPanel5.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, -1, -1));

        jLabel57.setBackground(new java.awt.Color(0, 102, 153));
        jLabel57.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(153, 153, 153));
        jLabel57.setText("Email Address");
        jPanel5.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 500, -1, -1));

        jLabel58.setBackground(new java.awt.Color(0, 102, 153));
        jLabel58.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(153, 153, 153));
        jLabel58.setText("Guirdian Last Name");
        jPanel5.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 430, -1, -1));

        jLabel59.setBackground(new java.awt.Color(0, 102, 153));
        jLabel59.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(153, 153, 153));
        jLabel59.setText("Guirdian Middle Initial");
        jPanel5.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 430, -1, -1));

        jLabel60.setBackground(new java.awt.Color(0, 102, 153));
        jLabel60.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(153, 153, 153));
        jLabel60.setText("Occupation");
        jPanel5.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 500, -1, -1));

        jLabel61.setBackground(new java.awt.Color(0, 102, 153));
        jLabel61.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(153, 153, 153));
        jLabel61.setText("Guirdian First Name");
        jPanel5.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, -1, -1));

        GuirdianSuffix.setBackground(new java.awt.Color(255, 255, 255));
        GuirdianSuffix.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        GuirdianSuffix.setForeground(new java.awt.Color(204, 204, 204));
        GuirdianSuffix.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(GuirdianSuffix, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 450, 150, 30));

        jLabel62.setBackground(new java.awt.Color(0, 102, 153));
        jLabel62.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(153, 153, 153));
        jLabel62.setText("Guirdian Suffix");
        jPanel5.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 430, -1, -1));

        jLabel80.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel80.setForeground(new java.awt.Color(255, 0, 0));
        jLabel80.setText("*");
        jPanel5.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 430, 20, -1));

        jLabel91.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel91.setForeground(new java.awt.Color(255, 0, 0));
        jLabel91.setText("*");
        jPanel5.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 20, -1));

        jLabel92.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel92.setForeground(new java.awt.Color(255, 0, 0));
        jLabel92.setText("*");
        jPanel5.add(jLabel92, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 80, 20, -1));

        jLabel93.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel93.setForeground(new java.awt.Color(255, 0, 0));
        jLabel93.setText("*");
        jPanel5.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 80, 20, -1));

        jLabel94.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel94.setForeground(new java.awt.Color(255, 0, 0));
        jLabel94.setText("*");
        jPanel5.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 20, -1));

        jLabel95.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel95.setForeground(new java.awt.Color(255, 0, 0));
        jLabel95.setText("*");
        jPanel5.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, 20, -1));

        jLabel96.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel96.setForeground(new java.awt.Color(255, 0, 0));
        jLabel96.setText("*");
        jPanel5.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 150, 20, -1));

        jLabel97.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel97.setForeground(new java.awt.Color(255, 0, 0));
        jLabel97.setText("*");
        jPanel5.add(jLabel97, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 250, 20, -1));

        jLabel98.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel98.setForeground(new java.awt.Color(255, 0, 0));
        jLabel98.setText("*");
        jPanel5.add(jLabel98, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, 20, -1));

        jLabel99.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel99.setForeground(new java.awt.Color(255, 0, 0));
        jLabel99.setText("*");
        jPanel5.add(jLabel99, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, 20, -1));

        jLabel100.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel100.setForeground(new java.awt.Color(255, 0, 0));
        jLabel100.setText("*");
        jPanel5.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 320, 20, -1));

        jLabel101.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel101.setForeground(new java.awt.Color(255, 0, 0));
        jLabel101.setText("*");
        jPanel5.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 320, 20, -1));

        jLabel102.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel102.setForeground(new java.awt.Color(255, 0, 0));
        jLabel102.setText("*");
        jPanel5.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 500, 20, -1));

        jLabel103.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel103.setForeground(new java.awt.Color(255, 0, 0));
        jLabel103.setText("*");
        jPanel5.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 430, 20, -1));

        jLabel104.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel104.setForeground(new java.awt.Color(255, 0, 0));
        jLabel104.setText("*");
        jPanel5.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 500, 30, -1));

        jLabel105.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel105.setForeground(new java.awt.Color(255, 0, 0));
        jLabel105.setText("*");
        jPanel5.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 430, 30, -1));

        jLabel106.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel106.setForeground(new java.awt.Color(255, 0, 0));
        jLabel106.setText("*");
        jPanel5.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 430, 30, -1));

        jLabel107.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel107.setForeground(new java.awt.Color(255, 0, 0));
        jLabel107.setText("*");
        jPanel5.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 500, 30, -1));

        jLabel108.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel108.setForeground(new java.awt.Color(255, 0, 0));
        jLabel108.setText("*");
        jPanel5.add(jLabel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 500, 30, -1));

        jLabel109.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        jLabel109.setForeground(new java.awt.Color(255, 0, 0));
        jLabel109.setText("*");
        jPanel5.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 320, 20, -1));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 1120, 1180, 570));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1180, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 1740, 1180, 30));

        jLabel5.setBackground(new java.awt.Color(0, 102, 153));
        jLabel5.setFont(new java.awt.Font("Bahnschrift", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 153));
        jLabel5.setText("Student Application Form");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, -1, -1));

        DoneBtn.setBackground(new java.awt.Color(0, 66, 37));
        DoneBtn.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        DoneBtn.setForeground(new java.awt.Color(255, 255, 255));
        DoneBtn.setText("Done");
        DoneBtn.setBorder(null);
        DoneBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DoneBtnActionPerformed(evt);
            }
        });
        jPanel1.add(DoneBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1370, 1710, 120, 30));

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 1800, 910));

        jPanel7.setBackground(new java.awt.Color(0, 66, 37));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1800, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1800, 60));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void StudentCitezenshipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentCitezenshipActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentCitezenshipActionPerformed

    private void StudentReligionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentReligionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentReligionActionPerformed

    private void ProvinceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProvinceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProvinceActionPerformed

    private void ZipCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ZipCodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ZipCodeActionPerformed

    private void StudentContactNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentContactNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentContactNumberActionPerformed

    private void FatherOccupationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FatherOccupationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FatherOccupationActionPerformed

    private void FatherMiddleInitialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FatherMiddleInitialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FatherMiddleInitialActionPerformed

    private void MotherOccupationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MotherOccupationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MotherOccupationActionPerformed

    private void MotherMiddleInitialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MotherMiddleInitialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MotherMiddleInitialActionPerformed

    private void GuirdianOccupationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuirdianOccupationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GuirdianOccupationActionPerformed

    private void GuirdianMiddleInitialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuirdianMiddleInitialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GuirdianMiddleInitialActionPerformed

    private void StudentLastNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentLastNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentLastNameActionPerformed

    private void StudentMiddleNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentMiddleNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentMiddleNameActionPerformed

    private void StudentBirthplaceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentBirthplaceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentBirthplaceActionPerformed

    private void SubdivisionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubdivisionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SubdivisionActionPerformed

    private void BaranggayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BaranggayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BaranggayActionPerformed

    private void MotherSuffixActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MotherSuffixActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MotherSuffixActionPerformed

    private void MotherContactNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MotherContactNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MotherContactNumberActionPerformed

    private void GuirdianFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuirdianFirstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GuirdianFirstNameActionPerformed

    private void GuirdianRelationshipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuirdianRelationshipActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GuirdianRelationshipActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Dashboard dashboard = new Dashboard();
        dashboard.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void DoneBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoneBtnActionPerformed

        try {
            pst = con.prepareStatement("INSERT INTO table1(admittype, yearlevel, schoolyear, term, course, studentfirstname, studentlastname, studentmiddlename, studentsuffix, studentgender, studentstatus, studentcitezenship, studentbirthdate, studentbirthplace, studentreligion, block, street, subdivision, baranggay, municipality, province, zipcode, emailaddress, contactnumber, schooltype, nameofschool, strand, previousschoolyear, fatherfirstname, fatherlastname, fathermiddleinitial, fathersuffix, fathercontactnumber, fatheremailaddress, fatheroccupation, motherfirstname, motherlastname, mothermiddleinitial, mothersuffix, mothercontactnumber, motheremailaddress, motheroccupation, guirdianfirstname, guirdianlastname, guirdianmiddleinitial, guirdiansuffix, guirdiancontactnumber, guirdianemailaddress, guirdianoccupation, guirdianrelationship)"
                    + "                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            
            Date date = StudentBirthdate.getDate();
            String formattedDate = null;
            
//            if (date != null) {
//            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//            formattedDate = dateFormat.format(date);
//            }
            
            if(AdmitType.getSelectedItem().toString().equals("Choose Admit Type")){
                JOptionPane.showMessageDialog(null, "Please select Admit Type!");
                
            } else if (YearLevel.getSelectedItem().toString().equals("Choose Year Level")){
                JOptionPane.showMessageDialog(null, "Please select Year Level!");
                
            } else if (SchoolYear.getSelectedItem().toString().equals("Choose School Year")){
                JOptionPane.showMessageDialog(null, "Please select School Year!");
                
            } else if (Term.getSelectedItem().toString().equals("Choose Term")){
                JOptionPane.showMessageDialog(null, "Please select Term!");
                
            } else if (Course.getSelectedItem().toString().equals("Choose Course")){
                JOptionPane.showMessageDialog(null, "Please select Course!");
                
            } else if (StudentFirstName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Student First Name!");
               
            } else if (!StudentFirstName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Student First Name must only contain letters!");
               
            } else if (StudentLastName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Student Last Name!");
               
            } else if (!StudentLastName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Student Last Name must only contain letters!");
               
            } else if (StudentMiddleName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Student Middle Name!");
               
            } else if (!StudentMiddleName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Student Middle Name must only contain letters!");
                  
            } else if (!StudentSuffix.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Student Suffix must only contain letters!");
               
            } else if (StudentGender.getSelectedItem().toString().equals("Choose Gender")){
                JOptionPane.showMessageDialog(null, "Please select Gender!");
                
            } else if (StudentStatus.getSelectedItem().toString().equals("Choose Status")){
                JOptionPane.showMessageDialog(null, "Please select Status!");
                
            } else if (StudentCitezenship.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Student Citizenship!");
               
            } else if (!StudentCitezenship.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Student Citezenship must only contain letters!");
                  
            }  else if (date == null) {
              JOptionPane.showMessageDialog(null, "Please select Birtdate!");
              
            } else if (StudentBirthplace.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Birthplace!");
               
            } else if (!StudentBirthplace.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Birthplace must only contain letters!");
               
            } else if (StudentReligion.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Religion!");
               
            } else if (!StudentReligion.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Religion must only contain letters!");
               
            } else if (Block.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Block/Unit!");
               
            } else if (Street.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Street!");
               
            } else if (Subdivision.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Subdivision!");
               
            } else if (Baranggay.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Baranggay!");
               
            } else if (Municipality.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Municipality!");
               
            }  else if (!Municipality.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Municipality must only contain letters!");
               
            } else if (Province.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Province!");
               
            }  else if (!Province.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Province must only contain letters!");
               
            } else if (ZipCode.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Zip Code!");
               
            }  else if (!ZipCode.getText().matches("\\d{4}")) {
               JOptionPane.showMessageDialog(null, "Zip Code must only contain 4 numbers!");
               
            } else if (StudentEmailAddress.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Email Address!");
               
            } else if (!StudentContactNumber.getText().matches("\\d{11}")) {
               JOptionPane.showMessageDialog(null, "Student Contact Number must only contain 11 numbers!");
               
            } else if(SchoolType.getSelectedItem().toString().equals("Choose School Type")){
                JOptionPane.showMessageDialog(null, "Please select School Type!");
                
            } else if (NameOfSchool.equals("")){
                JOptionPane.showMessageDialog(null, "Please select Name of School!");
                
            } else if (!NameOfSchool.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Name of School must only contain letters!");
               
            } else if (Strand.getSelectedItem().toString().equals("Choose Strand")){
                JOptionPane.showMessageDialog(null, "Please select Strand!");
                
            } else if (PreviousSchoolYear.getSelectedItem().toString().equals("Choose School Year")){
                JOptionPane.showMessageDialog(null, "Please select School Year!");
                
            } else if (FatherFirstName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Father First Name!");
               
            } else if (!FatherFirstName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Student Father Name must only contain letters!");
               
            } else if (FatherLastName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Father Last Name!");
               
            } else if (!FatherLastName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Father Last Name must only contain letters!");
               
            } else if (FatherMiddleInitial.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Father Middle Initial!");
               
            } else if (!FatherMiddleInitial.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Father Middle Initial must only contain letters!");
               
            } else if (!FatherSuffix.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Father Suffix must only contain letters!");
               
            } else if (FatherContactNumber.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Father Contact Number!");
               
            } else if (!FatherContactNumber.getText().matches("\\d{11}")) {
               JOptionPane.showMessageDialog(null, "Father Contact Number must only contain 11 numbers!");
               
            } else if (FatherEmailAddress.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Father Email Address!");
               
            } else if (FatherOccupation.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Father Occupation!");
               
            } else if (!FatherOccupation.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Father Occupation must only contain letters!");
               // last
            } else if (MotherFirstName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Mother First Name!");
               
            } else if (!MotherFirstName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Student Mother Name must only contain letters!");
               
            } else if (MotherLastName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Mother Last Name!");
               
            } else if (!MotherLastName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Mother Last Name must only contain letters!");
               
            } else if (MotherMiddleInitial.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Mother Middle Initial!");
               
            } else if (!MotherMiddleInitial.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Mother Middle Initial must only contain letters!");
               
            } else if (!MotherSuffix.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Mother Suffix must only contain letters!");
               
            } else if (MotherContactNumber.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Mother Contact Number!");
               
            } else if (!MotherContactNumber.getText().matches("\\d{11}")) {
               JOptionPane.showMessageDialog(null, "Mother Contact Number must only contain 11 numbers!");
               
            } else if (MotherEmailAddress.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Mother Email Address!");
               
            } else if (MotherOccupation.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Mother Occupation!");
               
            } else if (!MotherOccupation.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Mother Occupation must only contain letters!");
               // asd
            } else if (GuirdianFirstName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Guirdian First Name!");
               
            } else if (!GuirdianFirstName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Guirdian Name must only contain letters!");
               
            } else if (GuirdianLastName.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Guirdian Last Name!");
               
            } else if (!GuirdianLastName.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Guirdian Last Name must only contain letters!");
               
            } else if (GuirdianMiddleInitial.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Guirdian Middle Initial!");
               
            } else if (!GuirdianMiddleInitial.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Guirdian Middle Initial must only contain letters!");
               
            } else if (!GuirdianSuffix.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Guirdian Suffix must only contain letters!");
               
            } else if (GuirdianContactNumber.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Guirdian Contact Number!");
               
            } else if (!GuirdianContactNumber.getText().matches("\\d{11}")) {
               JOptionPane.showMessageDialog(null, "Guirdian Contact Number must only contain 11 numbers!");
               
            } else if (GuirdianEmailAddress.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Guirdian Email Address!");
               
            } else if (GuirdianOccupation.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Guirdian Occupation!");
               
            } else if (!GuirdianOccupation.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Guirdian Occupation must only contain letters!");
               
            } else if (GuirdianRelationship.getText().equals("")) {
               JOptionPane.showMessageDialog(null, "Please Enter Guirdian Relationship!");
               
            } else if (!GuirdianRelationship.getText().matches("[a-zA-Z]+")) {
               JOptionPane.showMessageDialog(null, "Guirdian Relationship must only contain letters!");
               
            } else {
                
            if (date != null) {
               SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
               formattedDate = dateFormat.format(date);
            
            }
                
            pst.setString(1, AdmitType.getSelectedItem().toString());
            pst.setString(2, YearLevel.getSelectedItem().toString());
            pst.setString(3, SchoolYear.getSelectedItem().toString());
            pst.setString(4, Term.getSelectedItem().toString());
            pst.setString(5, Course.getSelectedItem().toString());

            pst.setString(6, StudentFirstName.getText());
            pst.setString(7, StudentLastName.getText());
            pst.setString(8, StudentMiddleName.getText());
            pst.setString(9, StudentSuffix.getText());
            pst.setString(10, StudentGender.getSelectedItem().toString());
            pst.setString(11, StudentStatus.getSelectedItem().toString());
            pst.setString(12, StudentCitezenship.getText());
            pst.setString(13, formattedDate);
            pst.setString(14, StudentBirthplace.getText());
            pst.setString(15, StudentReligion.getText());

            pst.setString(16, Block.getText());
            pst.setString(17, Street.getText());
            pst.setString(18, Subdivision.getText());
            pst.setString(19, Baranggay.getText());
            pst.setString(20, Municipality.getText());
            pst.setString(21, Province.getText());
            pst.setString(22, ZipCode.getText());

            pst.setString(23, StudentEmailAddress.getText());
            pst.setString(24, StudentContactNumber.getText());

            pst.setString(25, SchoolType.getSelectedItem().toString());
            pst.setString(26, NameOfSchool.getText());
            pst.setString(27, Strand.getSelectedItem().toString());
            pst.setString(28, PreviousSchoolYear.getSelectedItem().toString());

            pst.setString(29, FatherFirstName.getText());
            pst.setString(30, FatherLastName.getText());
            pst.setString(31, FatherMiddleInitial.getText());
            pst.setString(32, FatherSuffix.getText());
            pst.setString(33, FatherContactNumber.getText());
            pst.setString(34, FatherEmailAddress.getText());
            pst.setString(35, FatherOccupation.getText());

            pst.setString(36, MotherFirstName.getText());
            pst.setString(37, MotherLastName.getText());
            pst.setString(38, MotherMiddleInitial.getText());
            pst.setString(39, MotherSuffix.getText());
            pst.setString(40, MotherContactNumber.getText());
            pst.setString(41, MotherEmailAddress.getText());
            pst.setString(42, MotherOccupation.getText());

            pst.setString(43, GuirdianFirstName.getText());
            pst.setString(44, GuirdianLastName.getText());
            pst.setString(45, GuirdianMiddleInitial.getText());
            pst.setString(46, GuirdianSuffix.getText());
            pst.setString(47, GuirdianContactNumber.getText());
            pst.setString(48, GuirdianEmailAddress.getText());
            pst.setString(49, GuirdianOccupation.getText());
            pst.setString(50, GuirdianRelationship.getText());
            
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Inserted new applicant");
            
            setVisible(false);
            ApplicationForm frame = new ApplicationForm();
            frame.setVisible(true);
            
            } // End
            
        } catch (Exception e) {
            e.printStackTrace(); 
        }
    }//GEN-LAST:event_DoneBtnActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ApplicationForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> AdmitType;
    private javax.swing.JTextField Baranggay;
    private javax.swing.JTextField Block;
    private javax.swing.JComboBox<String> Course;
    private javax.swing.JButton DoneBtn;
    private javax.swing.JTextField FatherContactNumber;
    private javax.swing.JTextField FatherEmailAddress;
    private javax.swing.JTextField FatherFirstName;
    private javax.swing.JTextField FatherLastName;
    private javax.swing.JTextField FatherMiddleInitial;
    private javax.swing.JTextField FatherOccupation;
    private javax.swing.JTextField FatherSuffix;
    private javax.swing.JTextField GuirdianContactNumber;
    private javax.swing.JTextField GuirdianEmailAddress;
    private javax.swing.JTextField GuirdianFirstName;
    private javax.swing.JTextField GuirdianLastName;
    private javax.swing.JTextField GuirdianMiddleInitial;
    private javax.swing.JTextField GuirdianOccupation;
    private javax.swing.JTextField GuirdianRelationship;
    private javax.swing.JTextField GuirdianSuffix;
    private javax.swing.JTextField MotherContactNumber;
    private javax.swing.JTextField MotherEmailAddress;
    private javax.swing.JTextField MotherFirstName;
    private javax.swing.JTextField MotherLastName;
    private javax.swing.JTextField MotherMiddleInitial;
    private javax.swing.JTextField MotherOccupation;
    private javax.swing.JTextField MotherSuffix;
    private javax.swing.JTextField Municipality;
    private javax.swing.JTextField NameOfSchool;
    private javax.swing.JComboBox<String> PreviousSchoolYear;
    private javax.swing.JTextField Province;
    private javax.swing.JComboBox<String> SchoolType;
    private javax.swing.JComboBox<String> SchoolYear;
    private javax.swing.JComboBox<String> Strand;
    private javax.swing.JTextField Street;
    private com.toedter.calendar.JDateChooser StudentBirthdate;
    private javax.swing.JTextField StudentBirthplace;
    private javax.swing.JTextField StudentCitezenship;
    private javax.swing.JTextField StudentContactNumber;
    private javax.swing.JTextField StudentEmailAddress;
    private javax.swing.JTextField StudentFirstName;
    private javax.swing.JComboBox<String> StudentGender;
    private javax.swing.JTextField StudentLastName;
    private javax.swing.JTextField StudentMiddleName;
    private javax.swing.JTextField StudentReligion;
    private javax.swing.JComboBox<String> StudentStatus;
    private javax.swing.JTextField StudentSuffix;
    private javax.swing.JTextField Subdivision;
    private javax.swing.JComboBox<String> Term;
    private javax.swing.JComboBox<String> YearLevel;
    private javax.swing.JTextField ZipCode;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
