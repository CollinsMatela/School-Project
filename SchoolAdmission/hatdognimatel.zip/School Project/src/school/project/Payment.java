package school.project;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import javax.swing.table.JTableHeader;

public class Payment extends javax.swing.JFrame {
    
        Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
        ResultSetMetaData rsmd;
    
        private static final String Dbname = "applicationform";
	private static final String DbDriver = "com.mysql.cj.jdbc.Driver";
	private static final String DbURL = "jdbc:mysql://localhost:3306/" + Dbname;
	private static final String DbUsername = "root";
	private static final String DbPassword = "";
    
        public void SQLconnection(){

         try {
                   Class.forName(DbDriver);
                   con = DriverManager.getConnection(DbURL, DbUsername, DbPassword);
                   System.out.println("Connection successful!");
                   
         } catch (ClassNotFoundException e) {
             
                   System.err.println("JDBC Driver not found: " + e.getMessage());
                   e.printStackTrace();
         } catch (SQLException e) {
             
                   System.err.println("Database connection failed: " + e.getMessage());
                  e.printStackTrace();
         }
         } // SQLconnection END
    
    
    


    public Payment() {
        initComponents();
        SQLconnection();
        BalancePanel.setVisible(false);
        Balance_Text.setVisible(false);
        
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        txtLogout = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        txtCourse = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtFullname = new javax.swing.JTextField();
        txtSemester = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        ComboItem = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        AmountText = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        txtYear = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        BalancePanel = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        txtMiscel = new javax.swing.JTextField();
        txtPrelim = new javax.swing.JTextField();
        txtMidterm = new javax.swing.JTextField();
        txtPrefinals = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtFinals = new javax.swing.JTextField();
        School_ID = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        Balance_Text = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("INPUT FRAME");
        setName("DashboardFrame"); // NOI18N
        setUndecorated(true);
        setResizable(false);

        jPanel5.setBackground(new java.awt.Color(249, 246, 238));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 66, 37));

        jButton10.setBackground(new java.awt.Color(0, 66, 37));
        jButton10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("x");
        jButton10.setBorder(null);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton12.setBackground(new java.awt.Color(0, 66, 37));
        jButton12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("-");
        jButton12.setBorder(null);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 1714, Short.MAX_VALUE)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 30, Short.MAX_VALUE))
        );

        jPanel5.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1800, 60));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(153, 153, 153));
        jButton2.setText("Student Records Table");
        jButton2.setBorder(null);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        txtLogout.setBackground(new java.awt.Color(255, 255, 255));
        txtLogout.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtLogout.setForeground(new java.awt.Color(153, 153, 153));
        txtLogout.setText("Logout");
        txtLogout.setBorder(null);
        txtLogout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        txtLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLogoutActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(153, 153, 153));
        jButton3.setText("Dashboard");
        jButton3.setBorder(null);
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(204, 204, 204));
        jButton5.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(153, 153, 153));
        jButton5.setText("Cashier / Payment");
        jButton5.setBorder(null);
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(153, 153, 153));
        jButton4.setText("Student Applicants Table");
        jButton4.setBorder(null);
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(191, 191, 191)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 510, Short.MAX_VALUE)
                .addComponent(txtLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel5.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 970));

        jLabel3.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        jLabel3.setText("Welcome back, Admin!");
        jPanel5.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, -1, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 2));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCourse.setEditable(false);
        txtCourse.setBackground(new java.awt.Color(255, 255, 255));
        txtCourse.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtCourse.setForeground(new java.awt.Color(51, 51, 51));
        txtCourse.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel4.add(txtCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 580, 30));

        jLabel2.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("Semester");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, 110, 30));

        txtFullname.setEditable(false);
        txtFullname.setBackground(new java.awt.Color(255, 255, 255));
        txtFullname.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtFullname.setForeground(new java.awt.Color(51, 51, 51));
        txtFullname.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        txtFullname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFullnameActionPerformed(evt);
            }
        });
        jPanel4.add(txtFullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, 580, 30));

        txtSemester.setEditable(false);
        txtSemester.setBackground(new java.awt.Color(255, 255, 255));
        txtSemester.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtSemester.setForeground(new java.awt.Color(51, 51, 51));
        txtSemester.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        txtSemester.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSemesterActionPerformed(evt);
            }
        });
        jPanel4.add(txtSemester, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 300, 580, 30));

        jLabel5.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 204, 204));
        jLabel5.setText("Student Fullname");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 110, 30));

        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("Course");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 110, 110, 30));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204), 2));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ComboItem.setBackground(new java.awt.Color(255, 255, 255));
        ComboItem.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        ComboItem.setForeground(new java.awt.Color(204, 204, 204));
        ComboItem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Please Select an Item", "Miscellaneous", "Prelim Tuition", "Midterm Tuition", "Pre-Finals Tuition", "Finals Tuition" }));
        ComboItem.setBorder(null);
        jPanel6.add(ComboItem, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 150, 30));

        jLabel4.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("Add Payment");
        jPanel6.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 90, 30));

        AmountText.setBackground(new java.awt.Color(255, 255, 255));
        AmountText.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        AmountText.setForeground(new java.awt.Color(51, 51, 51));
        AmountText.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel6.add(AmountText, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 300, 30));

        jButton7.setBackground(new java.awt.Color(0, 153, 0));
        jButton7.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Pay");
        jButton7.setBorder(null);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 273, 300, 50));

        jPanel4.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 0, 340, 380));

        txtYear.setEditable(false);
        txtYear.setBackground(new java.awt.Color(255, 255, 255));
        txtYear.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtYear.setForeground(new java.awt.Color(51, 51, 51));
        txtYear.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        txtYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtYearActionPerformed(evt);
            }
        });
        jPanel4.add(txtYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 580, 30));

        jLabel7.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setText("Year ");
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 110, 30));

        BalancePanel.setBackground(new java.awt.Color(188, 255, 188));
        BalancePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(153, 153, 153));
        jLabel8.setText("Total Tuition:");
        BalancePanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 90, 30));

        jLabel11.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(153, 153, 153));
        jLabel11.setText("Miscellaneous:");
        BalancePanel.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 90, 30));

        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 153, 153));
        jLabel12.setText("Prelim Tuition:");
        BalancePanel.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 90, 30));

        jLabel13.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 153, 153));
        jLabel13.setText("Midterm Tuition:");
        BalancePanel.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 90, 30));

        jLabel14.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 153, 153));
        jLabel14.setText("Pre-Finals Tuition:");
        BalancePanel.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 110, 30));

        txtTotal.setBackground(new java.awt.Color(188, 255, 188));
        txtTotal.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtTotal.setForeground(new java.awt.Color(153, 153, 153));
        txtTotal.setBorder(null);
        txtTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalActionPerformed(evt);
            }
        });
        BalancePanel.add(txtTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, 150, 30));

        txtMiscel.setBackground(new java.awt.Color(188, 255, 188));
        txtMiscel.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtMiscel.setForeground(new java.awt.Color(153, 153, 153));
        txtMiscel.setBorder(null);
        txtMiscel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMiscelActionPerformed(evt);
            }
        });
        BalancePanel.add(txtMiscel, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, 150, 30));

        txtPrelim.setBackground(new java.awt.Color(188, 255, 188));
        txtPrelim.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtPrelim.setForeground(new java.awt.Color(153, 153, 153));
        txtPrelim.setBorder(null);
        txtPrelim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrelimActionPerformed(evt);
            }
        });
        BalancePanel.add(txtPrelim, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 40, 150, 30));

        txtMidterm.setBackground(new java.awt.Color(188, 255, 188));
        txtMidterm.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtMidterm.setForeground(new java.awt.Color(153, 153, 153));
        txtMidterm.setBorder(null);
        txtMidterm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMidtermActionPerformed(evt);
            }
        });
        BalancePanel.add(txtMidterm, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, 150, 30));

        txtPrefinals.setBackground(new java.awt.Color(188, 255, 188));
        txtPrefinals.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtPrefinals.setForeground(new java.awt.Color(153, 153, 153));
        txtPrefinals.setBorder(null);
        txtPrefinals.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrefinalsActionPerformed(evt);
            }
        });
        BalancePanel.add(txtPrefinals, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 150, 30));

        jLabel15.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("Finals Tuition:");
        BalancePanel.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 90, 30));

        txtFinals.setBackground(new java.awt.Color(188, 255, 188));
        txtFinals.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        txtFinals.setForeground(new java.awt.Color(153, 153, 153));
        txtFinals.setBorder(null);
        txtFinals.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFinalsActionPerformed(evt);
            }
        });
        BalancePanel.add(txtFinals, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 150, 30));

        jPanel4.add(BalancePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 130, 300, 200));

        School_ID.setBackground(new java.awt.Color(255, 255, 255));
        School_ID.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        School_ID.setForeground(new java.awt.Color(51, 51, 51));
        School_ID.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 1, true));
        jPanel4.add(School_ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 60, 260, 30));

        jButton6.setBackground(new java.awt.Color(255, 255, 255));
        jButton6.setText("S");
        jButton6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 60, 40, 30));

        jLabel9.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("School ID");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 30, 60, 30));

        Balance_Text.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        Balance_Text.setForeground(new java.awt.Color(204, 204, 204));
        Balance_Text.setText("Student Balance");
        jPanel4.add(Balance_Text, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 100, 100, 30));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 1470, 380));

        jLabel1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel1.setText("Student Tuition Payment");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 60));

        jPanel5.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 1510, 460));

        jLabel10.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel10.setText("Take a look those newly applicants");
        jPanel5.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 1800, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLogoutActionPerformed
        // TODO add your handling code here:
        Login login = new Login();
        login.setVisible(true);
        dispose();
    }//GEN-LAST:event_txtLogoutActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        
        EnrolledStudents enrolledstudents = new EnrolledStudents();
        enrolledstudents.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        Payment dashboard = new Payment();
        this.setState(dashboard.ICONIFIED);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        Payment frame = new Payment();
        frame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        StudentApplicants frame = new StudentApplicants();
        frame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void txtFullnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFullnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFullnameActionPerformed

    private void txtSemesterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSemesterActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSemesterActionPerformed

    private void txtYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtYearActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtYearActionPerformed

    private void txtTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalActionPerformed

    private void txtMiscelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMiscelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMiscelActionPerformed

    private void txtPrelimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrelimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrelimActionPerformed

    private void txtMidtermActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMidtermActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMidtermActionPerformed

    private void txtPrefinalsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrefinalsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrefinalsActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
           
        if (School_ID.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Please Enter Student School ID!");
        School_ID.setText("");
        return;
    } else if (!School_ID.getText().matches("\\d+")) {
        JOptionPane.showMessageDialog(null, "School ID must contain only numbers!");
        School_ID.setText("");
        return;
    } else if (School_ID.getText().length() != 6) {
        JOptionPane.showMessageDialog(null, "School ID must be exactly 6 digits long!");
        School_ID.setText("");
        return;
    }

    try {
        // Prepare query
        pst = con.prepareStatement("SELECT * FROM school_records WHERE school_id = ?");
        pst.setString(1, School_ID.getText().trim());
        rs = pst.executeQuery();

        // Check if ResultSet is empty
        if (!rs.isBeforeFirst()) {
            JOptionPane.showMessageDialog(null, "No Existing Student School ID!");
            School_ID.setText("");
            return;
        }

        while (rs.next()) {
            String lastname = rs.getString("student_lastname");
            String firstname = rs.getString("student_firstname");
            String middlename = rs.getString("student_middlename");
            String course = rs.getString("student_course");
            String year = rs.getString("year_level");
            String semester = rs.getString("semester");

            int miscel = rs.getInt("miscellaneous_tuition");
            int prelim = rs.getInt("prelim_tuition");
            int midterm = rs.getInt("midterm_tuition");
            int prefinal = rs.getInt("prefinals_tuition");
            int finals = rs.getInt("finals_tuition");
            int total = rs.getInt("total_tuition");

            txtFullname.setText(lastname + " " + firstname + " " + middlename);
            txtCourse.setText(course);
            txtYear.setText(year);
            txtSemester.setText(semester);

            txtMiscel.setText(String.valueOf(miscel));
            txtPrelim.setText(String.valueOf(prelim));
            txtMidterm.setText(String.valueOf(midterm));
            txtPrefinals.setText(String.valueOf(prefinal));
            txtFinals.setText(String.valueOf(finals));
            txtTotal.setText(String.valueOf(total));

            BalancePanel.setVisible(true);
            Balance_Text.setVisible(true);
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        Logger.getLogger(Payment.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void txtFinalsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFinalsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFinalsActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
           try {
    pst = con.prepareStatement("SELECT * FROM school_records WHERE school_id = ?");
    pst.setString(1, School_ID.getText());
    rs = pst.executeQuery();

    if (rs.next()) {
        
        int miscel = rs.getInt("miscellaneous_tuition");
        int prelim = rs.getInt("prelim_tuition");
        int midterm = rs.getInt("midterm_tuition");
        int prefinal = rs.getInt("prefinals_tuition");
        int finals = rs.getInt("finals_tuition");

        int InputValue = Integer.parseInt(AmountText.getText());

        String selectedItem = ComboItem.getSelectedItem().toString();
        int AfterValue = 0;
        String columnToUpdate = null;

        if (selectedItem.equals("Miscellaneous")) {
            AfterValue = miscel - InputValue;
            columnToUpdate = "miscellaneous_tuition";
        } else if (selectedItem.equals("Prelim Tuition")) {
            AfterValue = prelim - InputValue;
            columnToUpdate = "prelim_tuition";
        } else if (selectedItem.equals("Midterm Tuition")) {
            AfterValue = midterm - InputValue;
            columnToUpdate = "midterm_tuition";
        } else if (selectedItem.equals("Pre-Finals Tuition")) {
            AfterValue = prefinal - InputValue;
            columnToUpdate = "prefinals_tuition";
        } else if (selectedItem.equals("Finals Tuition")) {
            AfterValue = finals - InputValue;
            columnToUpdate = "finals_tuition";
        } else {
            JOptionPane.showMessageDialog(null, "Please select a valid item from the dropdown.");
            return;
        }

        if (AfterValue < 0) {
            JOptionPane.showMessageDialog(null, "Error: Payment exceeds the current balance!");
            return;
        }

        pst = con.prepareStatement("UPDATE school_records SET " + columnToUpdate + " = ? WHERE school_id = ?");
        pst.setInt(1, AfterValue);
        pst.setString(2, School_ID.getText());
        int rowsAffected = pst.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, selectedItem + " updated successfully. Remaining balance: " + AfterValue);
            School_ID.setText("");
            AmountText.setText("");
            
            txtFullname.setText("");
            txtCourse.setText("");
            txtYear.setText("");
            txtSemester.setText("");

            txtMiscel.setText(String.valueOf(""));
            txtPrelim.setText(String.valueOf(""));
            txtMidterm.setText(String.valueOf(""));
            txtPrefinals.setText(String.valueOf(""));
            txtFinals.setText(String.valueOf(""));
            txtTotal.setText(String.valueOf(""));

            ComboItem.setSelectedIndex(1);
            BalancePanel.setVisible(false);
            Balance_Text.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(null, "Update failed. No record found.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No record found for the given School ID.");
    }
            
} catch (SQLException ex) {
    Logger.getLogger(Payment.class.getName()).log(Level.SEVERE, null, ex);
    JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(null, "Invalid amount. Please enter a numeric value.");
} finally {
    try {
        if (pst != null) pst.close();
        if (rs != null) rs.close();
    } catch (SQLException ex) {
        Logger.getLogger(Payment.class.getName()).log(Level.SEVERE, null, ex);
    }
}
        
    }//GEN-LAST:event_jButton7ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Payment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AmountText;
    private javax.swing.JPanel BalancePanel;
    private javax.swing.JLabel Balance_Text;
    private javax.swing.JComboBox<String> ComboItem;
    private javax.swing.JTextField School_ID;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JTextField txtCourse;
    private javax.swing.JTextField txtFinals;
    private javax.swing.JTextField txtFullname;
    private javax.swing.JButton txtLogout;
    private javax.swing.JTextField txtMidterm;
    private javax.swing.JTextField txtMiscel;
    private javax.swing.JTextField txtPrefinals;
    private javax.swing.JTextField txtPrelim;
    private javax.swing.JTextField txtSemester;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtYear;
    // End of variables declaration//GEN-END:variables
}
