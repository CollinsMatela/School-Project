
public class Cat extends Pet {
    public Cat(){
        System.out.println("Cat");
    }
    public static void main (String [] args){
        new Pet(5);
    }
}
