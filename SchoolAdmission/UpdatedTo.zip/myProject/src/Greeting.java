import java.util.Scanner;
import java.util.PriorityQueue;

class Greeting {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        PriorityQueue<String> nicknames = new PriorityQueue<String>();

        System.out.println("Enter the nicknames of 4 of your classmates: ");
        for (int i = 0; i < 4; i++) {
            String names = scanner.next();

            nicknames.add(names);
        }
        System.out.println("Press 'H' to say Hi to your classmates. ");
        

        while(!nicknames.isEmpty()){

                    System.out.print(nicknames.peek() + " ");
                    String letter = scanner.next();
                    
                    if(letter.equalsIgnoreCase("H")){
                    System.out.println("Hi " + nicknames.peek() + "! ");
                    nicknames.poll();
                    
                    } else {
                    System.out.println("Invalid input! Press 'P' to Hi.");
                    }
        }
        
        while(nicknames.isEmpty()){
            
                    System.out.println("Done Saying Hi! Queue is empty.");
                    break;
        }
                    
    }
}