import java.util.Scanner;
public class Student {
    // Collins C. Matela
    private String name;
    private int age;
    
    public Student() {
    name = "No name yet!";
    age = 0;    
    }
    public Student(String name, int age){
        this.name = name;
        this.age = age;       
    }
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        
        Student obj = new Student();
        // Gumawa ng object then invoke to display the value from first constructor
        System.out.println("Student Name: " + obj.name + "\n" + "Student Age: " + obj.age + "\n");
        
        System.out.print("Enter student name: ");
        String studentName = scanner.nextLine();
        System.out.print("Enter student age: ");
        int studentAge = scanner.nextInt();
        
        Student obj2 = new Student();
        // Gumawa ng object 2 to store the value from scanner
        // also to differentiate the value of 2 construcor
        obj2.name = studentName;
        obj2.age = studentAge;
        
        System.out.println("                                                         ");
        System.out.println("Result: ");
        System.out.println("Student Name: " + obj2.name + "\n" + "Student Age: " + obj2.age);
  
    }
}
