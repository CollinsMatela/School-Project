
package myproject;

public class OOP {
    
    // Variable for Constructor
    String myCar;
    int carModel;
    
    // Variable for Encapsulation, Setter/Getter
    String name;
    
    
    
    
    // Constructor
    public OOP(String carBrand, int carYear){
        this.myCar = carBrand;
        this.carModel = carYear;
        // Constructor purpose is initializing value/s to variable.
        // Ex. OOP myObj = new OOP("Ferrari", 1986);
        //      System.out.println(myObj.myCar + " " + + myObj.carModel);
    }
    
    // Static Method
    static void StaticMethod(){
        System.out.println("Static methods can be called without creating objects");
        // Ex. StaticMethod() <- This is the way to declare a Static Method.
    }
    
    // Public Method
    public void PublicMethod(){
        System.out.println("Public methods must be called by creating objects");
        // Ex. OOP myObj = new OOP();
        // Ex. myObj.StaticMethod() <- This is the way to declare a Public Method.
    }
    
    // Encapsulation
    public String getName(){
        return name;
    }
    public void setName(String newName){
        this.name = newName;
        //OOP myObj = new OOP();
        //myObj.setName("Collins");
        //System.out.println(myObj.getName()); // Collins
    }
    
    // Inheritance (using extends)
    class Vehicle { // Superclass
        String brand = "Lamborghini";
        
        public void honk(){
            System.out.println("Tuut! Tuuuuut!");
        }
    }
    class Car extends Vehicle{ 
        String model = "Aventador";
        
        // public static void main(String[]args)
        // Car myObj = new Car(); 
        // myObj.honk();
        // System.out.println(myObj.brand + " " + myObj.model);
    }
    
    // Polymorphism
    class Animal {
    public void animalSound() {
    System.out.println("The animal makes a sound");
    }
    }

    class Pig extends Animal {
    public void animalSound() {
    System.out.println("The pig says: wee wee");
    }
    }

    class Dog extends Animal {
    public void animalSound() {
    System.out.println("The dog says: bow wow");
    }
    }
/*
    class Main {
    public static void main(String[] args) {
    Animal myAnimal = new Animal();  // Create a Animal object
    Animal myPig = new Pig();  // Create a Pig object
    Animal myDog = new Dog();  // Create a Dog object
    myAnimal.animalSound();
    myPig.animalSound();
    myDog.animalSound();
  }
}
   */
    
    // Abstraction
    abstract class Animal { 
        animalSound();
        public void sleep(){
         System.out.println("Zzz...");   
        }
    }
        class Dog extends Animal{
            animalSound(){
                System.out.println("Arf..Arf!");
            }
        }
        /*
    class Main {
    public static void main(String[] args) {
    Dog myDog = new Dog();  // Create a Dog object
    myDog.animalSound();
    myDog.sleep();
  }
}
   */
        
     // Interface
        
     // Interface
     interface Animal {
     public void animalSound(); // interface method (does not have a body)
     public void sleep(); // interface method (does not have a body)
}

     // Pig "implements" the Animal interface
    class Pig implements Animal {
    public void animalSound() {
    // The body of animalSound() is provided here
    System.out.println("The pig says: wee wee");
  }
    public void sleep() {
    // The body of sleep() is provided here
    System.out.println("Zzz");
  }
}
    
    
    public static void main(String[]args){

    }
}
