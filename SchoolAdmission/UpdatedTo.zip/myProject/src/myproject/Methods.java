
package myproject;

import java.util.*;
public class Methods {
    
    static void myMethod(){
        System.out.println("This was a example of a method!");
    }
    static void myParameter(String name, int age){
        System.out.println("\n" + name + age);        
    }
    static int myWithReturn(int x, int y){
        return x * y;
    }
    static int OverloadingParameter(int a, int b){
        return a + b;
    }
    
    public static void main(String[] args){
        
        myMethod(); // Simple method
        myParameter("Collins C. Matela", 19); // Parameter with void
        System.out.println(myWithReturn(5, 2)); // Parameter with return value
        
        int variable = OverloadingParameter(5, 5); // Overloading is basically inserting function/method into a VARIABLE.
        System.out.println("Total is " + variable);
        
        
    }
}
