package myproject;

import java.util.Scanner;

public class MyProject{
    
    public void Method(){
        System.out.println("Hell!o");
    }
    public static void main(String[] args){
        
        Method obj = new Method();
 /*       
        Scanner scanner = new Scanner(System.in);
        
        String[] carModel = {"Mclaren","Lamborghini","Masserati","Ferrari","Audi"};
        
        for(int i = 0; i < carModel.length; i++){
            System.out.println(i + ")" + carModel[i]);
        }
        
        int Choose;
        System.out.println("Choose a number you would like to get");
        Choose = scanner.nextInt();
        
        if(Choose == 0){
            System.out.println("Congrats you received " + carModel[0]);
        }
        */
 
    }
}