
public class SavingsAccount {
    
    private double balance;
    public static double interestRate = 0;
    
    public SavingsAccount(){
        this.balance = balance;
        balance = 0;
    }
    
    public static double setInterestRate(double newRate){
        newRate = interestRate;
        return newRate;
    }
    public static double getInterestRate(){
        return interestRate;
    }
    
    public double getBalance(){
       return balance;
    }
    public void deposit(double amount){
        balance += amount;
    }
    public double withdraw(double amount){
        
        if(balance >= amount){
            return balance -= amount;
            
        } else {
            return 0;
        }       
    }
    public void addInterest(){
        balance = balance + (balance * getInterestRate());
    }
    public static void showBalance(SavingsAccount account){
        if(account.getBalance() > 1000){
            account.addInterest();
            System.out.println("Your new Balance is: " + account.getBalance());
        } else {
            System.out.println("Your new Balance is: " + account.getBalance());
        }
    }
    
}

