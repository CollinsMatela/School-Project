import java.util.LinkedList;

public class myLink {
    public static void main(String[] args){
        
        LinkedList MobileApps = new LinkedList();
        
        MobileApps.add("Tiktok");
        MobileApps.add("Facebook");
        MobileApps.add("Instagram");
        MobileApps.add("Youtube");
        
        System.out.println(MobileApps);
        
    }
    
}
