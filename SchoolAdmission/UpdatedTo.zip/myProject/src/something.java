import java.util.*;

public class something {
    Scanner scanner = new Scanner(System.in);  // Use the scanner for input
    
    private int number;  // Variable to store the number

    // Setter method for number
    public void setNum(int number) {
        this.number = number;
    }

    // Getter method for number
    public int getNum() {
        return number;
    }

    // Method to get input and display the number
    public void Display() {
        System.out.println("Enter your number:");
        int num = scanner.nextInt();
        this.setNum(num);  // Set number using the current instance (this)
        System.out.println("The number is: " + this.getNum());
    }

    public static void main(String[] args) {
        something obj = new something();  // Create an instance of the class
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Max number: ");
        int limit = scanner.nextInt();  // Get the limit from the user

        // Loop from 1 to limit
        for (int i = 1; i <= limit; i++) {  // Change condition to <= for inclusive loop
            obj.Display();
        }
    }
}