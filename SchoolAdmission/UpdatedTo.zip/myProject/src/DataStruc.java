
import java.util.LinkedList;

public class DataStruc {
    public static void main (String[] args){
        
        LinkedList songs = new LinkedList();
        
        songs.add("Alumni Homecoming");
        songs.add("Minsan");
        songs.add("Princesa");
        songs.add("Halik");
        songs.add("Bumalik Ka Na'akin");
        
        System.out.println(songs);
        
        LinkedList artist = new LinkedList();
        
        artist.add("Parokya ni Edgar");
        artist.add("Eraserheads");
        artist.add("6cycleminds");
        artist.add("Kamikaze");
        artist.add("Silent Sanctuary");
        
        System.out.println(artist);
        
        String collection1 = songs.get(0) + " - " + artist.get(0);
        String collection2 = songs.get(1) + " - " + artist.get(1);
        String collection3 = songs.get(2) + " - " + artist.get(2);
        String collection4 = songs.get(3) + " - " + artist.get(3);
        String collection5 = songs.get(4) + " - " + artist.get(4);
        
        LinkedList playlist = new LinkedList();
       
        playlist.add(collection1);
        playlist.add(collection2);
        playlist.add(collection3);
        playlist.add(collection4);
        playlist.add(collection5);
        
        System.out.println(playlist.get(0));
        System.out.println(playlist.get(1));
        System.out.println(playlist.get(2));
        System.out.println(playlist.get(3));
        System.out.println(playlist.get(4));
                
    }
}
