
public class Director extends Manager {
    public int stockOptions;
    
    public static void main(String[] args){
     Employee employee = new Employee();
     Manager manager = new Manager();
     Director director = new Director();
     //line n1
     
     employee.salary = 50000;//
     director.salary = 80000;
     employee.budget = 20000;
     manager.budget = 100000;//
     manager.stockOptions = 500;//
     director.stockOptions = 1000;//
     
     
}
}
