import java.util.*;
public class LinearRecursion {
    
    static int showFactorial(int number){
        if(number == 0){     
            return 1;
               
        } else {
            return number * showFactorial(number - 1);
        }
        
    }
    
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter a number to compute the factorial: ");
        int num = scanner.nextInt();
        
        System.out.println("The factorial of " + num + " is " + showFactorial(num));
        
    }
}
