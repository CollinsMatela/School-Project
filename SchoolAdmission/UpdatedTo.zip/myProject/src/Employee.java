
public class Employee {
    public int salary;
}
