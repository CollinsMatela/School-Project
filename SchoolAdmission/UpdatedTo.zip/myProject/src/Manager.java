
public class Manager extends Employee{
    public int budget;
}
