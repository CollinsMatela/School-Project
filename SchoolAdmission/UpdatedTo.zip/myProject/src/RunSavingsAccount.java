import java.util.*;
public class RunSavingsAccount {
    

        public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        SavingsAccount myObj = new SavingsAccount();
        
        System.out.println("Enter the interest Rate: ");
        double intRate = scanner.nextDouble();
        System.out.println("Enter the Deposit Rate: ");
        double depAmount = scanner.nextDouble();
        
        myObj.deposit(depAmount);
        SavingsAccount.setInterestRate(intRate);
        
        System.out.println("Your Balance is " + myObj.getBalance());
        
        
        
        System.out.println("Press D for another deposit or W to withdraw");
        String choice = scanner.next();
        
        
        if(choice.equalsIgnoreCase("D")){
            System.out.println("Please Enter your deposit amount: ");
            myObj.deposit(scanner.nextDouble());
            SavingsAccount.showBalance(myObj);
        } else if (choice.equalsIgnoreCase("W")) {
            System.out.println("Please Enter your withdraw amount: ");
            myObj.withdraw(scanner.nextDouble());
            SavingsAccount.showBalance(myObj);
        } else {
            System.out.println("Invalid Letter! Please try again!");
        }
        
        } // Main Method END Curly Braces
        } // Main Class END Curly Braces