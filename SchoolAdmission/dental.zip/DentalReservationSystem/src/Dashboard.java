/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.*;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
/**
 *
 * @author colli
 */
public class Dashboard extends javax.swing.JFrame {

    // Variable for Connection
    Connection con; // Declaring Connection
    PreparedStatement pst; // Declaring PreparedStatement
    ResultSet rs; // Declaring ResultSet
    ResultSetMetaData rsmd; // Declaring ResultSetMetaData
    Statement st; // Declaring Statement
    
    // MYSQL Syntax for Connection
        private static final String Dbname = "dentalclinic"; // Database Name
	private static final String DbDriver = "com.mysql.cj.jdbc.Driver"; // Driver
	private static final String DbURL = "jdbc:mysql://localhost:3306/" + Dbname; // URL for Connection
	private static final String DbUsername = "root"; // Username
	private static final String DbPassword = ""; // Password
        
        
    public Dashboard() {
        initComponents();
        Theader();
        TableWidth();
        fetchAll();
        
    }
    
    private void Theader(){
        JTableHeader theader = DentalTable.getTableHeader();
        theader.setBackground(new Color(24,25,26));
        theader.setForeground(Color.WHITE);
        theader.setBorder(BorderFactory.createEmptyBorder());
        DentalTable.setIntercellSpacing(new Dimension(0, 0));
        theader.setFont(new Font("Verdana", Font.PLAIN, 11));
        
    }
   
    
    private void fetchAll() {
        try {
					Class.forName(DbDriver); // Used to connect to database
					try {
						con = DriverManager.getConnection(DbURL,DbUsername,DbPassword);// URL,DbName,Username,Pass
						pst = con.prepareStatement("SELECT * from information");
						rs = pst.executeQuery();
						rsmd = rs.getMetaData();
						
						DefaultTableModel model = (DefaultTableModel) DentalTable.getModel();
									
						
						int col = rsmd.getColumnCount();
						String[] colName = new String[col];
						for(int i=0;i<col;i++)
						colName[i]=rsmd.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						
						DentalTable.setModel(model);
						DentalTable.setRowHeight(25);
						
						
						TableColumnModel columnmodel = DentalTable.getColumnModel();
						columnmodel.getColumn(0).setPreferredWidth(10); // ID
						columnmodel.getColumn(1).setPreferredWidth(40); // Last Name
						columnmodel.getColumn(2).setPreferredWidth(40); // First Name
						columnmodel.getColumn(3).setPreferredWidth(10); // Initial
						columnmodel.getColumn(4).setPreferredWidth(10); // Age
						columnmodel.getColumn(5).setPreferredWidth(25); // Gender
						columnmodel.getColumn(6).setPreferredWidth(35); // Contact
						columnmodel.getColumn(7).setPreferredWidth(80); // Email
						columnmodel.getColumn(8).setPreferredWidth(70); // Problem
						columnmodel.getColumn(9).setPreferredWidth(10); // Tooth No.
						columnmodel.getColumn(10).setPreferredWidth(25); // Time
						columnmodel.getColumn(11).setPreferredWidth(25); // Date
						
						
						String ID,Surname,Name,Initial,Age,Gender,Contact,Email,Treatment,Tooth,Time,Date;//no laman
                                                
						while(rs.next()) {
                                                    
							ID = rs.getString(1);
							Surname = rs.getString(2);
							Name = rs.getString(3);
							Initial = rs.getString(4);
							Age = rs.getString(5);
							Gender = rs.getString(6);
							Contact = rs.getString(7);
							Email = rs.getString(8);
							Treatment = rs.getString(9);
							Tooth = rs.getString(10);
							Time = rs.getString(11);
							Date = rs.getString(12);
                                                        
							String[] row = {ID,Surname,Name,Initial,Age,Gender,Contact,Email,Treatment,Tooth,Time,Date};
							model.addRow(row);

							
									
						}
						pst.close();
						con.close();
						
						
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
    }
    
    private void TableWidth(){
        TableColumnModel columnmodel = DentalTable.getColumnModel();
	columnmodel.getColumn(0).setPreferredWidth(10); // ID
	columnmodel.getColumn(1).setPreferredWidth(40); // Last Name
	columnmodel.getColumn(2).setPreferredWidth(40); // First Name
	columnmodel.getColumn(3).setPreferredWidth(10); // Initial
	columnmodel.getColumn(4).setPreferredWidth(10); // Age
	columnmodel.getColumn(5).setPreferredWidth(25); // Gender
	columnmodel.getColumn(6).setPreferredWidth(35); // Contact
	columnmodel.getColumn(7).setPreferredWidth(80); // Email
	columnmodel.getColumn(8).setPreferredWidth(70); // Problem
	columnmodel.getColumn(9).setPreferredWidth(10); // Tooth No.
	columnmodel.getColumn(10).setPreferredWidth(25); // Time
	columnmodel.getColumn(11).setPreferredWidth(25); // Date
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        refreshTable = new javax.swing.JButton();
        showList = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        DentalTable = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        minimizeBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(219, 219, 219));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(24, 25, 26));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Screenshot_2024-04-29_084601-removebg-preview (1).png"))); // NOI18N

        jButton9.setBackground(new java.awt.Color(51, 51, 51));
        jButton9.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/home (1) (1).png"))); // NOI18N
        jButton9.setText("      Home Page");
        jButton9.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        jButton1.setBackground(new java.awt.Color(24, 25, 26));
        jButton1.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/user (1).png"))); // NOI18N
        jButton1.setText("      Reservation");
        jButton1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(24, 25, 26));
        jButton2.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/credit-card (1) (1).png"))); // NOI18N
        jButton2.setText("          Payment");
        jButton2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(24, 25, 26));
        jButton3.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/edit (1).png"))); // NOI18N
        jButton3.setText("           Records");
        jButton3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(24, 25, 26));
        jButton5.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/arrow (2) (1).png"))); // NOI18N
        jButton5.setText("             Logout");
        jButton5.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 135, Short.MAX_VALUE)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 210, 580));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255), new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton6.setBackground(new java.awt.Color(255, 255, 255));
        jButton6.setFont(new java.awt.Font("Arial Black", 0, 10)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 0, 0));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/trash (1).png"))); // NOI18N
        jButton6.setToolTipText("Delete Button");
        jButton6.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 10, 40, 40));

        refreshTable.setBackground(new java.awt.Color(255, 255, 255));
        refreshTable.setFont(new java.awt.Font("Arial Black", 0, 10)); // NOI18N
        refreshTable.setForeground(new java.awt.Color(0, 102, 255));
        refreshTable.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/refresh (1).png"))); // NOI18N
        refreshTable.setToolTipText("Reset Button");
        refreshTable.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        refreshTable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshTableActionPerformed(evt);
            }
        });
        jPanel3.add(refreshTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 40, 40));

        showList.setBackground(new java.awt.Color(255, 255, 255));
        showList.setFont(new java.awt.Font("Arial Black", 0, 10)); // NOI18N
        showList.setForeground(new java.awt.Color(255, 255, 255));
        showList.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/show (1).png"))); // NOI18N
        showList.setToolTipText("Show Button");
        showList.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        showList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showListActionPerformed(evt);
            }
        });
        jPanel3.add(showList, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 10, 40, 40));

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        DentalTable.setBackground(new java.awt.Color(47, 47, 47));
        DentalTable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 51, 51), 1, true));
        DentalTable.setFont(new java.awt.Font("Verdana", 0, 10)); // NOI18N
        DentalTable.setForeground(new java.awt.Color(255, 255, 255));
        DentalTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Surname", "Name", "Initial", "Age", "Gender", "Contact", "Email", "Treatment", "Tooth", "Time", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        DentalTable.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        DentalTable.setSelectionBackground(new java.awt.Color(204, 255, 204));
        DentalTable.setShowGrid(false);
        DentalTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(DentalTable);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 56, 1000, 380));

        jLabel7.setBackground(new java.awt.Color(51, 51, 51));
        jLabel7.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        jLabel7.setText("RESERVATION TABLE");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 1040, 460));

        jLabel3.setBackground(new java.awt.Color(204, 255, 204));
        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 255, 204));
        jLabel3.setText("RESERVATION TABLE");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 300, -1, 70));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(153, 153, 153), new java.awt.Color(153, 153, 153)));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setBackground(new java.awt.Color(51, 51, 51));
        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        jLabel6.setText("DENTAL CLINIC RESERVATION SYSTEM");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, -1, 30));

        minimizeBtn.setBackground(new java.awt.Color(255, 255, 255));
        minimizeBtn.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        minimizeBtn.setForeground(new java.awt.Color(51, 51, 51));
        minimizeBtn.setText("-");
        minimizeBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        minimizeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimizeBtnActionPerformed(evt);
            }
        });
        jPanel4.add(minimizeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 0, 30, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1300, 70));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 575, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        // Opening RESERVATION
        Reservation reservation = new Reservation();
        reservation.setVisible(true);
        reservation.setLocationRelativeTo(null);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       
        // Opening RECORD
        Record record = new Record();
        record.setVisible(true);
        record.setLocationRelativeTo(null);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void showListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showListActionPerformed
        
        try {
					Class.forName(DbDriver); // Used to connect to database
					try {
						con = DriverManager.getConnection(DbURL,DbUsername,DbPassword);// URL,DbName,Username,Pass
						pst = con.prepareStatement("SELECT * from information");
						rs = pst.executeQuery();
						rsmd = rs.getMetaData();
						
//						DefaultTableModel model = (DefaultTableModel) DentalTable.getModel();// continues ung information

                                                DefaultTableModel model = new DefaultTableModel(); // reset
									
						
						int col = rsmd.getColumnCount();
						String[] colName = new String[col];
						for(int i=0;i<col;i++)
						colName[i]=rsmd.getColumnName(i+1);
						model.setColumnIdentifiers(colName);
						
						DentalTable.setModel(model);
						DentalTable.setRowHeight(25);
						
						
						TableColumnModel columnmodel = DentalTable.getColumnModel();
						columnmodel.getColumn(0).setPreferredWidth(10); // ID
						columnmodel.getColumn(1).setPreferredWidth(40); // Last Name
						columnmodel.getColumn(2).setPreferredWidth(40); // First Name
						columnmodel.getColumn(3).setPreferredWidth(10); // Initial
						columnmodel.getColumn(4).setPreferredWidth(10); // Age
						columnmodel.getColumn(5).setPreferredWidth(25); // Gender
						columnmodel.getColumn(6).setPreferredWidth(35); // Contact
						columnmodel.getColumn(7).setPreferredWidth(80); // Email
						columnmodel.getColumn(8).setPreferredWidth(70); // Problem
						columnmodel.getColumn(9).setPreferredWidth(10); // Tooth No.
						columnmodel.getColumn(10).setPreferredWidth(25); // Time
						columnmodel.getColumn(11).setPreferredWidth(25); // Date
						
						
						String ID,Surname,Name,Initial,Age,Gender,Contact,Email,Treatment,Tooth,Time,Date;//no laman
                                                
						while(rs.next()) {
                                                    
							ID = rs.getString(1);
							Surname = rs.getString(2);
							Name = rs.getString(3);
							Initial = rs.getString(4);
							Age = rs.getString(5);
							Gender = rs.getString(6);
							Contact = rs.getString(7);
							Email = rs.getString(8);
							Treatment = rs.getString(9);
							Tooth = rs.getString(10);
							Time = rs.getString(11);
							Date = rs.getString(12);
                                                        
							String[] row = {ID,Surname,Name,Initial,Age,Gender,Contact,Email,Treatment,Tooth,Time,Date};
							model.addRow(row);

							
									
						}
						pst.close();
						con.close();
						
						
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
    }//GEN-LAST:event_showListActionPerformed

    private void refreshTableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshTableActionPerformed
       DefaultTableModel model = (DefaultTableModel) DentalTable.getModel();
		       model.setRowCount(0);
    }//GEN-LAST:event_refreshTableActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        try {
					
					if (con == null || con.isClosed()) { // Sometimes connection get closed automatically
		                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dentalclinic", "root", "");
		            }
                                        
                                    
                                        
    int selectrow = DentalTable.getSelectedRow();

    if (selectrow == -1) {
        JOptionPane.showMessageDialog(null, "Please select a row to delete");
    } else {
        int choose = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the reservation?", "Delete Confirmation", JOptionPane.YES_NO_OPTION);

        if (choose == JOptionPane.YES_OPTION) {
            DefaultTableModel model = (DefaultTableModel) DentalTable.getModel();
            String rowSelected = (String) model.getValueAt(selectrow, 0);
            model.removeRow(selectrow);

            pst = con.prepareStatement("DELETE FROM information WHERE ID = ?");
            pst.setString(1, rowSelected);
            pst.executeUpdate();
        }
    }
    } catch (SQLException e1) {
    e1.printStackTrace();
}
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       
       int choice = JOptionPane.showConfirmDialog(null, "Are you sure logging out?","Confirmation",JOptionPane.YES_NO_OPTION);
 
        if(choice == (JOptionPane.YES_OPTION)) {  
            setVisible(false);
    
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        Payment payment = new Payment();
        payment.setVisible(true);
        payment.setLocationRelativeTo(null);

    }//GEN-LAST:event_jButton2ActionPerformed

    private void minimizeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimizeBtnActionPerformed
        // TODO add your handling code here:
        setState(Dashboard.ICONIFIED);
    }//GEN-LAST:event_minimizeBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable DentalTable;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton minimizeBtn;
    private javax.swing.JButton refreshTable;
    private javax.swing.JButton showList;
    // End of variables declaration//GEN-END:variables
}
