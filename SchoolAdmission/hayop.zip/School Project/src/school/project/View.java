package school.project;

import java.sql.Statement;
import java.sql.Connection; // Correct JDBC Connection
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

public class View extends javax.swing.JFrame {

        Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
        
        private static final String Dbname = "applicationform";
	private static final String DbDriver = "com.mysql.cj.jdbc.Driver";
	private static final String DbURL = "jdbc:mysql://localhost:3306/" + Dbname;
	private static final String DbUsername = "root";
	private static final String DbPassword = "";
        
        public void SQLconnection(){
         
         try {
                   Class.forName(DbDriver);
                   con = DriverManager.getConnection(DbURL, DbUsername, DbPassword);
                   System.out.println("Connection successful!");
                   
         } catch (ClassNotFoundException e) {
             
                   System.err.println("JDBC Driver not found: " + e.getMessage());
                   e.printStackTrace();
         } catch (SQLException e) {
             
                   System.err.println("Database connection failed: " + e.getMessage());
                  e.printStackTrace();
         }
         } // SQLconnection END
        
        
        
        

    public View() {
        initComponents();
        SQLconnection(); 
    }
    
    public View(
        String admitType, String yearLevel, String schoolYear, String term, String course,
        String studentFirstName, String studentLastName, String studentMiddleName,
        String studentSuffix, String studentGender, String studentStatus, String studentCitizenship,
        String formattedDate, String studentBirthplace, String studentReligion,
        String block, String street, String subdivision, String barangay, String municipality,
        String province, String zipCode, String studentEmailAddress, String studentContactNumber,
        String schoolType, String nameOfSchool, String strand, String previousSchoolYear,
        String fatherFirstName, String fatherLastName, String fatherMiddleInitial, String fatherSuffix,
        String fatherContactNumber, String fatherEmailAddress, String fatherOccupation,
        String motherFirstName, String motherLastName, String motherMiddleInitial, String motherSuffix,
        String motherContactNumber, String motherEmailAddress, String motherOccupation,
        String guardianFirstName, String guardianLastName, String guardianMiddleInitial,
        String guardianSuffix, String guardianContactNumber, String guardianEmailAddress,
        String guardianOccupation, String guardianRelationship
    ) {
        initComponents();
        SQLconnection();

        // Populate fields with passed data
        admitTypeField.setText(admitType);
        yearLevelField.setText(yearLevel);
        schoolYearField.setText(schoolYear);
        termField.setText(term);
        courseField.setText(course);

        studentFirstNameField.setText(studentFirstName);
        studentLastNameField.setText(studentLastName);
        studentMiddleNameField.setText(studentMiddleName);
        studentSuffixField.setText(studentSuffix);
        studentGenderField.setText(studentGender);
        studentStatusField.setText(studentStatus);
        studentCitizenshipField.setText(studentCitizenship);
        formattedDateField.setText(formattedDate);
        studentBirthplaceField.setText(studentBirthplace);
        studentReligionField.setText(studentReligion);

        blockField.setText(block);
        streetField.setText(street);
        subdivisionField.setText(subdivision);
        barangayField.setText(barangay);
        municipalityField.setText(municipality);
        provinceField.setText(province);
        zipCodeField.setText(zipCode);

        studentEmailAddressField.setText(studentEmailAddress);
        studentContactNumberField.setText(studentContactNumber);

        schoolTypeField.setText(schoolType);
        nameOfSchoolField.setText(nameOfSchool);
        strandField.setText(strand);
        previousSchoolYearField.setText(previousSchoolYear);

        fatherFirstNameField.setText(fatherFirstName);
        fatherLastNameField.setText(fatherLastName);
        fatherMiddleInitialField.setText(fatherMiddleInitial);
        fatherSuffixField.setText(fatherSuffix);
        fatherContactNumberField.setText(fatherContactNumber);
        fatherEmailAddressField.setText(fatherEmailAddress);
        fatherOccupationField.setText(fatherOccupation);

        motherFirstNameField.setText(motherFirstName);
        motherLastNameField.setText(motherLastName);
        motherMiddleInitialField.setText(motherMiddleInitial);
        motherSuffixField.setText(motherSuffix);
        motherContactNumberField.setText(motherContactNumber);
        motherEmailAddressField.setText(motherEmailAddress);
        motherOccupationField.setText(motherOccupation);

        guardianFirstNameField.setText(guardianFirstName);
        guardianLastNameField.setText(guardianLastName);
        guardianMiddleInitialField.setText(guardianMiddleInitial);
        guardianSuffixField.setText(guardianSuffix);
        guardianContactNumberField.setText(guardianContactNumber);
        guardianEmailAddressField.setText(guardianEmailAddress);
        guardianOccupationField.setText(guardianOccupation);
        guardianRelationshipField.setText(guardianRelationship);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        yearLevelField = new javax.swing.JTextField();
        courseField = new javax.swing.JTextField();
        admitTypeField = new javax.swing.JTextField();
        schoolYearField = new javax.swing.JTextField();
        termField = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        studentReligionField = new javax.swing.JTextField();
        studentLastNameField = new javax.swing.JTextField();
        studentCitizenshipField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        studentMiddleNameField = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        provinceField = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        barangayField = new javax.swing.JTextField();
        streetField = new javax.swing.JTextField();
        zipCodeField = new javax.swing.JTextField();
        municipalityField = new javax.swing.JTextField();
        subdivisionField = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        blockField = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        formattedDateField = new javax.swing.JTextField();
        studentSuffixField = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        studentBirthplaceField = new javax.swing.JTextField();
        studentFirstNameField = new javax.swing.JTextField();
        studentGenderField = new javax.swing.JTextField();
        studentStatusField = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        studentEmailAddressField = new javax.swing.JTextField();
        studentContactNumberField = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        previousSchoolYearField = new javax.swing.JTextField();
        nameOfSchoolField = new javax.swing.JTextField();
        schoolTypeField = new javax.swing.JTextField();
        strandField = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        fatherOccupationField = new javax.swing.JTextField();
        fatherFirstNameField = new javax.swing.JTextField();
        fatherLastNameField = new javax.swing.JTextField();
        fatherContactNumberField = new javax.swing.JTextField();
        fatherEmailAddressField = new javax.swing.JTextField();
        fatherSuffixField = new javax.swing.JTextField();
        fatherMiddleInitialField = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        motherOccupationField = new javax.swing.JTextField();
        motherFirstNameField = new javax.swing.JTextField();
        motherLastNameField = new javax.swing.JTextField();
        motherContactNumberField = new javax.swing.JTextField();
        motherEmailAddressField = new javax.swing.JTextField();
        motherSuffixField = new javax.swing.JTextField();
        motherMiddleInitialField = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        guardianOccupationField = new javax.swing.JTextField();
        guardianFirstNameField = new javax.swing.JTextField();
        guardianLastNameField = new javax.swing.JTextField();
        guardianContactNumberField = new javax.swing.JTextField();
        guardianEmailAddressField = new javax.swing.JTextField();
        guardianRelationshipField = new javax.swing.JTextField();
        guardianMiddleInitialField = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        guardianSuffixField = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("INPUT FRAME");
        setName("DashboardFrame"); // NOI18N
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setPreferredSize(new java.awt.Dimension(1270, 1772));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setMinimumSize(new java.awt.Dimension(1270, 1770));
        jPanel1.setPreferredSize(new java.awt.Dimension(1270, 1770));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setBackground(new java.awt.Color(0, 102, 153));
        jLabel3.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 153, 153));
        jLabel3.setText("Course");
        jPanel6.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 120, -1, -1));

        jLabel4.setBackground(new java.awt.Color(0, 102, 153));
        jLabel4.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 66, 37));
        jLabel4.setText("Field");
        jPanel6.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel6.setBackground(new java.awt.Color(0, 102, 153));
        jLabel6.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(153, 153, 153));
        jLabel6.setText("School Year");
        jPanel6.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel7.setBackground(new java.awt.Color(0, 102, 153));
        jLabel7.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(153, 153, 153));
        jLabel7.setText("Year Level");
        jPanel6.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 50, -1, -1));

        jLabel24.setBackground(new java.awt.Color(0, 102, 153));
        jLabel24.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(153, 153, 153));
        jLabel24.setText("Admit Type");
        jPanel6.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, 20));

        jLabel63.setBackground(new java.awt.Color(0, 102, 153));
        jLabel63.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(153, 153, 153));
        jLabel63.setText("Term");
        jPanel6.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 120, -1, -1));

        yearLevelField.setBackground(new java.awt.Color(255, 255, 255));
        yearLevelField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        yearLevelField.setForeground(new java.awt.Color(204, 204, 204));
        yearLevelField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        yearLevelField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearLevelFieldActionPerformed(evt);
            }
        });
        jPanel6.add(yearLevelField, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 70, 560, 30));

        courseField.setBackground(new java.awt.Color(255, 255, 255));
        courseField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        courseField.setForeground(new java.awt.Color(204, 204, 204));
        courseField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        courseField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseFieldActionPerformed(evt);
            }
        });
        jPanel6.add(courseField, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, 560, 30));

        admitTypeField.setBackground(new java.awt.Color(255, 255, 255));
        admitTypeField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        admitTypeField.setForeground(new java.awt.Color(204, 204, 204));
        admitTypeField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        admitTypeField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                admitTypeFieldActionPerformed(evt);
            }
        });
        jPanel6.add(admitTypeField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 530, 30));

        schoolYearField.setBackground(new java.awt.Color(255, 255, 255));
        schoolYearField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        schoolYearField.setForeground(new java.awt.Color(204, 204, 204));
        schoolYearField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        schoolYearField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                schoolYearFieldActionPerformed(evt);
            }
        });
        jPanel6.add(schoolYearField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 240, 30));

        termField.setBackground(new java.awt.Color(255, 255, 255));
        termField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        termField.setForeground(new java.awt.Color(204, 204, 204));
        termField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        termField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                termFieldActionPerformed(evt);
            }
        });
        jPanel6.add(termField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 140, 240, 30));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 1180, 190));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        studentReligionField.setBackground(new java.awt.Color(255, 255, 255));
        studentReligionField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentReligionField.setForeground(new java.awt.Color(204, 204, 204));
        studentReligionField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        studentReligionField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentReligionFieldActionPerformed(evt);
            }
        });
        jPanel4.add(studentReligionField, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 210, 580, 30));

        studentLastNameField.setBackground(new java.awt.Color(255, 255, 255));
        studentLastNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentLastNameField.setForeground(new java.awt.Color(204, 204, 204));
        studentLastNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        studentLastNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentLastNameFieldActionPerformed(evt);
            }
        });
        jPanel4.add(studentLastNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, 250, 30));

        studentCitizenshipField.setBackground(new java.awt.Color(255, 255, 255));
        studentCitizenshipField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentCitizenshipField.setForeground(new java.awt.Color(204, 204, 204));
        studentCitizenshipField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        studentCitizenshipField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentCitizenshipFieldActionPerformed(evt);
            }
        });
        jPanel4.add(studentCitizenshipField, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 140, 250, 30));

        jLabel1.setBackground(new java.awt.Color(0, 102, 153));
        jLabel1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Birthdate");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 120, -1, -1));

        jLabel11.setBackground(new java.awt.Color(0, 102, 153));
        jLabel11.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(153, 153, 153));
        jLabel11.setText("Citezenship");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 120, -1, -1));

        jLabel12.setBackground(new java.awt.Color(0, 102, 153));
        jLabel12.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 153, 153));
        jLabel12.setText("Last name");
        jPanel4.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, -1, -1));

        jLabel13.setBackground(new java.awt.Color(0, 102, 153));
        jLabel13.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 153, 153));
        jLabel13.setText("Middle name");
        jPanel4.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, -1));

        jLabel14.setBackground(new java.awt.Color(0, 102, 153));
        jLabel14.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 153, 153));
        jLabel14.setText("First name");
        jPanel4.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel15.setBackground(new java.awt.Color(0, 102, 153));
        jLabel15.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("Religion");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 190, -1, -1));

        studentMiddleNameField.setBackground(new java.awt.Color(255, 255, 255));
        studentMiddleNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentMiddleNameField.setForeground(new java.awt.Color(204, 204, 204));
        studentMiddleNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        studentMiddleNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentMiddleNameFieldActionPerformed(evt);
            }
        });
        jPanel4.add(studentMiddleNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 250, 30));

        jLabel16.setBackground(new java.awt.Color(0, 102, 153));
        jLabel16.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(153, 153, 153));
        jLabel16.setText("Status");
        jPanel4.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 120, -1, -1));

        provinceField.setBackground(new java.awt.Color(255, 255, 255));
        provinceField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        provinceField.setForeground(new java.awt.Color(204, 204, 204));
        provinceField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        provinceField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                provinceFieldActionPerformed(evt);
            }
        });
        jPanel4.add(provinceField, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 390, 420, 30));

        jLabel17.setBackground(new java.awt.Color(0, 102, 153));
        jLabel17.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(153, 153, 153));
        jLabel17.setText("Zip Code");
        jPanel4.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 370, -1, -1));

        jLabel18.setBackground(new java.awt.Color(0, 102, 153));
        jLabel18.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(153, 153, 153));
        jLabel18.setText("Birthplace");
        jPanel4.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, -1, -1));

        jLabel19.setBackground(new java.awt.Color(0, 102, 153));
        jLabel19.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 66, 37));
        jLabel19.setText("Current Address");
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));

        jLabel20.setBackground(new java.awt.Color(0, 102, 153));
        jLabel20.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 66, 37));
        jLabel20.setText("Student Information");
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel21.setBackground(new java.awt.Color(0, 102, 153));
        jLabel21.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 51, 153));
        jLabel21.setText("Student Information");
        jPanel4.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        barangayField.setBackground(new java.awt.Color(255, 255, 255));
        barangayField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        barangayField.setForeground(new java.awt.Color(204, 204, 204));
        barangayField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        barangayField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                barangayFieldActionPerformed(evt);
            }
        });
        jPanel4.add(barangayField, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 320, 240, 30));

        streetField.setBackground(new java.awt.Color(255, 255, 255));
        streetField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        streetField.setForeground(new java.awt.Color(204, 204, 204));
        streetField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(streetField, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 320, 250, 30));

        zipCodeField.setBackground(new java.awt.Color(255, 255, 255));
        zipCodeField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        zipCodeField.setForeground(new java.awt.Color(204, 204, 204));
        zipCodeField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        zipCodeField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                zipCodeFieldActionPerformed(evt);
            }
        });
        jPanel4.add(zipCodeField, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 390, 130, 30));

        municipalityField.setBackground(new java.awt.Color(255, 255, 255));
        municipalityField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        municipalityField.setForeground(new java.awt.Color(204, 204, 204));
        municipalityField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(municipalityField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 530, 30));

        subdivisionField.setBackground(new java.awt.Color(255, 255, 255));
        subdivisionField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        subdivisionField.setForeground(new java.awt.Color(204, 204, 204));
        subdivisionField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        subdivisionField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subdivisionFieldActionPerformed(evt);
            }
        });
        jPanel4.add(subdivisionField, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 320, 310, 30));

        jLabel22.setBackground(new java.awt.Color(0, 102, 153));
        jLabel22.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(153, 153, 153));
        jLabel22.setText("Gender");
        jPanel4.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel23.setBackground(new java.awt.Color(0, 102, 153));
        jLabel23.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(153, 153, 153));
        jLabel23.setText("Block / Unit");
        jPanel4.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, -1, -1));

        jLabel25.setBackground(new java.awt.Color(0, 102, 153));
        jLabel25.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(153, 153, 153));
        jLabel25.setText("Subdivision/Village/Etc.");
        jPanel4.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 300, -1, -1));

        jLabel26.setBackground(new java.awt.Color(0, 102, 153));
        jLabel26.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(153, 153, 153));
        jLabel26.setText("Baranggay");
        jPanel4.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 300, -1, -1));

        jLabel27.setBackground(new java.awt.Color(0, 102, 153));
        jLabel27.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(153, 153, 153));
        jLabel27.setText("City/Municipality");
        jPanel4.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, -1, -1));

        jLabel28.setBackground(new java.awt.Color(0, 102, 153));
        jLabel28.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(153, 153, 153));
        jLabel28.setText("Province");
        jPanel4.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 370, -1, -1));

        blockField.setBackground(new java.awt.Color(255, 255, 255));
        blockField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        blockField.setForeground(new java.awt.Color(204, 204, 204));
        blockField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(blockField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 250, 30));

        jLabel29.setBackground(new java.awt.Color(0, 102, 153));
        jLabel29.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(153, 153, 153));
        jLabel29.setText("Street");
        jPanel4.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 300, -1, -1));

        formattedDateField.setBackground(new java.awt.Color(255, 255, 255));
        formattedDateField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        formattedDateField.setForeground(new java.awt.Color(204, 204, 204));
        formattedDateField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(formattedDateField, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 140, 150, 30));

        studentSuffixField.setBackground(new java.awt.Color(255, 255, 255));
        studentSuffixField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentSuffixField.setForeground(new java.awt.Color(204, 204, 204));
        studentSuffixField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(studentSuffixField, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 70, 150, 30));

        jLabel30.setBackground(new java.awt.Color(0, 102, 153));
        jLabel30.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(153, 153, 153));
        jLabel30.setText("Suffix");
        jPanel4.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 50, -1, -1));

        studentBirthplaceField.setBackground(new java.awt.Color(255, 255, 255));
        studentBirthplaceField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentBirthplaceField.setForeground(new java.awt.Color(204, 204, 204));
        studentBirthplaceField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        studentBirthplaceField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentBirthplaceFieldActionPerformed(evt);
            }
        });
        jPanel4.add(studentBirthplaceField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 530, 30));

        studentFirstNameField.setBackground(new java.awt.Color(255, 255, 255));
        studentFirstNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentFirstNameField.setForeground(new java.awt.Color(204, 204, 204));
        studentFirstNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(studentFirstNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 250, 30));

        studentGenderField.setBackground(new java.awt.Color(255, 255, 255));
        studentGenderField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentGenderField.setForeground(new java.awt.Color(204, 204, 204));
        studentGenderField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(studentGenderField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 250, 30));

        studentStatusField.setBackground(new java.awt.Color(255, 255, 255));
        studentStatusField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentStatusField.setForeground(new java.awt.Color(204, 204, 204));
        studentStatusField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel4.add(studentStatusField, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 140, 250, 30));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 290, 1180, 460));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        studentEmailAddressField.setBackground(new java.awt.Color(255, 255, 255));
        studentEmailAddressField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentEmailAddressField.setForeground(new java.awt.Color(204, 204, 204));
        studentEmailAddressField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel3.add(studentEmailAddressField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 520, 30));

        studentContactNumberField.setBackground(new java.awt.Color(255, 255, 255));
        studentContactNumberField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        studentContactNumberField.setForeground(new java.awt.Color(204, 204, 204));
        studentContactNumberField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        studentContactNumberField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentContactNumberFieldActionPerformed(evt);
            }
        });
        jPanel3.add(studentContactNumberField, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 70, 580, 30));

        jLabel31.setBackground(new java.awt.Color(0, 102, 153));
        jLabel31.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(153, 153, 153));
        jLabel31.setText("Contact Number");
        jPanel3.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, -1));

        jLabel8.setBackground(new java.awt.Color(0, 102, 153));
        jLabel8.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 66, 37));
        jLabel8.setText("Contact Details");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel32.setBackground(new java.awt.Color(0, 102, 153));
        jLabel32.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(153, 153, 153));
        jLabel32.setText("Email Address");
        jPanel3.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 770, 1180, 120));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel33.setBackground(new java.awt.Color(0, 102, 153));
        jLabel33.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(153, 153, 153));
        jLabel33.setText("School Type");
        jPanel2.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel35.setBackground(new java.awt.Color(0, 102, 153));
        jLabel35.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(153, 153, 153));
        jLabel35.setText("Strand");
        jPanel2.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 50, -1, -1));

        jLabel36.setBackground(new java.awt.Color(0, 102, 153));
        jLabel36.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(153, 153, 153));
        jLabel36.setText("School Year");
        jPanel2.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jLabel37.setBackground(new java.awt.Color(0, 102, 153));
        jLabel37.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(153, 153, 153));
        jPanel2.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, -1, -1));

        jLabel9.setBackground(new java.awt.Color(0, 102, 153));
        jLabel9.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 66, 37));
        jLabel9.setText("Current / Last School Attended");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel10.setBackground(new java.awt.Color(0, 102, 153));
        jLabel10.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 153));
        jLabel10.setText("Current / Last School Attended");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel38.setBackground(new java.awt.Color(0, 102, 153));
        jLabel38.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(153, 153, 153));
        jLabel38.setText("Name of School");
        jPanel2.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 50, -1, -1));

        previousSchoolYearField.setBackground(new java.awt.Color(255, 255, 255));
        previousSchoolYearField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        previousSchoolYearField.setForeground(new java.awt.Color(204, 204, 204));
        previousSchoolYearField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel2.add(previousSchoolYearField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 350, 30));

        nameOfSchoolField.setBackground(new java.awt.Color(255, 255, 255));
        nameOfSchoolField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        nameOfSchoolField.setForeground(new java.awt.Color(204, 204, 204));
        nameOfSchoolField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel2.add(nameOfSchoolField, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 70, 350, 30));

        schoolTypeField.setBackground(new java.awt.Color(255, 255, 255));
        schoolTypeField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        schoolTypeField.setForeground(new java.awt.Color(204, 204, 204));
        schoolTypeField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel2.add(schoolTypeField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 350, 30));

        strandField.setBackground(new java.awt.Color(255, 255, 255));
        strandField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        strandField.setForeground(new java.awt.Color(204, 204, 204));
        strandField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel2.add(strandField, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 70, 350, 30));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 910, 1180, 190));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(235, 235, 235), 2, true));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 102, 153));
        jLabel2.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 66, 37));
        jLabel2.setText("Parent / Guardian Information");
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        fatherOccupationField.setBackground(new java.awt.Color(255, 255, 255));
        fatherOccupationField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        fatherOccupationField.setForeground(new java.awt.Color(204, 204, 204));
        fatherOccupationField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        fatherOccupationField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fatherOccupationFieldActionPerformed(evt);
            }
        });
        jPanel5.add(fatherOccupationField, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 170, 250, 30));

        fatherFirstNameField.setBackground(new java.awt.Color(255, 255, 255));
        fatherFirstNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        fatherFirstNameField.setForeground(new java.awt.Color(204, 204, 204));
        fatherFirstNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(fatherFirstNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 250, 30));

        fatherLastNameField.setBackground(new java.awt.Color(255, 255, 255));
        fatherLastNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        fatherLastNameField.setForeground(new java.awt.Color(204, 204, 204));
        fatherLastNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(fatherLastNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 100, 250, 30));

        fatherContactNumberField.setBackground(new java.awt.Color(255, 255, 255));
        fatherContactNumberField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        fatherContactNumberField.setForeground(new java.awt.Color(204, 204, 204));
        fatherContactNumberField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(fatherContactNumberField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 250, 30));

        fatherEmailAddressField.setBackground(new java.awt.Color(255, 255, 255));
        fatherEmailAddressField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        fatherEmailAddressField.setForeground(new java.awt.Color(204, 204, 204));
        fatherEmailAddressField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(fatherEmailAddressField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 250, 30));

        fatherSuffixField.setBackground(new java.awt.Color(255, 255, 255));
        fatherSuffixField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        fatherSuffixField.setForeground(new java.awt.Color(204, 204, 204));
        fatherSuffixField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(fatherSuffixField, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 100, 150, 30));

        fatherMiddleInitialField.setBackground(new java.awt.Color(255, 255, 255));
        fatherMiddleInitialField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        fatherMiddleInitialField.setForeground(new java.awt.Color(204, 204, 204));
        fatherMiddleInitialField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        fatherMiddleInitialField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fatherMiddleInitialFieldActionPerformed(evt);
            }
        });
        jPanel5.add(fatherMiddleInitialField, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 100, 250, 30));

        jLabel34.setBackground(new java.awt.Color(0, 102, 153));
        jLabel34.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(153, 153, 153));
        jLabel34.setText("Father Suffix");
        jPanel5.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 80, -1, -1));

        jLabel39.setBackground(new java.awt.Color(0, 102, 153));
        jLabel39.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(153, 153, 153));
        jLabel39.setText("* Father Information");
        jPanel5.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel40.setBackground(new java.awt.Color(0, 102, 153));
        jLabel40.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(153, 153, 153));
        jLabel40.setText("Contact Number");
        jPanel5.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        jLabel41.setBackground(new java.awt.Color(0, 102, 153));
        jLabel41.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(153, 153, 153));
        jLabel41.setText("Email Address");
        jPanel5.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, -1, -1));

        jLabel42.setBackground(new java.awt.Color(0, 102, 153));
        jLabel42.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(153, 153, 153));
        jLabel42.setText("Father Last Name");
        jPanel5.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, -1, -1));

        jLabel43.setBackground(new java.awt.Color(0, 102, 153));
        jLabel43.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(153, 153, 153));
        jLabel43.setText("Father Middle Initial");
        jPanel5.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 80, -1, -1));

        jLabel44.setBackground(new java.awt.Color(0, 102, 153));
        jLabel44.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(153, 153, 153));
        jLabel44.setText("Occupation");
        jPanel5.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 150, -1, -1));

        jLabel45.setBackground(new java.awt.Color(0, 102, 153));
        jLabel45.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(153, 153, 153));
        jLabel45.setText("Father First Name");
        jPanel5.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        motherOccupationField.setBackground(new java.awt.Color(255, 255, 255));
        motherOccupationField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        motherOccupationField.setForeground(new java.awt.Color(204, 204, 204));
        motherOccupationField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        motherOccupationField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                motherOccupationFieldActionPerformed(evt);
            }
        });
        jPanel5.add(motherOccupationField, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 340, 250, 30));

        motherFirstNameField.setBackground(new java.awt.Color(255, 255, 255));
        motherFirstNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        motherFirstNameField.setForeground(new java.awt.Color(204, 204, 204));
        motherFirstNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(motherFirstNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 250, 30));

        motherLastNameField.setBackground(new java.awt.Color(255, 255, 255));
        motherLastNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        motherLastNameField.setForeground(new java.awt.Color(204, 204, 204));
        motherLastNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(motherLastNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 270, 250, 30));

        motherContactNumberField.setBackground(new java.awt.Color(255, 255, 255));
        motherContactNumberField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        motherContactNumberField.setForeground(new java.awt.Color(204, 204, 204));
        motherContactNumberField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        motherContactNumberField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                motherContactNumberFieldActionPerformed(evt);
            }
        });
        jPanel5.add(motherContactNumberField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 250, 30));

        motherEmailAddressField.setBackground(new java.awt.Color(255, 255, 255));
        motherEmailAddressField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        motherEmailAddressField.setForeground(new java.awt.Color(204, 204, 204));
        motherEmailAddressField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(motherEmailAddressField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 250, 30));

        motherSuffixField.setBackground(new java.awt.Color(255, 255, 255));
        motherSuffixField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        motherSuffixField.setForeground(new java.awt.Color(204, 204, 204));
        motherSuffixField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        motherSuffixField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                motherSuffixFieldActionPerformed(evt);
            }
        });
        jPanel5.add(motherSuffixField, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 270, 150, 30));

        motherMiddleInitialField.setBackground(new java.awt.Color(255, 255, 255));
        motherMiddleInitialField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        motherMiddleInitialField.setForeground(new java.awt.Color(204, 204, 204));
        motherMiddleInitialField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        motherMiddleInitialField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                motherMiddleInitialFieldActionPerformed(evt);
            }
        });
        jPanel5.add(motherMiddleInitialField, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 270, 250, 30));

        jLabel46.setBackground(new java.awt.Color(0, 102, 153));
        jLabel46.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(153, 153, 153));
        jLabel46.setText("Mother Suffix");
        jPanel5.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 250, -1, -1));

        jLabel47.setBackground(new java.awt.Color(0, 102, 153));
        jLabel47.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(153, 153, 153));
        jLabel47.setText("* Father Information");
        jPanel5.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        jLabel48.setBackground(new java.awt.Color(0, 102, 153));
        jLabel48.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(153, 153, 153));
        jLabel48.setText("Contact Number");
        jPanel5.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        jLabel49.setBackground(new java.awt.Color(0, 102, 153));
        jLabel49.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(153, 153, 153));
        jLabel49.setText("Email Address");
        jPanel5.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 320, -1, -1));

        jLabel50.setBackground(new java.awt.Color(0, 102, 153));
        jLabel50.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(153, 153, 153));
        jLabel50.setText("Mother Last Name");
        jPanel5.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 250, -1, -1));

        jLabel51.setBackground(new java.awt.Color(0, 102, 153));
        jLabel51.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(153, 153, 153));
        jLabel51.setText("Mother Middle initial");
        jPanel5.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 250, -1, -1));

        jLabel52.setBackground(new java.awt.Color(0, 102, 153));
        jLabel52.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(153, 153, 153));
        jLabel52.setText("Occupation");
        jPanel5.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 320, -1, -1));

        jLabel53.setBackground(new java.awt.Color(0, 102, 153));
        jLabel53.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(153, 153, 153));
        jLabel53.setText("Mother First Name");
        jPanel5.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, -1, -1));

        guardianOccupationField.setBackground(new java.awt.Color(255, 255, 255));
        guardianOccupationField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        guardianOccupationField.setForeground(new java.awt.Color(204, 204, 204));
        guardianOccupationField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        guardianOccupationField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardianOccupationFieldActionPerformed(evt);
            }
        });
        jPanel5.add(guardianOccupationField, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 520, 250, 30));

        guardianFirstNameField.setBackground(new java.awt.Color(255, 255, 255));
        guardianFirstNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        guardianFirstNameField.setForeground(new java.awt.Color(204, 204, 204));
        guardianFirstNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        guardianFirstNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardianFirstNameFieldActionPerformed(evt);
            }
        });
        jPanel5.add(guardianFirstNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 250, 30));

        guardianLastNameField.setBackground(new java.awt.Color(255, 255, 255));
        guardianLastNameField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        guardianLastNameField.setForeground(new java.awt.Color(204, 204, 204));
        guardianLastNameField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(guardianLastNameField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 450, 250, 30));

        guardianContactNumberField.setBackground(new java.awt.Color(255, 255, 255));
        guardianContactNumberField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        guardianContactNumberField.setForeground(new java.awt.Color(204, 204, 204));
        guardianContactNumberField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(guardianContactNumberField, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 250, 30));

        guardianEmailAddressField.setBackground(new java.awt.Color(255, 255, 255));
        guardianEmailAddressField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        guardianEmailAddressField.setForeground(new java.awt.Color(204, 204, 204));
        guardianEmailAddressField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(guardianEmailAddressField, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 520, 250, 30));

        guardianRelationshipField.setBackground(new java.awt.Color(255, 255, 255));
        guardianRelationshipField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        guardianRelationshipField.setForeground(new java.awt.Color(204, 204, 204));
        guardianRelationshipField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        guardianRelationshipField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardianRelationshipFieldActionPerformed(evt);
            }
        });
        jPanel5.add(guardianRelationshipField, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 520, 150, 30));

        guardianMiddleInitialField.setBackground(new java.awt.Color(255, 255, 255));
        guardianMiddleInitialField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        guardianMiddleInitialField.setForeground(new java.awt.Color(204, 204, 204));
        guardianMiddleInitialField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        guardianMiddleInitialField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardianMiddleInitialFieldActionPerformed(evt);
            }
        });
        jPanel5.add(guardianMiddleInitialField, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 450, 250, 30));

        jLabel54.setBackground(new java.awt.Color(0, 102, 153));
        jLabel54.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(153, 153, 153));
        jLabel54.setText("Relationship");
        jPanel5.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 500, -1, -1));

        jLabel55.setBackground(new java.awt.Color(0, 102, 153));
        jLabel55.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(153, 153, 153));
        jLabel55.setText("* Guardian Information");
        jPanel5.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, -1, -1));

        jLabel56.setBackground(new java.awt.Color(0, 102, 153));
        jLabel56.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(153, 153, 153));
        jLabel56.setText("Contact Number");
        jPanel5.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, -1, -1));

        jLabel57.setBackground(new java.awt.Color(0, 102, 153));
        jLabel57.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(153, 153, 153));
        jLabel57.setText("Email Address");
        jPanel5.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 500, -1, -1));

        jLabel58.setBackground(new java.awt.Color(0, 102, 153));
        jLabel58.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(153, 153, 153));
        jLabel58.setText("Guirdian Last Name");
        jPanel5.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 430, -1, -1));

        jLabel59.setBackground(new java.awt.Color(0, 102, 153));
        jLabel59.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(153, 153, 153));
        jLabel59.setText("Guirdian Middle Initial");
        jPanel5.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 430, -1, -1));

        jLabel60.setBackground(new java.awt.Color(0, 102, 153));
        jLabel60.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(153, 153, 153));
        jLabel60.setText("Occupation");
        jPanel5.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 500, -1, -1));

        jLabel61.setBackground(new java.awt.Color(0, 102, 153));
        jLabel61.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(153, 153, 153));
        jLabel61.setText("Guirdian First Name");
        jPanel5.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, -1, -1));

        guardianSuffixField.setBackground(new java.awt.Color(255, 255, 255));
        guardianSuffixField.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        guardianSuffixField.setForeground(new java.awt.Color(204, 204, 204));
        guardianSuffixField.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(102, 102, 102), 1, true));
        jPanel5.add(guardianSuffixField, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 450, 150, 30));

        jLabel62.setBackground(new java.awt.Color(0, 102, 153));
        jLabel62.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(153, 153, 153));
        jLabel62.setText("Guirdian Suffix");
        jPanel5.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 430, -1, -1));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 1120, 1180, 570));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1180, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 1740, 1180, 30));

        jLabel5.setBackground(new java.awt.Color(0, 102, 153));
        jLabel5.setFont(new java.awt.Font("Bahnschrift", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 153));
        jLabel5.setText("Applicant Information");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, -1, -1));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Bahnschrift", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 51, 51));
        jButton1.setText("x");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1450, 30, 30, 30));

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1810, 970));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void studentCitizenshipFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentCitizenshipFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentCitizenshipFieldActionPerformed

    private void studentReligionFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentReligionFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentReligionFieldActionPerformed

    private void provinceFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_provinceFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_provinceFieldActionPerformed

    private void zipCodeFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_zipCodeFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_zipCodeFieldActionPerformed

    private void studentContactNumberFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentContactNumberFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentContactNumberFieldActionPerformed

    private void fatherOccupationFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fatherOccupationFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fatherOccupationFieldActionPerformed

    private void fatherMiddleInitialFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fatherMiddleInitialFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fatherMiddleInitialFieldActionPerformed

    private void motherOccupationFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_motherOccupationFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_motherOccupationFieldActionPerformed

    private void motherMiddleInitialFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_motherMiddleInitialFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_motherMiddleInitialFieldActionPerformed

    private void guardianOccupationFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardianOccupationFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_guardianOccupationFieldActionPerformed

    private void guardianMiddleInitialFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardianMiddleInitialFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_guardianMiddleInitialFieldActionPerformed

    private void studentLastNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentLastNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentLastNameFieldActionPerformed

    private void studentMiddleNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentMiddleNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentMiddleNameFieldActionPerformed

    private void yearLevelFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearLevelFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_yearLevelFieldActionPerformed

    private void subdivisionFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subdivisionFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_subdivisionFieldActionPerformed

    private void barangayFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_barangayFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_barangayFieldActionPerformed

    private void motherSuffixFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_motherSuffixFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_motherSuffixFieldActionPerformed

    private void motherContactNumberFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_motherContactNumberFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_motherContactNumberFieldActionPerformed

    private void guardianFirstNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardianFirstNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_guardianFirstNameFieldActionPerformed

    private void guardianRelationshipFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardianRelationshipFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_guardianRelationshipFieldActionPerformed

    private void studentBirthplaceFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentBirthplaceFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentBirthplaceFieldActionPerformed

    private void courseFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_courseFieldActionPerformed

    private void admitTypeFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_admitTypeFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_admitTypeFieldActionPerformed

    private void schoolYearFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_schoolYearFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_schoolYearFieldActionPerformed

    private void termFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_termFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_termFieldActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {         
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField admitTypeField;
    private javax.swing.JTextField barangayField;
    private javax.swing.JTextField blockField;
    private javax.swing.JTextField courseField;
    private javax.swing.JTextField fatherContactNumberField;
    private javax.swing.JTextField fatherEmailAddressField;
    private javax.swing.JTextField fatherFirstNameField;
    private javax.swing.JTextField fatherLastNameField;
    private javax.swing.JTextField fatherMiddleInitialField;
    private javax.swing.JTextField fatherOccupationField;
    private javax.swing.JTextField fatherSuffixField;
    private javax.swing.JTextField formattedDateField;
    private javax.swing.JTextField guardianContactNumberField;
    private javax.swing.JTextField guardianEmailAddressField;
    private javax.swing.JTextField guardianFirstNameField;
    private javax.swing.JTextField guardianLastNameField;
    private javax.swing.JTextField guardianMiddleInitialField;
    private javax.swing.JTextField guardianOccupationField;
    private javax.swing.JTextField guardianRelationshipField;
    private javax.swing.JTextField guardianSuffixField;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField motherContactNumberField;
    private javax.swing.JTextField motherEmailAddressField;
    private javax.swing.JTextField motherFirstNameField;
    private javax.swing.JTextField motherLastNameField;
    private javax.swing.JTextField motherMiddleInitialField;
    private javax.swing.JTextField motherOccupationField;
    private javax.swing.JTextField motherSuffixField;
    private javax.swing.JTextField municipalityField;
    private javax.swing.JTextField nameOfSchoolField;
    private javax.swing.JTextField previousSchoolYearField;
    private javax.swing.JTextField provinceField;
    private javax.swing.JTextField schoolTypeField;
    private javax.swing.JTextField schoolYearField;
    private javax.swing.JTextField strandField;
    private javax.swing.JTextField streetField;
    private javax.swing.JTextField studentBirthplaceField;
    private javax.swing.JTextField studentCitizenshipField;
    private javax.swing.JTextField studentContactNumberField;
    private javax.swing.JTextField studentEmailAddressField;
    private javax.swing.JTextField studentFirstNameField;
    private javax.swing.JTextField studentGenderField;
    private javax.swing.JTextField studentLastNameField;
    private javax.swing.JTextField studentMiddleNameField;
    private javax.swing.JTextField studentReligionField;
    private javax.swing.JTextField studentStatusField;
    private javax.swing.JTextField studentSuffixField;
    private javax.swing.JTextField subdivisionField;
    private javax.swing.JTextField termField;
    private javax.swing.JTextField yearLevelField;
    private javax.swing.JTextField zipCodeField;
    // End of variables declaration//GEN-END:variables
}
